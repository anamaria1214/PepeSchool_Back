create view AWR_CDB_PLAN_OPERATION_NAME (DBID, OPERATION_ID, OPERATION_NAME, CON_DBID, CON_ID) as
select dbid, operation_id, operation_name,
       decode(con_dbid, 0, dbid, con_dbid),
       decode(con_dbid_to_id(dbid), 1, 0, con_dbid_to_id(dbid)) con_id
from WRH$_PLAN_OPERATION_NAME
/

comment on table AWR_CDB_PLAN_OPERATION_NAME is 'Optimizer Explain Plan Operation Names'
/

