create view DBA_SQLTUNE_BINDS (TASK_ID, OBJECT_ID, POSITION, VALUE) as
SELECT task_id, object_id, position, value
  FROM   wri$_adv_sqlt_binds
/

