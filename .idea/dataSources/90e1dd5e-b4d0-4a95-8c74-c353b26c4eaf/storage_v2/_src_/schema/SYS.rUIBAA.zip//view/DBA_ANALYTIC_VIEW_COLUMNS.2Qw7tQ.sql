create view DBA_ANALYTIC_VIEW_COLUMNS
            (OWNER, ANALYTIC_VIEW_NAME, DIMENSION_NAME, HIER_NAME, COLUMN_NAME, ROLE, DATA_TYPE, DATA_LENGTH,
             DATA_PRECISION, DATA_SCALE, NULLABLE, CHARACTER_SET_NAME, CHAR_COL_DECL_LENGTH, CHAR_USED, ORDER_NUM,
             ORIGIN_CON_ID)
as
select OWNER, ANALYTIC_VIEW_NAME, DIMENSION_NAME, HIER_NAME, COLUMN_NAME,
    ROLE, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE,
    CHARACTER_SET_NAME, CHAR_COL_DECL_LENGTH, CHAR_USED,
    ORDER_NUM, ORIGIN_CON_ID
from INT$DBA_AVIEW_COLUMNS
/

comment on table DBA_ANALYTIC_VIEW_COLUMNS is 'Analytic view columns in the database'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.OWNER is 'Owner of analytic view column'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.ANALYTIC_VIEW_NAME is 'Name of the owning analytic view'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.DIMENSION_NAME is 'Alias of the dimension in the analytic view (MEASURES for measures)'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.HIER_NAME is 'Alias of the hierarchy within DIM_NAME in the analytic view (MEASURES for measures)'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.COLUMN_NAME is 'Name of the column'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.ROLE is 'The role the attribute plays in the analytic view.  One of: KEY, AKEY, PROP, HIER, or MEAS'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.DATA_TYPE is 'Datatype of the column'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.DATA_LENGTH is 'Length of the column (in bytes)'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.DATA_PRECISION is 'Decimal precision for NUMBER datatype; binary precision for
 FLOAT datatype, NULL for all other datatypes'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.DATA_SCALE is 'Digits to right of decimal point in a number'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.NULLABLE is 'Does column allow NULL values?'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.CHARACTER_SET_NAME is 'Name of the character set: CHAR_CS or NCHAR_CS'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.CHAR_COL_DECL_LENGTH is 'Declaration length of character type column'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.CHAR_USED is 'B or C.  B indicates that the column uses BYTE length semantics.
 C indicates that the column uses CHAR length semantics. NULL indicates
 the datatype is not any of the following: CHAR, VARCHAR2, NCHAR, NVARCHAR2'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.ORDER_NUM is 'Order of the column, with the hierarchy columns first followed by measure
 columns.  The columns for a given hierarchy are grouped together, with the
 ordering of the hierarchies determined by dimension/hierarchy order as created.
 Within a given hierarchy, attributes are listed first in order created
 followed by hierarchical attributes'
/

comment on column DBA_ANALYTIC_VIEW_COLUMNS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

