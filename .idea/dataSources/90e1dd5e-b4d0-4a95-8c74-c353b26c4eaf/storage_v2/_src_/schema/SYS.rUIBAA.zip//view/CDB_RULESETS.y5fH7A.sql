create view CDB_RULESETS (OWNER, RULESET_NAME, RULESET_STORAGE_TABLE, BASE_TABLE, RULESET_COMMENT, CON_ID) as
SELECT k."OWNER",k."RULESET_NAME",k."RULESET_STORAGE_TABLE",k."BASE_TABLE",k."RULESET_COMMENT",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_RULESETS") k
/

comment on table CDB_RULESETS is 'Rulesets in the database: maintained for backward compatibility in all containers'
/

comment on column CDB_RULESETS.OWNER is 'Owner of the ruleset'
/

comment on column CDB_RULESETS.RULESET_NAME is 'Name of the ruleset'
/

comment on column CDB_RULESETS.RULESET_STORAGE_TABLE is 'name of the table to store rules in the ruleset'
/

comment on column CDB_RULESETS.BASE_TABLE is 'name of the evaluation context for the rule set'
/

comment on column CDB_RULESETS.RULESET_COMMENT is 'user description of the ruleset'
/

comment on column CDB_RULESETS.CON_ID is 'container id'
/

