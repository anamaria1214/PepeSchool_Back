create view EXU9INDI
            (IOBJID, IDOBJID, INAME, IOWNER, IOWNERID, ISPACE, ITSNO, IFILENO, IBLOCKNO, BTNAME, BTOBJID, BTOWNER,
             BTOWNERID, BTPROPERTY, BTCLUSTERFLAG, PROPERTY, CLUSTER$, PCTFREE$, INITRANS, MAXTRANS, BLEVEL, BITMAP,
             DEFLOG, TSDEFLOG, DEGREE, INSTANCES, TYPE, ROWCNT, LEAFCNT, DISTKEY, LBLKKEY, DBLKKEY, CLUFAC, PRECCNT,
             IFLAGS, SYSGENCONST)
as
SELECT  "IOBJID","IDOBJID","INAME","IOWNER","IOWNERID","ISPACE","ITSNO","IFILENO","IBLOCKNO","BTNAME","BTOBJID","BTOWNER","BTOWNERID","BTPROPERTY","BTCLUSTERFLAG","PROPERTY","CLUSTER$","PCTFREE$","INITRANS","MAXTRANS","BLEVEL","BITMAP","DEFLOG","TSDEFLOG","DEGREE","INSTANCES","TYPE","ROWCNT","LEAFCNT","DISTKEY","LBLKKEY","DBLKKEY","CLUFAC","PRECCNT","IFLAGS","SYSGENCONST"
        FROM    sys.exu9ind
        WHERE   sysgenconst = 0 AND                /* not sys gen constraint */
                (bitmap = 1 OR                             /* select bitmap, */
                 BITAND(property, 16) = 16 OR                 /* functional, */
                 type = 9) AND                         /* and domain indexes */
                (iownerid, btname) IN ((
                    SELECT  ownerid, name
                    FROM    sys.exu9tabi)
                  UNION (
                    SELECT  r.ownerid, r.tname
                    FROM    sys.exu9tabi ii, sys.exu8ref r
                    WHERE   r.robjid = ii.objid))   /* table included in inc */
/

