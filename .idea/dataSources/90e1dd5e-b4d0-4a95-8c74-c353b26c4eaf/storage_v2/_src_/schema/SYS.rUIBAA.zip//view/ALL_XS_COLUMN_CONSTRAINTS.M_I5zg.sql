create view ALL_XS_COLUMN_CONSTRAINTS (POLICY, OWNER, COLUMN_NAME, PRIVILEGE) as
select DISTINCT o1.name, o1.owner, c.attr_name, o2.name
  from sys.xs$obj o1, sys.xs$obj o2, sys.xs$obj o3, sys.xs$attr_sec c
 where o1.id = c.xdsid# and o2.id = c.priv# and
       ((ORA_CHECK_PRIVILEGE('ADMIN_ANY_SEC_POLICY')=1 and o1.owner != 'SYS') or
        o1.owner  = sys_context('USERENV','CURRENT_USER') or
        (o1.owner=o3.owner and o3.name='XS$SCHEMA_ACL' and o3.type=3 and
         ORA_CHECK_ACL(TO_ACLID(o3.owner||'.XS$SCHEMA_ACL'),
                       'ADMIN_SEC_POLICY')=1))
 order by o1.name, c.attr_name
/

comment on table ALL_XS_COLUMN_CONSTRAINTS is 'All the Real Application Security column constraints accessible to the current user'
/

comment on column ALL_XS_COLUMN_CONSTRAINTS.POLICY is 'Name of the data security policy'
/

comment on column ALL_XS_COLUMN_CONSTRAINTS.OWNER is 'Owner of the data security policy'
/

comment on column ALL_XS_COLUMN_CONSTRAINTS.COLUMN_NAME is 'Name of the column that the column constraint is enforced'
/

comment on column ALL_XS_COLUMN_CONSTRAINTS.PRIVILEGE is 'Name of the privilege required to access the column'
/

