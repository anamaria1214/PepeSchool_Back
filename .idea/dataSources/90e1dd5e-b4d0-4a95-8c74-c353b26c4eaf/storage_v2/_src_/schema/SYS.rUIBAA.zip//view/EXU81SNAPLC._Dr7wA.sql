create view EXU81SNAPLC
            (LOG_OWNER, LOG_OWNERID, MASTER, LOG_TABLE, LOG_TRIGGER, FLAG, YOUNGEST, OLDEST, OLDEST_PK, MTIME,
             ROWID_SNAPL, PRIMKEY_SNAPL, FILE_VER, TEMP_LOG)
as
SELECT  s."LOG_OWNER",s."LOG_OWNERID",s."MASTER",s."LOG_TABLE",s."LOG_TRIGGER",s."FLAG",s."YOUNGEST",s."OLDEST",s."OLDEST_PK",s."MTIME",s."ROWID_SNAPL",s."PRIMKEY_SNAPL",s."FILE_VER",s."TEMP_LOG"
        FROM    sys.exu81snapl s, sys.incexp i, sys.incvid v
        WHERE   s.master = i.name(+) AND
                s.log_ownerid = i.owner#(+) AND
                NVL(i.type#, 98) = 98 AND
                (NVL(i.ctime, TO_DATE('01-01-1900', 'DD-MM-YYYY')) < i.itime OR
                 NVL(i.expid, 9999) > v.expid)
/

