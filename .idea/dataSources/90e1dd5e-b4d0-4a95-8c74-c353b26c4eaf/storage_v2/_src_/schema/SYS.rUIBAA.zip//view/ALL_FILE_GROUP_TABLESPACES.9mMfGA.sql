create view ALL_FILE_GROUP_TABLESPACES (FILE_GROUP_OWNER, FILE_GROUP_NAME, VERSION_NAME, VERSION, TABLESPACE_NAME) as
select file_group_owner, file_group_name, version_name, version_id,
       tablespace_name
from "_ALL_FILE_GROUP_TABLESPACES"
/

comment on table ALL_FILE_GROUP_TABLESPACES is 'Details about the transportable tablespaces in the file group repository'
/

comment on column ALL_FILE_GROUP_TABLESPACES.FILE_GROUP_OWNER is 'Owner of the file group'
/

comment on column ALL_FILE_GROUP_TABLESPACES.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column ALL_FILE_GROUP_TABLESPACES.VERSION_NAME is 'Name of the version'
/

comment on column ALL_FILE_GROUP_TABLESPACES.VERSION is 'Internal version number'
/

comment on column ALL_FILE_GROUP_TABLESPACES.TABLESPACE_NAME is 'Name of the tablespace'
/

