create view DBA_XS_COLUMN_CONSTRAINTS (POLICY, OWNER, COLUMN_NAME, PRIVILEGE) as
select o1.name, o1.owner, c.attr_name, o2.name
  from sys.xs$obj o1, sys.xs$obj o2, sys.xs$attr_sec c
 where o1.id = c.xdsid# and o2.id = c.priv#
 order by o1.name, c.attr_name
/

comment on table DBA_XS_COLUMN_CONSTRAINTS is 'All the Real Application Security column constraints defined in the database'
/

comment on column DBA_XS_COLUMN_CONSTRAINTS.POLICY is 'Name of the data security policy'
/

comment on column DBA_XS_COLUMN_CONSTRAINTS.OWNER is 'Owner of the data security policy'
/

comment on column DBA_XS_COLUMN_CONSTRAINTS.COLUMN_NAME is 'Name of the column that the column constraint is enforced'
/

comment on column DBA_XS_COLUMN_CONSTRAINTS.PRIVILEGE is 'Name of the privilege required to access the column'
/

