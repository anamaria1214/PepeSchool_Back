create view CDB_LOG_GROUP_COLUMNS
            (OWNER, LOG_GROUP_NAME, TABLE_NAME, COLUMN_NAME, POSITION, LOGGING_PROPERTY, CON_ID) as
SELECT k."OWNER",k."LOG_GROUP_NAME",k."TABLE_NAME",k."COLUMN_NAME",k."POSITION",k."LOGGING_PROPERTY",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_LOG_GROUP_COLUMNS") k
/

comment on table CDB_LOG_GROUP_COLUMNS is 'Information about columns in log group definitions in all containers'
/

comment on column CDB_LOG_GROUP_COLUMNS.OWNER is 'Owner of the log group definition'
/

comment on column CDB_LOG_GROUP_COLUMNS.LOG_GROUP_NAME is 'Name associated with the log group definition'
/

comment on column CDB_LOG_GROUP_COLUMNS.TABLE_NAME is 'Name associated with table with log group definition'
/

comment on column CDB_LOG_GROUP_COLUMNS.COLUMN_NAME is 'Name associated with column or attribute of object column specified in the log group definition'
/

comment on column CDB_LOG_GROUP_COLUMNS.POSITION is 'Original position of column or attribute in definition'
/

comment on column CDB_LOG_GROUP_COLUMNS.LOGGING_PROPERTY is 'Whether the column or attribute would be supplementally logged'
/

comment on column CDB_LOG_GROUP_COLUMNS.CON_ID is 'container id'
/

