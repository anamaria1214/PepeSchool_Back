create view CDB_HIST_COMP_IOSTAT
            (SNAP_ID, DBID, INSTANCE_NUMBER, COMPONENT, FILE_TYPE, IO_TYPE, OPERATION, BYTES, IO_COUNT, CON_DBID,
             CON_ID) as
SELECT k."SNAP_ID",k."DBID",k."INSTANCE_NUMBER",k."COMPONENT",k."FILE_TYPE",k."IO_TYPE",k."OPERATION",k."BYTES",k."IO_COUNT",k."CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_COMP_IOSTAT") k
/

comment on table CDB_HIST_COMP_IOSTAT is 'I/O stats aggregated on component level in all containers'
/

comment on column CDB_HIST_COMP_IOSTAT.CON_ID is 'container id'
/

