create view AWR_CDB_SGA (SNAP_ID, DBID, INSTANCE_NUMBER, NAME, VALUE, CON_DBID, CON_ID) as
select sga.snap_id, sga.dbid, sga.instance_number, name,
       case when SYS_CONTEXT('USERENV','SYSTEM_DATA_VISIBLE')='YES' or sga.per_pdb<>0 then sga.value else null end value,
       decode(sga.con_dbid, 0, sga.dbid, sga.con_dbid),
       decode(sga.per_pdb, 0, 0,
         con_dbid_to_id(decode(sga.con_dbid, 0, sga.dbid, sga.con_dbid))) con_id
  from AWR_CDB_SNAPSHOT sn, WRH$_SGA sga
  where     sn.snap_id         = sga.snap_id
        and sn.dbid            = sga.dbid
        and sn.instance_number = sga.instance_number
/

comment on table AWR_CDB_SGA is 'SGA Historical Statistics Information'
/

