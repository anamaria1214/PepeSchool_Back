create view CDB_HIER_JOIN_PATHS (OWNER, HIER_NAME, JOIN_PATH_NAME, ORDER_NUM, ORIGIN_CON_ID, CON_ID) as
SELECT k."OWNER",k."HIER_NAME",k."JOIN_PATH_NAME",k."ORDER_NUM",k."ORIGIN_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_HIER_JOIN_PATHS") k
/

comment on table CDB_HIER_JOIN_PATHS is 'Hierarchy join paths in the database in all containers'
/

comment on column CDB_HIER_JOIN_PATHS.OWNER is 'Owner of the hierarchy join path'
/

comment on column CDB_HIER_JOIN_PATHS.HIER_NAME is 'Name of the owning hierarchy join path'
/

comment on column CDB_HIER_JOIN_PATHS.JOIN_PATH_NAME is 'Name of the hierarchy join path'
/

comment on column CDB_HIER_JOIN_PATHS.ORDER_NUM is 'Order number of join path within the hierarchy'
/

comment on column CDB_HIER_JOIN_PATHS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

comment on column CDB_HIER_JOIN_PATHS.CON_ID is 'container id'
/

