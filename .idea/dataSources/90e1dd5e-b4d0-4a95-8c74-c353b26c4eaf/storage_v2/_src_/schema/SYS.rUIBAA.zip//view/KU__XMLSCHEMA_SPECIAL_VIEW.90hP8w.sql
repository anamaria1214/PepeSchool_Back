create view KU$_XMLSCHEMA_SPECIAL_VIEW (XMLSCHEMA_XML_DOC) as
select
'<?xml version="1.0"?><ROWSET><ROW> <XMLSCHEMA_T> <VERS_MAJOR>1</VERS_MAJOR> <VERS_MINOR>0 </VERS_MINOR> </XMLSCHEMA_T> </ROW></ROWSET>'
xmlschema_xml_doc from dual
/

