create view USER_TSTZ_TABLES (TABLE_NAME, UPGRADE_IN_PROGRESS) as
select distinct table_name,
       decode(bitand(t.property, 137438953472), 137438953472, 'YES', 'NO')
from user_tstz_tab_cols uttc, sys.obj$ o, sys.tab$ t
where uttc.table_name = o.name
  and o.owner# = userenv('SCHEMAID')
  and o.obj# = t.obj#
/

comment on table USER_TSTZ_TABLES is 'Description of the user''s own tables, which have column(s) defined on timestamp with time zone data type or ADT type containing attribute(s) of timestamp with time zone data type'
/

comment on column USER_TSTZ_TABLES.TABLE_NAME is 'Name of the table'
/

comment on column USER_TSTZ_TABLES.UPGRADE_IN_PROGRESS is 'Is table upgrade in progress?'
/

