create view DBA_LOGSTDBY_NOT_UNIQUE (OWNER, TABLE_NAME, BAD_COLUMN) as
with redo_compat as
         (select nvl((select min(s.redo_compat)
                      from system.logstdby$parameters p,
                           system.logmnr_session$ s,
                           sys.v$database d
                      where p.name in ('LMNR_SID', 'FUTURE_SESSION') and
                            p.value = s.session# and
                            d.database_role = 'LOGICAL STANDBY'),
                     (select p.value
                      from sys.v$parameter p
                      where p.name = 'compatible')) compat
          from dual)
  select owner, name table_name,
         decode((select count(c.obj#)
                 from sys.col$ c
                 where c.obj# = l.obj#
                 and ((c.type# in (8,                             /* LONG */
                                   24,                        /* LONG RAW */
                                   58,                             /* XML */
                                   111,                            /* REF */
                                   112,                           /* CLOB */
                                   113,                           /* BLOB */
                                   114,                          /* BFILE */
                                   119,                           /* JSON */
                                   121,                            /* ADT */
                                   123))                        /* Varray */
                 or (c.type# = 1 and bitand(c.property, 128) = 128))),
                 /* 32k varchar */
                 0, 'N', 'Y') bad_column
  from (
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_10_1 u, redo_compat c
    where c.compat like '10.0%' or c.compat like '10.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_10_2 u, redo_compat c
    where c.compat like '10.2%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_1 u, redo_compat c
    where c.compat like '11.0%' or c.compat like '11.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_2 u, redo_compat c
    where c.compat like '11.2%' and c.compat not like '11.2.0.3%'
                                and c.compat not like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_2b u, redo_compat c
    where c.compat like '11.2.0.3%' or c.compat like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_12_1 u, redo_compat c
    where c.compat like '12.0%' or c.compat like '12.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_12_2 u, redo_compat c
    where c.compat like '12.2%' and c.compat not like '12.2.0.2%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_12_2_0_2 u, redo_compat c
    where c.compat like '12.2.0.2%' or c.compat like '18.0%'
          or c.compat like '18.1%'
    UNION ALL
    -- In 19.0, the compat-specific views for LSBY check the RU
    -- event in-line.  From 20.0 onward, we make the check here.  If not
    -- in rolling upgrade, or if replication metadata maintenance
    -- is disabled via event setting, then the obj$ support mode metadata is
    -- not valid, or does not apply, so we must use the compat-specific view.
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_19 u, redo_compat c
    where c.compat like '19.%' or
          (c.compat like '2%.%' and
           sys_context('userenv', 'IS_DG_ROLLING_UPGRADE') = 'FALSE') or
          (c.compat like '2%.%' and
           sys_context('userenv', 'IS_REPL_META_DISA
/

comment on table DBA_LOGSTDBY_NOT_UNIQUE is ' List of all the tables with out primary or unique key not null constraints '
/

comment on column DBA_LOGSTDBY_NOT_UNIQUE.OWNER is ' Schema name of the non - unique table '
/

comment on column DBA_LOGSTDBY_NOT_UNIQUE.TABLE_NAME is ' Table name of the non - unique table '
/

comment on column DBA_LOGSTDBY_NOT_UNIQUE.BAD_COLUMN is ' Indicates that the table has a column not useful in the where
                       clause '
/

