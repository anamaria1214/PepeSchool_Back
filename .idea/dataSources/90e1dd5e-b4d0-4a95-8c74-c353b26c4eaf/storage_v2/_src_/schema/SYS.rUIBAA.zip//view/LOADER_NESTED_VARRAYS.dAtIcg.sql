create view LOADER_NESTED_VARRAYS (TABLE_OWNER, TABLE_NAME) as
select u.name as table_owner, o.name as table_name
        from col$ c, obj$ o, user$ u, ntab$ nt
        where o.obj# = nt.ntab# and o.owner# = u.user# and
              c.obj# = nt.obj#  and c.type#  = 123 and c.intcol# = nt.intcol#
              and (o.owner# = userenv('schemaid')
                    or o.obj# in
                         (select oa.obj#
                          from sys.objauth$ oa
                          where grantee# in ( select kzsrorol
                                              from x$kzsro
                                            )
                         )
                    or
                      ora_check_SYS_privilege (o.owner#, o.type#) = 1
                   )
/

