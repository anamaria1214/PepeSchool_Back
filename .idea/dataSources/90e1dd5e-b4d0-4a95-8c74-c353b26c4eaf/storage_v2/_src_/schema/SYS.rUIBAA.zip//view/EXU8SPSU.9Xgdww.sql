create view EXU8SPSU (OBJ#, LINE, SOURCE) as
SELECT  o.obj#, s.line, s.source
        FROM    sys.source$ s, sys.obj$ o
        WHERE   s.obj# = o.obj# AND
                o.owner# = userenv('SCHEMAID')
/

