create view DBA_ARGUMENTS
            (OWNER, OBJECT_NAME, PACKAGE_NAME, OBJECT_ID, OVERLOAD, SUBPROGRAM_ID, ARGUMENT_NAME, POSITION, SEQUENCE,
             DATA_LEVEL, DATA_TYPE, DEFAULTED, DEFAULT_VALUE, DEFAULT_LENGTH, IN_OUT, DATA_LENGTH, DATA_PRECISION,
             DATA_SCALE, RADIX, CHARACTER_SET_NAME, TYPE_OWNER, TYPE_NAME, TYPE_SUBNAME, TYPE_LINK, TYPE_OBJECT_TYPE,
             PLS_TYPE, CHAR_LENGTH, CHAR_USED, ORIGIN_CON_ID)
as
select
   OWNER, OBJECT_NAME, PACKAGE_NAME, OBJECT_ID, OVERLOAD,
   SUBPROGRAM_ID, ARGUMENT_NAME, POSITION, SEQUENCE,
   DATA_LEVEL, DATA_TYPE, DEFAULTED, DEFAULT_VALUE, DEFAULT_LENGTH,
   IN_OUT, DATA_LENGTH, DATA_PRECISION, DATA_SCALE, RADIX,
   CHARACTER_SET_NAME, TYPE_OWNER, TYPE_NAME, TYPE_SUBNAME,
   TYPE_LINK, TYPE_OBJECT_TYPE, PLS_TYPE, CHAR_LENGTH, CHAR_USED, ORIGIN_CON_ID
from INT$DBA_ARGUMENTS
/

comment on table DBA_ARGUMENTS is 'All arguments for objects in the database'
/

comment on column DBA_ARGUMENTS.OBJECT_NAME is 'Procedure or function name'
/

comment on column DBA_ARGUMENTS.PACKAGE_NAME is 'Package name'
/

comment on column DBA_ARGUMENTS.OBJECT_ID is 'Object number of the object'
/

comment on column DBA_ARGUMENTS.OVERLOAD is 'Overload unique identifier'
/

comment on column DBA_ARGUMENTS.SUBPROGRAM_ID is 'Unique sub-program Identifier'
/

comment on column DBA_ARGUMENTS.ARGUMENT_NAME is 'Argument name'
/

comment on column DBA_ARGUMENTS.POSITION is 'Position in argument list, or null for function return value'
/

comment on column DBA_ARGUMENTS.SEQUENCE is 'Argument sequence, including all nesting levels'
/

comment on column DBA_ARGUMENTS.DATA_LEVEL is 'Nesting depth of argument for composite types'
/

comment on column DBA_ARGUMENTS.DATA_TYPE is 'Datatype of the argument'
/

comment on column DBA_ARGUMENTS.DEFAULTED is 'Is the argument defaulted?'
/

comment on column DBA_ARGUMENTS.DEFAULT_VALUE is 'Default value for the argument'
/

comment on column DBA_ARGUMENTS.DEFAULT_LENGTH is 'Length of default value for the argument'
/

comment on column DBA_ARGUMENTS.IN_OUT is 'Argument direction (IN, OUT, or IN/OUT)'
/

comment on column DBA_ARGUMENTS.DATA_LENGTH is 'Length of the column in bytes'
/

comment on column DBA_ARGUMENTS.DATA_PRECISION is 'Length: decimal digits (NUMBER) or binary digits (FLOAT)'
/

comment on column DBA_ARGUMENTS.DATA_SCALE is 'Digits to right of decimal point in a number'
/

comment on column DBA_ARGUMENTS.RADIX is 'Argument radix for a number'
/

comment on column DBA_ARGUMENTS.CHARACTER_SET_NAME is 'Character set name for the argument'
/

comment on column DBA_ARGUMENTS.TYPE_OWNER is 'Owner name for the argument type in case of object types'
/

comment on column DBA_ARGUMENTS.TYPE_NAME is 'Object name for the argument type in case of object types'
/

comment on column DBA_ARGUMENTS.TYPE_SUBNAME is 'Subordinate object name for the argument type in case of object types'
/

comment on column DBA_ARGUMENTS.TYPE_LINK is 'Database link name for the argument type in case of object types'
/

comment on column DBA_ARGUMENTS.TYPE_OBJECT_TYPE is 'Object type of the argument type'
/

comment on column DBA_ARGUMENTS.PLS_TYPE is 'PL/SQL type name for the argument'
/

comment on column DBA_ARGUMENTS.CHAR_LENGTH is 'Character limit for string datatypes'
/

comment on column DBA_ARGUMENTS.CHAR_USED is 'Is the byte limit (B) or char limit (C) official for this string?'
/

comment on column DBA_ARGUMENTS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

