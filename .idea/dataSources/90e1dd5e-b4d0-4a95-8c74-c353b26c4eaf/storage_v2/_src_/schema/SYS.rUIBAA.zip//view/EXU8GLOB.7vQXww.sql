create view EXU8GLOB (GLOBAL_NAME) as
SELECT  value$
        FROM    sys.props$
        WHERE   name = 'GLOBAL_DB_NAME'
/

