create view USER_HEAT_MAP_SEG_HISTOGRAM
            (OBJECT_NAME, SUBOBJECT_NAME, TRACK_TIME, SEGMENT_WRITE, FULL_SCAN, LOOKUP_SCAN) as
select o.name, o.subname, s.track_time,
   s.segment_write, s.full_scan, s.lookup_scan
from obj$ o, sys."_SYS_HEAT_MAP_SEG_HISTOGRAM" s
where o.owner#=userenv('SCHEMAID')
  and s.obj# = o.obj#
order by o.obj#
/

comment on table USER_HEAT_MAP_SEG_HISTOGRAM is 'Segment access information for segments owned by the user'
/

comment on column USER_HEAT_MAP_SEG_HISTOGRAM.TRACK_TIME is 'System time when the segment access was tracked'
/

comment on column USER_HEAT_MAP_SEG_HISTOGRAM.SEGMENT_WRITE is 'Segment has write access YES/NO'
/

comment on column USER_HEAT_MAP_SEG_HISTOGRAM.FULL_SCAN is 'Segment has full scan YES/NO'
/

comment on column USER_HEAT_MAP_SEG_HISTOGRAM.LOOKUP_SCAN is 'Segment has lookup scan YES/NO'
/

