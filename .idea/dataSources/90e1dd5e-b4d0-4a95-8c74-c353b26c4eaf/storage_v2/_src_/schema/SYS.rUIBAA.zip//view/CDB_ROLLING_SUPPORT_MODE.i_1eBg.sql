create view CDB_ROLLING_SUPPORT_MODE (OWNER, TABLE_NAME, SUPPORT_MODE, EXPLANATION, CON_ID) as
SELECT k."OWNER",k."TABLE_NAME",k."SUPPORT_MODE",k."EXPLANATION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ROLLING_SUPPORT_MODE") k
/

comment on table CDB_ROLLING_SUPPORT_MODE is 'List of all tables and their support_mode during DBMS_ROLLING upgrade in all containers'
/

comment on column CDB_ROLLING_SUPPORT_MODE.OWNER is 'Schema name of the table'
/

comment on column CDB_ROLLING_SUPPORT_MODE.TABLE_NAME is 'Name of the table'
/

comment on column CDB_ROLLING_SUPPORT_MODE.SUPPORT_MODE is 'Either SUPPORTED, UNSUPPORTED, or INTERNAL'
/

comment on column CDB_ROLLING_SUPPORT_MODE.EXPLANATION is 'Gives a reason when support_mode is not SUPPORTED'
/

comment on column CDB_ROLLING_SUPPORT_MODE.CON_ID is 'container id'
/

