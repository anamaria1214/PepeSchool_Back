create view CDB_AUTOTASK_OPERATION
            (CLIENT_NAME, OPERATION_NAME, OPERATION_TAG, PRIORITY_OVERRIDE, ATTRIBUTES, USE_RESOURCE_ESTIMATES, STATUS,
             LAST_CHANGE, CON_ID)
as
SELECT k."CLIENT_NAME",k."OPERATION_NAME",k."OPERATION_TAG",k."PRIORITY_OVERRIDE",k."ATTRIBUTES",k."USE_RESOURCE_ESTIMATES",k."STATUS",k."LAST_CHANGE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_AUTOTASK_OPERATION") k
/

comment on table CDB_AUTOTASK_OPERATION is 'Automated Maintenance Task Operation Configuration in all containers'
/

comment on column CDB_AUTOTASK_OPERATION.CLIENT_NAME is 'Name of Autotask Client'
/

comment on column CDB_AUTOTASK_OPERATION.OPERATION_NAME is 'Name of Autotask Client Operation'
/

comment on column CDB_AUTOTASK_OPERATION.OPERATION_TAG is 'Tag of Autotask Client Operation'
/

comment on column CDB_AUTOTASK_OPERATION.PRIORITY_OVERRIDE is 'Priority that will be used for all jobs performing the operation'
/

comment on column CDB_AUTOTASK_OPERATION.ATTRIBUTES is 'Operation attributes'
/

comment on column CDB_AUTOTASK_OPERATION.USE_RESOURCE_ESTIMATES is 'Specifies if resource usage estimates are used for the operation'
/

comment on column CDB_AUTOTASK_OPERATION.STATUS is 'Status of the operation'
/

comment on column CDB_AUTOTASK_OPERATION.LAST_CHANGE is 'Timestamp of the last change'
/

comment on column CDB_AUTOTASK_OPERATION.CON_ID is 'container id'
/

