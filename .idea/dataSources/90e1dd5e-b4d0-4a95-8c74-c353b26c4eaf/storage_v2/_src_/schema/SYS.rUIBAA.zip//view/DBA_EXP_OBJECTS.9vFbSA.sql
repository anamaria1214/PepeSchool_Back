create view DBA_EXP_OBJECTS (OWNER, OBJECT_NAME, OBJECT_TYPE, CUMULATIVE, INCREMENTAL, EXPORT_VERSION) as
select u.name, o.name,
       decode(o.type#, 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 6, 'SEQUENCE', 7, 'PROCEDURE',
                      8, 'FUNCTION', 9, 'PACKAGE', 11, 'PACKAGE BODY',
                      12, 'TRIGGER', 13, 'TYPE', 14, 'TYPE BODY',
                      22, 'LIBRARY', 28, 'JAVA SOURCE', 29, 'JAVA CLASS',
                      30, 'JAVA RESOURCE', 87, 'ASSEMBLY', 'UNDEFINED'),
       o.ctime, o.itime, o.expid
from sys.incexp o, sys.user$ u
where o.owner# = u.user#
/

comment on table DBA_EXP_OBJECTS is 'Objects that have been incrementally exported'
/

comment on column DBA_EXP_OBJECTS.OWNER is 'Owner of exported object'
/

comment on column DBA_EXP_OBJECTS.OBJECT_NAME is 'Name of exported object'
/

comment on column DBA_EXP_OBJECTS.OBJECT_TYPE is 'Type of exported object'
/

comment on column DBA_EXP_OBJECTS.CUMULATIVE is 'Timestamp of last cumulative export'
/

comment on column DBA_EXP_OBJECTS.INCREMENTAL is 'Timestamp of last incremental export'
/

comment on column DBA_EXP_OBJECTS.EXPORT_VERSION is 'The id of the export session'
/

