create view USER_XS_PASSWORD_LIMITS (RESOURCE_NAME, LIMIT) as
select
  m.name,
  decode(u.limit#,
         2147483647, decode(u.resource#, 4, 'NULL', 'UNLIMITED'),
         -1, 0,
         0, decode(p.limit#,
                   2147483647, decode(p.resource#, 4, 'NULL', 'UNLIMITED'),
                   -1, 0,
                   decode(p.resource#,
                          4, po.name,
                          1, trunc(p.limit#/86400, 4),
                          2, trunc(p.limit#/86400, 4),
                          5, trunc(p.limit#/86400, 4),
                          6, trunc(p.limit#/86400, 4),
                          7, trunc(p.limit#/86400, 4),
                          8, trunc(p.limit#/86400, 4),
                          p.limit#)),
         -- Bug 30180598: Schema qualify the PVF if owned by non-SYS user
         decode(u.resource#,
                4, decode(SYS_CONTEXT('USERENV','CON_NAME'),
                              'CDB$ROOT', decode(nvl(s2.name, 'SYS'), 'SYS',
                                          uo.name, s2.name || '.' || uo.name),
                              decode(bitand(n.flags,1), 1,
                                 'FROM ROOT', decode(nvl(s2.name, 'SYS'), 'SYS',
                                          uo.name, s2.name || '.' || uo.name))),
                1, trunc(u.limit#/86400, 4),
                2, trunc(u.limit#/86400, 4),
                5, trunc(u.limit#/86400, 4),
                6, trunc(u.limit#/86400, 4),
                7, trunc(u.limit#/86400, 4),
                8, trunc(u.limit#/86400, 4),
                u.limit#))
  from sys.profile$ u, sys.profile$ p, sys.obj$ uo, sys.obj$ po,
       sys.resource_map m, sys.rxs$sessions xsse, sys.xs$prin xspr,
       sys.profname$ n, sys.user$ s2
  where u.resource# = m.resource#
  and p.profile# = 0
  and p.resource# = u.resource#
  and u.type# = p.type#
  and p.type# = 1
  and m.type# = 1
  and uo.obj#(+) = u.limit#
  and po.obj#(+) = p.limit#
  and uo.owner# = s2.user# (+)
  and xsse.userid = xspr.prin#
  and u.profile# = xspr.profile#
  and u.profile# = n.profile#
  and xsse.sid = xs_sys_context('XS$SESSION', 'SESSION_ID')
  and BITAND(xsse.flag,32) = 32
/

comment on table USER_XS_PASSWORD_LIMITS is 'Display password limits for currently logged on application user'
/

comment on column USER_XS_PASSWORD_LIMITS.RESOURCE_NAME is 'Resource name'
/

comment on column USER_XS_PASSWORD_LIMITS.LIMIT is 'Limit placed on this resource'
/

