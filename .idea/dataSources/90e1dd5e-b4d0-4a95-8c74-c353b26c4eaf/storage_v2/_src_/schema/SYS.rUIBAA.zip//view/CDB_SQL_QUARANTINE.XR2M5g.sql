create view CDB_SQL_QUARANTINE
            (SIGNATURE, NAME, SQL_TEXT, PLAN_HASH_VALUE, CPU_TIME, IO_MEGABYTES, IO_REQUESTS, ELAPSED_TIME, IO_LOGICAL,
             CREATOR, ORIGIN, DESCRIPTION, CREATED, LAST_EXECUTED, ENABLED, AUTOPURGE, CON_ID)
as
SELECT k."SIGNATURE",k."NAME",k."SQL_TEXT",k."PLAN_HASH_VALUE",k."CPU_TIME",k."IO_MEGABYTES",k."IO_REQUESTS",k."ELAPSED_TIME",k."IO_LOGICAL",k."CREATOR",k."ORIGIN",k."DESCRIPTION",k."CREATED",k."LAST_EXECUTED",k."ENABLED",k."AUTOPURGE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SQL_QUARANTINE") k
/

comment on table CDB_SQL_QUARANTINE is ' in all containers'
/

comment on column CDB_SQL_QUARANTINE.SIGNATURE is 'unique SQL identifier generated from normalized SQL text'
/

comment on column CDB_SQL_QUARANTINE.NAME is 'unique plan identifier in string form as a search key'
/

comment on column CDB_SQL_QUARANTINE.SQL_TEXT is 'un-normalized SQL text'
/

comment on column CDB_SQL_QUARANTINE.PLAN_HASH_VALUE is 'unique plan identifier as a search key'
/

comment on column CDB_SQL_QUARANTINE.CPU_TIME is 'quarantine CPU time threshold in seconds'
/

comment on column CDB_SQL_QUARANTINE.IO_MEGABYTES is 'quarantine I/O megabytes threshold'
/

comment on column CDB_SQL_QUARANTINE.IO_REQUESTS is 'quarantine I/O requests threshold'
/

comment on column CDB_SQL_QUARANTINE.ELAPSED_TIME is 'quarantine elapsed time threshold in seconds'
/

comment on column CDB_SQL_QUARANTINE.IO_LOGICAL is 'quarantine I/O logical threshold'
/

comment on column CDB_SQL_QUARANTINE.ORIGIN is 'how thresholds were created'
/

comment on column CDB_SQL_QUARANTINE.DESCRIPTION is 'text description provided for plan baseline'
/

comment on column CDB_SQL_QUARANTINE.CREATED is 'time when SQL quarantine configuration was created'
/

comment on column CDB_SQL_QUARANTINE.LAST_EXECUTED is 'time when SQL quarantine configuration was last used'
/

comment on column CDB_SQL_QUARANTINE.ENABLED is 'enabled status of plan baseline'
/

comment on column CDB_SQL_QUARANTINE.AUTOPURGE is 'auto-purge status of plan baseline'
/

comment on column CDB_SQL_QUARANTINE.CON_ID is 'container id'
/

