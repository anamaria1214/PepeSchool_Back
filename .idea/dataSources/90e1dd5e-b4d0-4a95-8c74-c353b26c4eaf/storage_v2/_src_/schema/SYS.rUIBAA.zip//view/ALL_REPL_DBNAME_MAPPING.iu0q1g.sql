create view ALL_REPL_DBNAME_MAPPING (SOURCE_ROOT_NAME, SOURCE_DATABASE_NAME, SOURCE_CONTAINER_NAME) as
select
  source_root_name, source_database_name, source_container_name
from repl$_dbname_mapping
/

comment on table ALL_REPL_DBNAME_MAPPING is 'Details about the database name mapping'
/

comment on column ALL_REPL_DBNAME_MAPPING.SOURCE_ROOT_NAME is 'The fully qualified global name of the root container in a consolidated database where the LCRs originated'
/

comment on column ALL_REPL_DBNAME_MAPPING.SOURCE_DATABASE_NAME is 'The fully qualified global name of the database where the LCRs originated'
/

comment on column ALL_REPL_DBNAME_MAPPING.SOURCE_CONTAINER_NAME is 'The short container name of the database where the LCRs originated'
/

