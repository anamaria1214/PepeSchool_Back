create view CDB_APPLY_HANDLE_COLLISIONS
            (APPLY_NAME, OBJECT_OWNER, OBJECT_NAME, SOURCE_OBJECT_OWNER, SOURCE_OBJECT_NAME, ENABLED, SET_BY, CON_ID) as
SELECT k."APPLY_NAME",k."OBJECT_OWNER",k."OBJECT_NAME",k."SOURCE_OBJECT_OWNER",k."SOURCE_OBJECT_NAME",k."ENABLED",k."SET_BY",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_APPLY_HANDLE_COLLISIONS") k
/

comment on table CDB_APPLY_HANDLE_COLLISIONS is 'Details about apply collision handlers in all containers'
/

comment on column CDB_APPLY_HANDLE_COLLISIONS.APPLY_NAME is 'Name of the apply process'
/

comment on column CDB_APPLY_HANDLE_COLLISIONS.OBJECT_OWNER is 'Owner of the target object'
/

comment on column CDB_APPLY_HANDLE_COLLISIONS.OBJECT_NAME is 'Name of the target object'
/

comment on column CDB_APPLY_HANDLE_COLLISIONS.SOURCE_OBJECT_OWNER is 'Owner of the source object'
/

comment on column CDB_APPLY_HANDLE_COLLISIONS.SOURCE_OBJECT_NAME is 'Name of the source object'
/

comment on column CDB_APPLY_HANDLE_COLLISIONS.ENABLED is 'State of the collision handlers'
/

comment on column CDB_APPLY_HANDLE_COLLISIONS.SET_BY is 'Entity that set up the handler: USER, GOLDENGATE'
/

comment on column CDB_APPLY_HANDLE_COLLISIONS.CON_ID is 'container id'
/

