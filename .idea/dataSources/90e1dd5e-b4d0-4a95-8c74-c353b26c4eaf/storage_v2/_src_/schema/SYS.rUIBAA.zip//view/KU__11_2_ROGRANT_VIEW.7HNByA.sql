create view KU$_11_2_ROGRANT_VIEW
            (VERS_MAJOR, VERS_MINOR, GRANTEE_ID, GRANTEE, ROLE, ROLE_ID, ADMIN, SEQUENCE, USER_SPARE1) as
select * from ku$_rogrant_view r
      where r.role  NOT IN ('AUDIT_ADMIN',
                            'AUDIT_VIEWER')
/

