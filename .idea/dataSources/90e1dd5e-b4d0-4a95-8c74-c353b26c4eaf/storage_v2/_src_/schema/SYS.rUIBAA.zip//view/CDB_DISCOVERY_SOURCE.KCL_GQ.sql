create view CDB_DISCOVERY_SOURCE (SOURCE_NAME, SOURCE_TYPE, CTIME, CON_ID) as
SELECT k."SOURCE_NAME",k."SOURCE_TYPE",k."CTIME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_DISCOVERY_SOURCE") k
/

comment on table CDB_DISCOVERY_SOURCE is 'All source of sensitive data discovery in all containers'
/

comment on column CDB_DISCOVERY_SOURCE.SOURCE_NAME is 'The name of the source'
/

comment on column CDB_DISCOVERY_SOURCE.SOURCE_TYPE is 'The type of the discovery source - within DB or from ADM'
/

comment on column CDB_DISCOVERY_SOURCE.CTIME is 'The last time sensitive data was identified/imported from this source'
/

comment on column CDB_DISCOVERY_SOURCE.CON_ID is 'container id'
/

