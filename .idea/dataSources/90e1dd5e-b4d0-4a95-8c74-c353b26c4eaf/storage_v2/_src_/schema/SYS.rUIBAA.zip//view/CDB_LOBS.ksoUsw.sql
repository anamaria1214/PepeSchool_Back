create view CDB_LOBS
            (OWNER, TABLE_NAME, COLUMN_NAME, SEGMENT_NAME, TABLESPACE_NAME, INDEX_NAME, CHUNK, PCTVERSION, RETENTION,
             FREEPOOLS, CACHE, LOGGING, ENCRYPT, COMPRESSION, DEDUPLICATION, IN_ROW, FORMAT, PARTITIONED, SECUREFILE,
             SEGMENT_CREATED, RETENTION_TYPE, RETENTION_VALUE, VALUE_BASED, MAX_INLINE, CON_ID)
as
SELECT k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."SEGMENT_NAME",k."TABLESPACE_NAME",k."INDEX_NAME",k."CHUNK",k."PCTVERSION",k."RETENTION",k."FREEPOOLS",k."CACHE",k."LOGGING",k."ENCRYPT",k."COMPRESSION",k."DEDUPLICATION",k."IN_ROW",k."FORMAT",k."PARTITIONED",k."SECUREFILE",k."SEGMENT_CREATED",k."RETENTION_TYPE",k."RETENTION_VALUE",k."VALUE_BASED",k."MAX_INLINE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_LOBS") k
/

comment on table CDB_LOBS is 'Description of LOBs contained in all tables in all containers'
/

comment on column CDB_LOBS.OWNER is 'Owner of the table containing the LOB'
/

comment on column CDB_LOBS.TABLE_NAME is 'Name of the table containing the LOB'
/

comment on column CDB_LOBS.COLUMN_NAME is 'Name of the LOB column or attribute'
/

comment on column CDB_LOBS.SEGMENT_NAME is 'Name of the LOB segment'
/

comment on column CDB_LOBS.TABLESPACE_NAME is 'Name of the tablespace containing the LOB segment'
/

comment on column CDB_LOBS.INDEX_NAME is 'Name of the LOB index'
/

comment on column CDB_LOBS.CHUNK is 'Size of the LOB chunk as a unit of allocation/manipulation in bytes'
/

comment on column CDB_LOBS.PCTVERSION is 'Maximum percentage of the LOB space used for versioning'
/

comment on column CDB_LOBS.RETENTION is 'Maximum time duration for versioning of the LOB space'
/

comment on column CDB_LOBS.FREEPOOLS is 'Number of freepools for this LOB segment'
/

comment on column CDB_LOBS.CACHE is 'Is the LOB accessed through the buffer cache?'
/

comment on column CDB_LOBS.LOGGING is 'Are changes to the LOB logged?'
/

comment on column CDB_LOBS.ENCRYPT is 'Is this lob encrypted?'
/

comment on column CDB_LOBS.COMPRESSION is 'What level of compression is used for this lob?'
/

comment on column CDB_LOBS.DEDUPLICATION is 'What kind of deduplication is used for this lob?'
/

comment on column CDB_LOBS.IN_ROW is 'Are some of the LOBs stored with the base row?'
/

comment on column CDB_LOBS.FORMAT is 'Is the LOB storage format dependent on the endianness of the platform?'
/

comment on column CDB_LOBS.PARTITIONED is 'Is the LOB column in a partitioned table?'
/

comment on column CDB_LOBS.SECUREFILE is 'Is the LOB a SECUREFILE LOB?'
/

comment on column CDB_LOBS.SEGMENT_CREATED is 'Is the LOB segment created?'
/

comment on column CDB_LOBS.VALUE_BASED is 'Is the LOB column value based?'
/

comment on column CDB_LOBS.CON_ID is 'container id'
/

