create view ALL_APPLY_HANDLE_COLLISIONS
            (APPLY_NAME, OBJECT_OWNER, OBJECT_NAME, SOURCE_OBJECT_OWNER, SOURCE_OBJECT_NAME, ENABLED, SET_BY) as
select hc."APPLY_NAME",hc."OBJECT_OWNER",hc."OBJECT_NAME",hc."SOURCE_OBJECT_OWNER",hc."SOURCE_OBJECT_NAME",hc."ENABLED",hc."SET_BY"
from DBA_APPLY_HANDLE_COLLISIONS hc, ALL_APPLY a, all_tables t
where hc.apply_name = a.apply_name and hc.object_owner = t.owner
      and hc.object_name = t.table_name
/

comment on table ALL_APPLY_HANDLE_COLLISIONS is 'Details about apply collision handlers on objects visible to the user'
/

comment on column ALL_APPLY_HANDLE_COLLISIONS.APPLY_NAME is 'Name of the apply process'
/

comment on column ALL_APPLY_HANDLE_COLLISIONS.OBJECT_OWNER is 'Owner of the target object'
/

comment on column ALL_APPLY_HANDLE_COLLISIONS.OBJECT_NAME is 'Name of the target object'
/

comment on column ALL_APPLY_HANDLE_COLLISIONS.SOURCE_OBJECT_OWNER is 'Owner of the source object'
/

comment on column ALL_APPLY_HANDLE_COLLISIONS.SOURCE_OBJECT_NAME is 'Name of the source object'
/

comment on column ALL_APPLY_HANDLE_COLLISIONS.ENABLED is 'State of the collision handlers'
/

comment on column ALL_APPLY_HANDLE_COLLISIONS.SET_BY is 'Entity that set up the handler: USER, GOLDENGATE'
/

