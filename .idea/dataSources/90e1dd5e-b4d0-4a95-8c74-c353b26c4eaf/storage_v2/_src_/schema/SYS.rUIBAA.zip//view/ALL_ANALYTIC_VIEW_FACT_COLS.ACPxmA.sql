create view ALL_ANALYTIC_VIEW_FACT_COLS
            (OWNER, ANALYTIC_VIEW_NAME, TABLE_ALIAS, COLUMN_NAME, COLUMN_ALIAS, ORDER_NUM, ORIGIN_CON_ID) as
select OWNER,
       ANALYTIC_VIEW_NAME,
       TABLE_ALIAS,
       COLUMN_NAME,
       COLUMN_ALIAS,
       ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_AVIEW_FACT_COLS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

comment on table ALL_ANALYTIC_VIEW_FACT_COLS is 'Analytic view fact columns in the database'
/

comment on column ALL_ANALYTIC_VIEW_FACT_COLS.OWNER is 'Owner of the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_FACT_COLS.ANALYTIC_VIEW_NAME is 'Name of the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_FACT_COLS.TABLE_ALIAS is 'Alias of the table or view to which the column belongs'
/

comment on column ALL_ANALYTIC_VIEW_FACT_COLS.COLUMN_NAME is 'Column name in the table or view for this analytic view fact column'
/

comment on column ALL_ANALYTIC_VIEW_FACT_COLS.COLUMN_ALIAS is 'Column alias in the table or view for this analytic view fact column, or column name if not specified'
/

comment on column ALL_ANALYTIC_VIEW_FACT_COLS.ORDER_NUM is 'Order number of the fact column within the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_FACT_COLS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

