create view AWR_CDB_BUFFER_POOL_STAT
            (SNAP_ID, DBID, INSTANCE_NUMBER, ID, NAME, BLOCK_SIZE, SET_MSIZE, CNUM_REPL, CNUM_WRITE, CNUM_SET, BUF_GOT,
             SUM_WRITE, SUM_SCAN, FREE_BUFFER_WAIT, WRITE_COMPLETE_WAIT, BUFFER_BUSY_WAIT, FREE_BUFFER_INSPECTED,
             DIRTY_BUFFERS_INSPECTED, DB_BLOCK_CHANGE, DB_BLOCK_GETS, CONSISTENT_GETS, PHYSICAL_READS, PHYSICAL_WRITES,
             CON_DBID, CON_ID)
as
select bp.snap_id, bp.dbid, bp.instance_number,
       id, name, block_size, set_msize,
       cnum_repl, cnum_write, cnum_set, buf_got, sum_write, sum_scan,
       free_buffer_wait, write_complete_wait, buffer_busy_wait,
       free_buffer_inspected, dirty_buffers_inspected,
       db_block_change, db_block_gets, consistent_gets,
       physical_reads, physical_writes,
       decode(bp.con_dbid, 0, bp.dbid, bp.con_dbid),
       decode(bp.per_pdb, 0, 0,
         con_dbid_to_id(decode(bp.con_dbid, 0, bp.dbid, bp.con_dbid))) con_id
  from AWR_CDB_SNAPSHOT sn, WRH$_BUFFER_POOL_STATISTICS bp
  where     sn.snap_id         = bp.snap_id
        and sn.dbid            = bp.dbid
        and sn.instance_number = bp.instance_number
/

comment on table AWR_CDB_BUFFER_POOL_STAT is 'Buffer Pool Historical Statistics Information'
/

