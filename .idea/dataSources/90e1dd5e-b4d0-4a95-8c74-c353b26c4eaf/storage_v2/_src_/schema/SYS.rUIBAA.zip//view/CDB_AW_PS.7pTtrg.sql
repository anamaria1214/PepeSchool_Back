create view CDB_AW_PS (OWNER, AW_NUMBER, AW_NAME, PSNUMBER, GENERATIONS, MAXPAGES, CON_ID) as
SELECT k."OWNER",k."AW_NUMBER",k."AW_NAME",k."PSNUMBER",k."GENERATIONS",k."MAXPAGES",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_AW_PS") k
/

comment on table CDB_AW_PS is 'Pagespaces in Analytic Workspaces owned by the user in all containers'
/

comment on column CDB_AW_PS.OWNER is 'Owner of the Analytic Workspace'
/

comment on column CDB_AW_PS.AW_NAME is 'Name of the Analytic Workspace'
/

comment on column CDB_AW_PS.PSNUMBER is 'Number of the pagespace'
/

comment on column CDB_AW_PS.GENERATIONS is 'Number of active generations in the pagespace'
/

comment on column CDB_AW_PS.MAXPAGES is 'Maximum pages allocated in the pagespace'
/

comment on column CDB_AW_PS.CON_ID is 'container id'
/

