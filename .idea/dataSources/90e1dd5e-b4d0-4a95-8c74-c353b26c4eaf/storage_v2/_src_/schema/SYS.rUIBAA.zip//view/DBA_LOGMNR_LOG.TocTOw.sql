create view DBA_LOGMNR_LOG
            (LOGMNR_SESSION_ID, NAME, DBID, RESETLOGS_SCN, RESETLOGS_TIME, MODIFIED_TIME, THREAD#, SEQUENCE#, FIRST_SCN,
             NEXT_SCN, FIRST_TIME, NEXT_TIME, DICTIONARY_BEGIN, DICTIONARY_END, KEEP, SUSPECT)
as
select
                  l.session#                    logmnr_session_id,
                  l.file_name                   name,
                  l.db_id                       dbid,
                  l.resetlogs_change#           resetlogs_scn,
                  l.reset_timestamp             resetlogs_time,
                  l.timestamp                   modified_time,
                  l.thread#                     thread#,
                  l.sequence#                   sequence#,
                  l.first_change#               first_scn,
                  l.next_change#                next_scn,
                  l.first_time                  first_time,
                  l.next_time                   next_time,
                  l.dict_begin                  dictionary_begin,
                  l.dict_end                    dictionary_end,
                  case
                  when (bitand(l.status, 2) = 2) then
                   'NO'
                  else
                   'YES'
                  end                           keep,
                  case
                  when (bitand(l.status, 4) = 4) then
                   'YES'
                  else
                   'NO'
                  end                           suspect
                from system.logmnr_log$ l
                where bitand(l.flags, 16) != 16
/

