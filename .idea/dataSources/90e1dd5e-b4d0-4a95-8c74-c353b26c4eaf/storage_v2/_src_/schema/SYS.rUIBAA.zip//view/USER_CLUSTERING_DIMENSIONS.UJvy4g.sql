create view USER_CLUSTERING_DIMENSIONS (TABLE_NAME, DIMENSION_OWNER, DIMENSION_NAME) as
select d.TABLE_NAME, d.DIMENSION_OWNER, d.DIMENSION_NAME
from   DBA_CLUSTERING_DIMENSIONS d
WHERE  d.OWNER = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_CLUSTERING_DIMENSIONS is 'All dimension details about clustering tables owned by the user'
/

comment on column USER_CLUSTERING_DIMENSIONS.TABLE_NAME is 'Name of the clustering table'
/

