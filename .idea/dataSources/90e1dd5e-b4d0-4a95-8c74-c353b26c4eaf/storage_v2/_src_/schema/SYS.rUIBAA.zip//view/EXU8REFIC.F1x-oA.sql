create view EXU8REFIC
            (OBJID, OWNER, OWNERID, TNAME, ROWNER, RTNAME, CNAME, CNO, RCNO, ACTION, ENABLED, DEFER, PROPERTY, ROBJID,
             ROWNERID, REFTYPE, REFCONSTR, TYPE)
as
SELECT  "OBJID","OWNER","OWNERID","TNAME","ROWNER","RTNAME","CNAME","CNO","RCNO","ACTION","ENABLED","DEFER","PROPERTY","ROBJID","ROWNERID","REFTYPE","REFCONSTR","TYPE"
        FROM    sys.exu8ref
        WHERE   (ownerid, tname) IN (
                    SELECT  i.owner#, i.name
                    FROM    sys.incexp i, sys.incvid v
                    WHERE   i.expid > v.expid AND
                            i.type# = 2)
/

