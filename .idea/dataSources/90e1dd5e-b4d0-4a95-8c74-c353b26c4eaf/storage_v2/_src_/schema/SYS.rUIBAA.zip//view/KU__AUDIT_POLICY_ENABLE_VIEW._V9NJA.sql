create view KU$_AUDIT_POLICY_ENABLE_VIEW (POLICY_NUM, SCHEMA_OBJ, USER, WHEN_OPT, HOW_OPT) as
select
  ng.policy#,
  value(o),
  decode(ng.user#, -1, NULL,
        (select u.name from user$ u where  u.user#=ng.user#)) userid,
  ng."WHEN",
  ng."HOW"
from sys.audit_ng$ ng, ku$_schemaobj_view o
where o.obj_num=ng.policy#
/

