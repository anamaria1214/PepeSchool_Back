create view USER_HIER_COLUMNS
            (HIER_NAME, COLUMN_NAME, ROLE, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE,
             CHARACTER_SET_NAME, CHAR_COL_DECL_LENGTH, CHAR_USED, ORDER_NUM, ORIGIN_CON_ID)
as
select HIER_NAME, COLUMN_NAME, ROLE, DATA_TYPE, DATA_LENGTH,
       DATA_PRECISION, DATA_SCALE, NULLABLE, CHARACTER_SET_NAME,
       CHAR_COL_DECL_LENGTH, CHAR_USED,
       --DATA_TYPE_MOD,
       --DATA_TYPE_OWNER,
       --CHAR_LENGTH,
       --COLLATION,
       ORDER_NUM, ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_HIER_COLUMNS)
where owner = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_HIER_COLUMNS is 'Hierarchy columns in the database'
/

comment on column USER_HIER_COLUMNS.HIER_NAME is 'Name of hierarchy in the database'
/

comment on column USER_HIER_COLUMNS.COLUMN_NAME is 'Name of column'
/

comment on column USER_HIER_COLUMNS.ROLE is 'The role the attribute plays in the hierarchy.  One of: KEY, AKEY, or PROP'
/

comment on column USER_HIER_COLUMNS.DATA_TYPE is 'Datatype of the column'
/

comment on column USER_HIER_COLUMNS.DATA_LENGTH is 'Length of the column (in bytes)'
/

comment on column USER_HIER_COLUMNS.DATA_PRECISION is 'Decimal precision for NUMBER datatype; binary precision for
 FLOAT datatype, NULL for all other datatypes'
/

comment on column USER_HIER_COLUMNS.DATA_SCALE is 'Digits to right of decimal point in a number'
/

comment on column USER_HIER_COLUMNS.NULLABLE is 'Does column allow NULL values?'
/

comment on column USER_HIER_COLUMNS.CHARACTER_SET_NAME is 'Name of the character set: CHAR_CS or NCHAR_CS'
/

comment on column USER_HIER_COLUMNS.CHAR_COL_DECL_LENGTH is 'Declaration length of character type column'
/

comment on column USER_HIER_COLUMNS.CHAR_USED is 'B or C.  B indicates that the column uses BYTE length semantics.
 C indicates that the column uses CHAR length semantics. NULL indicates
 the datatype is not any of the following: CHAR, VARCHAR2, NCHAR, NVARCHAR2'
/

comment on column USER_HIER_COLUMNS.ORDER_NUM is 'Order of the column, with attributes first in the order of creation
 followed by hierarchical attributes.'
/

comment on column USER_HIER_COLUMNS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

