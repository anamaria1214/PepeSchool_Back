create view KU$_EDITION_TRIG_EXISTS_VIEW (OBJ_NUM, BASE_OBJ_NUM, SCHEMA) as
select t.obj#,t.baseobject,o.owner_name
 from   sys.ku$_edition_schemaobj_view o, sys.trigger$ t
  where  t.obj# = o.obj_num AND
         (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles WHERE role='SELECT_CATALOG_ROLE'))
/

