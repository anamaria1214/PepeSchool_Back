create view AWR_CDB_CON_SYSMETRIC_SUMM
            (SNAP_ID, DBID, INSTANCE_NUMBER, BEGIN_TIME, END_TIME, INTSIZE, GROUP_ID, METRIC_ID, METRIC_NAME,
             METRIC_UNIT, NUM_INTERVAL, MINVAL, MAXVAL, AVERAGE, STANDARD_DEVIATION, SUM_SQUARES, CON_DBID, CON_ID)
as
select m.snap_id, m.dbid, m.instance_number,
       begin_time, end_time, intsize,
       m.group_id, m.metric_id, mn.metric_name, mn.metric_unit,
       num_interval, minval, maxval, average, standard_deviation, sum_squares,
       decode(m.con_dbid, 0, m.dbid, m.con_dbid),
       con_dbid_to_id(decode(m.con_dbid, 0, m.dbid, m.con_dbid)) con_id
  from AWR_CDB_SNAPSHOT sn, WRH$_CON_SYSMETRIC_SUMMARY m, WRH$_METRIC_NAME mn
  where     m.group_id         = mn.group_id
        and m.metric_id        = mn.metric_id
        and m.dbid             = mn.dbid
        and sn.snap_id         = m.snap_id
        and sn.dbid            = m.dbid
        and sn.instance_number = m.instance_number
/

comment on table AWR_CDB_CON_SYSMETRIC_SUMM is 'PDB System Metrics Summary'
/

