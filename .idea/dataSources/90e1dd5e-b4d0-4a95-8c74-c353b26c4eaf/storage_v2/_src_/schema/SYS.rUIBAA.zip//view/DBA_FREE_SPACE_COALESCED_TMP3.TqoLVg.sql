create view DBA_FREE_SPACE_COALESCED_TMP3 (TS#, TOTAL_EXTENTS, TOTAL_BLOCKS) as
select /*+ ordered */ ktfbfetsn, count(*), sum(ktfbfeblks)
    from sys.x$ktfbfe
  group by ktfbfetsn
union all
  select /*+ ordered use_nl(e) */ ktfbuesegtsn, count(*), sum(ktfbueblks)
    from sys.ts$ ts , sys.recyclebin$ rb, sys.x$ktfbue e
    where ts.ts# = e.ktfbuesegtsn
      and e.ktfbuesegtsn = rb.ts#
      and e.ktfbuesegfno = rb.file#
      and e.ktfbuesegbno = rb.block#
      and ts.bitmapped <> 0
      and ts.online$ in (1,4)
      and ts.contents$ = 0
  group by ktfbuesegtsn
/

comment on column DBA_FREE_SPACE_COALESCED_TMP3.TS# is 'Number of Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP3.TOTAL_EXTENTS is 'Number of Free Extents in Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP3.TOTAL_BLOCKS is 'Total Free Blocks in Tablespace'
/

