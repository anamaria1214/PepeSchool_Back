create view KU$_AUDIT_OBJ_BASE_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, BASE_OBJ, AUDIT_VAL, AUDIT_LIST) as
select '1','0',
         o.obj_num,
         value(o),
         case when o.type_num = 2
        then (SELECT replace(t.audit$,chr(0),'-') from sys.tab$ t
              where t.obj# = o.obj_num)
        when o.type_num = 4
        then (SELECT replace(v.audit$,chr(0),'-') from sys.view$ v
              where v.obj# = o.obj_num)
        when o.type_num = 6
        then (SELECT replace(s.audit$,chr(0),'-') from sys.seq$ s
              where s.obj# = o.obj_num)
        when (o.type_num in (7, 9))
        then (SELECT replace(p.audit$,chr(0),'-') from sys.procedure$ p
              where p.obj# = o.obj_num)
        when o.type_num = 13
        then (SELECT replace(ty.audit$,chr(0),'-') from sys.type_misc$ ty
              where ty.obj#= o.obj_num)
        when o.type_num = 22
        then (SELECT replace(l.audit$,chr(0),'-') from sys.library$ l
              where l.obj# = o.obj_num)
        when o.type_num = 23
        then (SELECT replace(d.audit$,chr(0),'-') from sys.dir$ d
              where d.obj# = o.obj_num)
        when o.type_num = 150
        then (SELECT replace(h.audit$,chr(0),'-') from sys.hcs_hierarchy$ h
              where h.obj# = o.obj_num)
        when o.type_num = 151
        then (SELECT replace(d.audit$,chr(0),'-') from sys.hcs_dim$ d
              where d.obj# = o.obj_num)
        when o.type_num = 152
        then (SELECT replace(av.audit$,chr(0),'-')
              from sys.hcs_analytic_view$ av
              where av.obj# = o.obj_num)
        else null end,
         sys.dbms_metadata_util.get_audit(o.obj_num,o.type_num)
  from   ku$_schemaobj_view o
  where  bitand(o.flags,4)=0            -- exclude system-generated objects
/

