create view CDB_REDEFINITION_ERRORS
            (OBJECT_TYPE, OBJECT_OWNER, OBJECT_NAME, BASE_TABLE_OWNER, BASE_TABLE_NAME, DDL_TXT, EDITION_NAME, ERR_NO,
             ERR_TXT, CON_ID)
as
SELECT k."OBJECT_TYPE",k."OBJECT_OWNER",k."OBJECT_NAME",k."BASE_TABLE_OWNER",k."BASE_TABLE_NAME",k."DDL_TXT",k."EDITION_NAME",k."ERR_NO",k."ERR_TXT",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_REDEFINITION_ERRORS") k
/

comment on table CDB_REDEFINITION_ERRORS is ' in all containers'
/

comment on column CDB_REDEFINITION_ERRORS.OBJECT_TYPE is 'Type of the redefinition object'
/

comment on column CDB_REDEFINITION_ERRORS.OBJECT_OWNER is 'Owner of the redefinition object'
/

comment on column CDB_REDEFINITION_ERRORS.OBJECT_NAME is 'Name of the redefinition object'
/

comment on column CDB_REDEFINITION_ERRORS.BASE_TABLE_OWNER is 'Owner of the base table of the redefinition object'
/

comment on column CDB_REDEFINITION_ERRORS.BASE_TABLE_NAME is 'Name of the base table of the redefinition object'
/

comment on column CDB_REDEFINITION_ERRORS.DDL_TXT is 'DDL used to create the corresponding interim dependent object'
/

comment on column CDB_REDEFINITION_ERRORS.EDITION_NAME is 'Name of the edition that the redefinition object belongs to'
/

comment on column CDB_REDEFINITION_ERRORS.ERR_NO is 'Oracle Error Number corresponding to this error'
/

comment on column CDB_REDEFINITION_ERRORS.ERR_TXT is 'Oracle Error Text corresponding to this error'
/

comment on column CDB_REDEFINITION_ERRORS.CON_ID is 'container id'
/

