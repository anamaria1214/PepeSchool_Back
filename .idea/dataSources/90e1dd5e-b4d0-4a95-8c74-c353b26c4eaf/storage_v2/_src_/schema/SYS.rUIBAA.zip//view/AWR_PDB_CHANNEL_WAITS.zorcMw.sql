create view AWR_PDB_CHANNEL_WAITS
            (SNAP_ID, DBID, INSTANCE_NUMBER, CHANNEL, MESSAGES_PUBLISHED, WAIT_COUNT, WAIT_TIME_USEC, CON_DBID,
             CON_ID) as
select cw.snap_id, cw.dbid, cw.instance_number,
       channel, messages_published, wait_count, wait_time_usec,
       decode(cw.con_dbid, 0, cw.dbid, cw.con_dbid),
       decode(cw.per_pdb, 0, 0,
         con_dbid_to_id(decode(cw.con_dbid, 0, cw.dbid, cw.con_dbid))) con_id
  from AWR_PDB_SNAPSHOT sn, WRH$_CHANNEL_WAITS cw
  where     sn.snap_id         = cw.snap_id
        and sn.dbid            = cw.dbid
        and sn.instance_number = cw.instance_number
/

comment on table AWR_PDB_CHANNEL_WAITS is 'Channel Waits Information'
/

