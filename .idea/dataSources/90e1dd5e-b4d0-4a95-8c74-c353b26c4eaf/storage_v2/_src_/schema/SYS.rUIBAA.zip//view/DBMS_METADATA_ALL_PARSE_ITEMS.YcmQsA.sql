create view DBMS_METADATA_ALL_PARSE_ITEMS
            (OBJECT_TYPE, PARSE_ITEM, INTERNAL, ALTER_XML, FETCH_XML_CLOB, CONVERT, DESCRIPTION) as
select t.object_type, substr(t.param,5),
  decode(bitand(t.flags,1),1,'Y','N'),
  decode(bitand(t.flags,2),2,'Y','N'),
  decode(bitand(t.flags,4),4,'Y','N'),
  decode(bitand(t.flags,8),8,'Y','N'),
         t.description
  from dbms_metadata_tparams_base t
  where t.model = 'ORACLE'
    and t.transform = 'PARSE'
/

