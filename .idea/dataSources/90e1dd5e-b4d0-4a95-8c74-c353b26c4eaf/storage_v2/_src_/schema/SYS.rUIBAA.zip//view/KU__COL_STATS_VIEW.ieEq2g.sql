create view KU$_COL_STATS_VIEW
            (OBJ_NUM, INTCOL_NUM, DISTCNT, LOWVAL, LOWVAL_1000, HIVAL, HIVAL_1000, DENSITY, NULL_CNT, AVGCLN, CFLAGS,
             EAV, SAMPLE_SIZE, MINIMUM, MAXIMUM, SPARE1, HIST_GRAM_LIST)
as
select  hh.obj#, hh.intcol#, hh.distcnt,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then case when hh.lowval is null
                         then hh.lowval
                         else utl_raw.substr(hh.lowval, 1,
                                          least(UTL_RAW.LENGTH(hh.lowval), 32))
                         end
               else null
          end,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then hh.lowval
               else null
          end,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then case when hh.hival is null
                         then hh.hival
                         else utl_raw.substr(hh.hival, 1,
                                           least(UTL_RAW.LENGTH(hh.hival), 32))
                         end
               else null
          end,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then hh.hival
               else null
          end,
          hh.density, hh.null_cnt, hh.avgcln,
          bitand(hh.spare2, 3), bitand(hh.spare2, 4), hh.sample_size,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then hh.minimum
               else null
          end,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then hh.maximum
               else null
          end,
          hh.spare1,
          cast(multiset(select value(hv)
                        from   sys.ku$_histgrm_view hv
                        where  hv.obj_num = hh.obj#
                           and hv.intcol_num = hh.intcol#)
                        as ku$_histgrm_list_t)
  from    sys.obj$ o, sys.hist_head$ hh
  where   o.obj# = hh.obj#
/

