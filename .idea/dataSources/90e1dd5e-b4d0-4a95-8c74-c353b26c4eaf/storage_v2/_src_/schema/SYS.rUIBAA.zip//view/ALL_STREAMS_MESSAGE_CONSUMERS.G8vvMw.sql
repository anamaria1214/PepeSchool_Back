create view ALL_STREAMS_MESSAGE_CONSUMERS
            (STREAMS_NAME, QUEUE_NAME, QUEUE_OWNER, RULE_SET_NAME, RULE_SET_OWNER, NEGATIVE_RULE_SET_NAME,
             NEGATIVE_RULE_SET_OWNER, NOTIFICATION_TYPE, NOTIFICATION_ACTION, NOTIFICATION_CONTEXT)
as
select c."STREAMS_NAME",c."QUEUE_NAME",c."QUEUE_OWNER",c."RULE_SET_NAME",c."RULE_SET_OWNER",c."NEGATIVE_RULE_SET_NAME",c."NEGATIVE_RULE_SET_OWNER",c."NOTIFICATION_TYPE",c."NOTIFICATION_ACTION",c."NOTIFICATION_CONTEXT"
  from dba_streams_message_consumers c, all_queues q
 where c.queue_name = q.name
   and c.queue_owner = q.owner
   and ((c.rule_set_owner is null and c.rule_set_name is null) or
        ((c.rule_set_owner, c.rule_set_name) in
          (select r.rule_set_owner, r.rule_set_name
             from all_rule_sets r)))
   and ((c.negative_rule_set_owner is null and
         c.negative_rule_set_name is null) or
        ((c.negative_rule_set_owner, c.negative_rule_set_name) in
          (select r.rule_set_owner, r.rule_set_name
             from all_rule_sets r)))
/

comment on table ALL_STREAMS_MESSAGE_CONSUMERS is 'Streams messaging consumers visible to the current user'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.STREAMS_NAME is 'Name of the consumer'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.QUEUE_NAME is 'Name of the queue'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.QUEUE_OWNER is 'Owner of the queue'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.RULE_SET_NAME is 'Name of the rule set'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.NEGATIVE_RULE_SET_NAME is 'Name of the negative rule set'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.NEGATIVE_RULE_SET_OWNER is 'Owner of the negative rule set'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.NOTIFICATION_ACTION is 'Notification action'
/

comment on column ALL_STREAMS_MESSAGE_CONSUMERS.NOTIFICATION_CONTEXT is 'Context for the notification action'
/

