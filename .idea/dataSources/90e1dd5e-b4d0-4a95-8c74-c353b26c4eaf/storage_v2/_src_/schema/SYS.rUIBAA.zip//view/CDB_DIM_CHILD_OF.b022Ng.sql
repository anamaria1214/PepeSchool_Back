create view CDB_DIM_CHILD_OF
            (OWNER, DIMENSION_NAME, HIERARCHY_NAME, POSITION, CHILD_LEVEL_NAME, JOIN_KEY_ID, PARENT_LEVEL_NAME,
             CON_ID) as
SELECT k."OWNER",k."DIMENSION_NAME",k."HIERARCHY_NAME",k."POSITION",k."CHILD_LEVEL_NAME",k."JOIN_KEY_ID",k."PARENT_LEVEL_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_DIM_CHILD_OF") k
/

comment on table CDB_DIM_CHILD_OF is 'Representaion of a 1:n hierarchical relationship between a pair of levels in
 a dimension in all containers'
/

comment on column CDB_DIM_CHILD_OF.OWNER is 'Owner of the dimension'
/

comment on column CDB_DIM_CHILD_OF.DIMENSION_NAME is 'Name of the dimension'
/

comment on column CDB_DIM_CHILD_OF.HIERARCHY_NAME is 'Name of the hierarchy'
/

comment on column CDB_DIM_CHILD_OF.POSITION is 'Hierarchical position within this hierarchy, position 1 being
 the most detailed'
/

comment on column CDB_DIM_CHILD_OF.CHILD_LEVEL_NAME is 'Name of the child-side level of this 1:n relationship'
/

comment on column CDB_DIM_CHILD_OF.JOIN_KEY_ID is 'Keys that join child to the parent'
/

comment on column CDB_DIM_CHILD_OF.PARENT_LEVEL_NAME is 'Name of the parent-side level of this 1:n relationship'
/

comment on column CDB_DIM_CHILD_OF.CON_ID is 'container id'
/

