create view USER_HOST_ACES (HOST, LOWER_PORT, UPPER_PORT, PRIVILEGE, STATUS) as
select host, lower_port, upper_port, privilege,
       decode(status, 0, 'DENIED', 1, 'GRANTED', null)
  from (select h.host, h.lower_port, h.upper_port, xo.name privilege,
               sys_check_privilege(sys_xsid_to_raw(xo.id), h.acl#, null) status
          from sys.nacl$_host h, dba_xs_objects xo
         where nlssort(xo.owner, 'NLS_SORT=BINARY') =
               nlssort('SYS',    'NLS_SORT=BINARY')
           and xo.name in ('RESOLVE', 'CONNECT', 'HTTP', 'HTTP_PROXY', 'SMTP')
           and xo.type = 'PRIVILEGE')
 where status in (0, 1)
/

comment on table USER_HOST_ACES is 'Status of access control entries for user to access network hosts through PL/SQL host utility packages'
/

comment on column USER_HOST_ACES.HOST is 'Network host'
/

comment on column USER_HOST_ACES.LOWER_PORT is 'Lower bound of the port range'
/

comment on column USER_HOST_ACES.UPPER_PORT is 'Upper bound of the port range'
/

comment on column USER_HOST_ACES.PRIVILEGE is 'Privilege'
/

comment on column USER_HOST_ACES.STATUS is 'Privilege status'
/

