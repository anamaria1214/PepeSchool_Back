create view CDB_SCHEDULER_JOB_ROLES
            (OWNER, JOB_NAME, JOB_SUBNAME, JOB_CREATOR, DATABASE_ROLE, PROGRAM_OWNER, PROGRAM_NAME, JOB_TYPE,
             JOB_ACTION, JOB_CLASS, SCHEDULE_OWNER, SCHEDULE_NAME, SCHEDULE_TYPE, START_DATE, REPEAT_INTERVAL, END_DATE,
             LAST_START_DATE, ENABLED, STATE, COMMENTS, CON_ID)
as
SELECT k."OWNER",k."JOB_NAME",k."JOB_SUBNAME",k."JOB_CREATOR",k."DATABASE_ROLE",k."PROGRAM_OWNER",k."PROGRAM_NAME",k."JOB_TYPE",k."JOB_ACTION",k."JOB_CLASS",k."SCHEDULE_OWNER",k."SCHEDULE_NAME",k."SCHEDULE_TYPE",k."START_DATE",k."REPEAT_INTERVAL",k."END_DATE",k."LAST_START_DATE",k."ENABLED",k."STATE",k."COMMENTS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SCHEDULER_JOB_ROLES") k
/

comment on table CDB_SCHEDULER_JOB_ROLES is 'All scheduler jobs in the database by database role in all containers'
/

comment on column CDB_SCHEDULER_JOB_ROLES.OWNER is 'Owner of the scheduler job'
/

comment on column CDB_SCHEDULER_JOB_ROLES.JOB_NAME is 'Name of the scheduler job'
/

comment on column CDB_SCHEDULER_JOB_ROLES.JOB_SUBNAME is 'Subname of the scheduler job (for a job running a chain step)'
/

comment on column CDB_SCHEDULER_JOB_ROLES.PROGRAM_OWNER is 'Owner of the program associated with the job'
/

comment on column CDB_SCHEDULER_JOB_ROLES.PROGRAM_NAME is 'Name of the program associated with the job'
/

comment on column CDB_SCHEDULER_JOB_ROLES.JOB_TYPE is 'Inlined job action type'
/

comment on column CDB_SCHEDULER_JOB_ROLES.JOB_ACTION is 'Inlined job action'
/

comment on column CDB_SCHEDULER_JOB_ROLES.JOB_CLASS is 'Name of job class associated with the job'
/

comment on column CDB_SCHEDULER_JOB_ROLES.SCHEDULE_OWNER is 'Owner of the schedule that this job uses (can be a window or window group)'
/

comment on column CDB_SCHEDULER_JOB_ROLES.SCHEDULE_NAME is 'Name of the schedule that this job uses (can be a window or window group)'
/

comment on column CDB_SCHEDULER_JOB_ROLES.SCHEDULE_TYPE is 'Type of the schedule that this job uses'
/

comment on column CDB_SCHEDULER_JOB_ROLES.START_DATE is 'Original scheduled start date of this job (for an inlined schedule)'
/

comment on column CDB_SCHEDULER_JOB_ROLES.REPEAT_INTERVAL is 'Inlined schedule PL/SQL expression or calendar string'
/

comment on column CDB_SCHEDULER_JOB_ROLES.END_DATE is 'Date after which this job will no longer run (for an inlined schedule)'
/

comment on column CDB_SCHEDULER_JOB_ROLES.ENABLED is 'Whether the job is enabled'
/

comment on column CDB_SCHEDULER_JOB_ROLES.STATE is 'Current state of the job'
/

comment on column CDB_SCHEDULER_JOB_ROLES.COMMENTS is 'Comments on the job'
/

comment on column CDB_SCHEDULER_JOB_ROLES.CON_ID is 'container id'
/

