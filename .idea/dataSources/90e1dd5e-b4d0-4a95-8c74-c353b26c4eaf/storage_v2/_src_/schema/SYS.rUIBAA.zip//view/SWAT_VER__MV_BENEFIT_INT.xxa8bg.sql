create view SWAT_VER$_MV_BENEFIT_INT
            (MV_OWNER, MV_NAME, TASK_NAME, EXECUTION_TYPE, CM_IMPACT_B, PQ_COUNT_B, NQ_COUNT_B, FQ_COUNT_B, CM_IMPACT_C,
             PQ_COUNT_C, NQ_COUNT_C, FQ_COUNT_C, CM_IMPACT_E, PQ_COUNT_E, NQ_COUNT_E, FQ_COUNT_E)
as
SELECT   mv_owner,
         mv_name,
         task_name,
         execution_type,
         (case WHEN SUM(p_count_b)+SUM(n_count_b)> 0 THEN
           SUM(benefit_b)/(SUM(p_count_b)+SUM(n_count_b))
           ELSE 0 END) cm_impact_b,
         SUM(p_count_b) pq_count_b,
         SUM(n_count_b) nq_count_b,
         SUM(f_count_b) fq_count_b,
         (case WHEN SUM(p_count_c)+SUM(n_count_c) > 0 THEN
           SUM(benefit_c)/(SUM(p_count_c)+SUM(n_count_c))
           ELSE 0 END) cm_impact_c,
         SUM(p_count_c) pq_count_c,
         SUM(n_count_c) nq_count_c,
         SUM(f_count_c) fq_count_c,
         (case WHEN SUM(p_count_e)+SUM(n_count_e) > 0 THEN
           SUM(benefit_e)/(SUM(p_count_e)+SUM(n_count_e))
           ELSE 0 END) cm_impact_e,
         SUM(p_count_e) pq_count_e,
         SUM(n_count_e) nq_count_e,
         SUM(f_count_e) fq_count_e
FROM     sys.swat_ver$_mv_benefit_per_query
GROUP BY task_name, execution_type, mv_owner, mv_name
/

