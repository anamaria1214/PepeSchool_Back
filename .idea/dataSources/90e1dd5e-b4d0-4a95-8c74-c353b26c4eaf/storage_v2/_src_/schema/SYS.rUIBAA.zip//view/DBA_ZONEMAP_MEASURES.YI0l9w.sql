create view DBA_ZONEMAP_MEASURES (OWNER, ZONEMAP_NAME, MEASURE, POSITION_IN_SELECT, AGG_FUNCTION, AGG_COLUMN_NAME) as
select s.sowner, s.vname, a.aggtext, a.sumcolpos#,
       decode(a.aggfunction, 18, 'MIN', 19, 'MAX',
              17, 'COUNT', 16, 'SUM', 'ERROR-UNKNOWN'),
       c.name
from sys.user$ u, sys.sum$ w, sys.obj$ o, sys.snap$ s, sys.sumagg$ a, sys.col$ c
where w.containernam(+) = s.vname
  and o.obj#(+) = w.obj#
  and o.owner# = u.user#(+)
  and ((u.name = s.sowner) or (u.name IS NULL))
  and a.sumobj# = w.obj#
  and a.containercol# = c.col#
  and w.containerobj# = c.obj#
  and s.instsite = 0
  and bitand(s.flag3, 512) = 512                       /* snapshot = zonemap */
  and bitand(w.xpflags, 34359738368) = 34359738368      /* summary = zonemap */
  and a.aggfunction != 17                                 /* exclude COUNT() */
  and a.aggfunction != 16                                   /* exclude SUM() */
/

comment on table DBA_ZONEMAP_MEASURES is 'All zonemap measures in the database'
/

comment on column DBA_ZONEMAP_MEASURES.OWNER is 'Zonemap owner name'
/

comment on column DBA_ZONEMAP_MEASURES.ZONEMAP_NAME is 'Zonemap name'
/

comment on column DBA_ZONEMAP_MEASURES.MEASURE is 'Column whose MIN/MAX materialized'
/

comment on column DBA_ZONEMAP_MEASURES.POSITION_IN_SELECT is 'Ordinal position of measure aggregate'
/

comment on column DBA_ZONEMAP_MEASURES.AGG_FUNCTION is 'Type of aggregate function: MIN/MAX'
/

comment on column DBA_ZONEMAP_MEASURES.AGG_COLUMN_NAME is 'Aggregate column name in zonemap table'
/

