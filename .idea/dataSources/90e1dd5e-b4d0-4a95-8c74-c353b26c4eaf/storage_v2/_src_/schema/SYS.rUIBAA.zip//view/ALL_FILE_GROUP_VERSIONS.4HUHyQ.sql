create view ALL_FILE_GROUP_VERSIONS
            (FILE_GROUP_OWNER, FILE_GROUP_NAME, VERSION_NAME, VERSION, CREATOR, CREATED, COMMENTS, DEFAULT_DIRECTORY) as
select v.file_group_owner, v.file_group_name, v.version_name, v.version_id,
       v.creator, v.created, v.comments, v.default_directory
from "_ALL_FILE_GROUP_VERSIONS" v
/

comment on table ALL_FILE_GROUP_VERSIONS is 'Details about file group versions'
/

comment on column ALL_FILE_GROUP_VERSIONS.FILE_GROUP_OWNER is 'Owner of the file group'
/

comment on column ALL_FILE_GROUP_VERSIONS.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column ALL_FILE_GROUP_VERSIONS.VERSION_NAME is 'Name of the version'
/

comment on column ALL_FILE_GROUP_VERSIONS.VERSION is 'Internal version number'
/

comment on column ALL_FILE_GROUP_VERSIONS.CREATOR is 'Creator of the version'
/

comment on column ALL_FILE_GROUP_VERSIONS.CREATED is 'When the version was created'
/

comment on column ALL_FILE_GROUP_VERSIONS.COMMENTS is 'User specified comment'
/

comment on column ALL_FILE_GROUP_VERSIONS.DEFAULT_DIRECTORY is 'Default directory object'
/

