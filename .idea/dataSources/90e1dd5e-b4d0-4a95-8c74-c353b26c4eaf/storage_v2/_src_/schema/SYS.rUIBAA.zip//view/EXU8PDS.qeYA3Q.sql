create view EXU8PDS
            (OBJID, TYPE, OWNERID, PTYPE, SUBPTYPE, PFLAG, PCNT, PKCNT, PCTFREE$, PCTUSED$, INITRANS, MAXTRANS, INIEXTS,
             EXTSIZE, MINEXTS, MAXEXTS, EXTPCT, FLISTS, FREEGRP, TSNAME, DEFLOG, PCACHE)
as
SELECT  p.objid, p.type, p.ownerid, p.ptype, p.subptype, p.pflag,
                p.pcnt, p.pkcnt, p.pctfree$, p.pctused$, p.initrans,
                p.maxtrans,
                NVL(CEIL(p.iniexts * (p.blocksize / (
                    SELECT  t$.blocksize
                    FROM    sys.ts$ t$
                    WHERE   t$.ts# = 0))),
                    NULL),
                NVL(CEIL(p.extsize * (p.blocksize / (
                    SELECT  t$.blocksize
                    FROM    sys.ts$ t$
                    WHERE   t$.ts# = 0))),
                    NULL),
                p.minexts, p.maxexts, p.extpct, p.flists, p.freegrp, p.tsname,
                p.deflog, p.pcache
        FROM    sys.exu9pds p
/

