create view INT$DBA_AVIEW_ATTR_CLASS
            (OWNER, ANALYTIC_VIEW_NAME, DIMENSION_ALIAS, OWNER_ID, OBJECT_ID, OBJECT_TYPE, HIER_ALIAS, ATTRIBUTE_NAME,
             CLASSIFICATION, VALUE, LANGUAGE, ORDER_NUM, SHARING, ORIGIN_CON_ID)
as
select u.name owner,
       o.name ANALYTIC_VIEW_NAME,
       avd.alias DIMENSION_ALIAS,
       o.owner# OWNER_ID,
       o.obj# OBJECT_ID,
       o.type# OBJECT_TYPE,
       avh.hier_alias HIER_ALIAS,
       avc.col_name ATTRIBUTE_NAME,
       c.clsfction_name CLASSIFICATION,
       c.clsfction_value VALUE,
       c.clsfction_lang language,
       c.order_num ORDER_NUM,
       case when bitand(o.flags, 196608)>0 then 1 else 0 end sharing,
       to_number(sys_context('USERENV','CON_ID')) origin_con_id
from obj$ o, hcs_av_clsfctn$ c, user$ u, hcs_av_hier$ avh,
     hcs_av_dim$ avd, hcs_av_col$ avc
where o.owner# = u.user#
      and c.av# = o.obj#
      and avh.av# = c.av#
      and avd.av# = avh.av#
      and c.av_dim# = avh.av_dim#
      and avh.av_dim# = avd.av_dim#
      and c.av_hier# = avh.hier#
      and avc.av# = c.av#
      and avc.av_dim# = c.av_dim#
      and avc.av_hier# = c.av_hier#
      and avc.sub_obj# = c.sub_obj#
      and avc.sub_obj_type = c.obj_type
      and avc.role not in (5, 6)
      and c.obj_type in (4, 11) -- DIM OR HIER ATTRIBUTE
/

