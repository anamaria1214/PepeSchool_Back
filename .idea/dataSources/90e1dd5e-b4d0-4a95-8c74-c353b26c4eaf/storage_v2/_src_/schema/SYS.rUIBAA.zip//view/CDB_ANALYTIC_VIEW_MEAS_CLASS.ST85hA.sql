create view CDB_ANALYTIC_VIEW_MEAS_CLASS
            (OWNER, ANALYTIC_VIEW_NAME, MEASURE_NAME, CLASSIFICATION, VALUE, LANGUAGE, ORDER_NUM, ORIGIN_CON_ID,
             CON_ID) as
SELECT k."OWNER",k."ANALYTIC_VIEW_NAME",k."MEASURE_NAME",k."CLASSIFICATION",k."VALUE",k."LANGUAGE",k."ORDER_NUM",k."ORIGIN_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ANALYTIC_VIEW_MEAS_CLASS") k
/

comment on table CDB_ANALYTIC_VIEW_MEAS_CLASS is 'Analytic View measure classifications in the database in all containers'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.OWNER is 'Owner of the analytic view measure classification'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.ANALYTIC_VIEW_NAME is 'Name of owning analytic view of the measure'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.MEASURE_NAME is 'Name of owning measure of the classification'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.CLASSIFICATION is 'Name of analytic view measure classification'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.VALUE is 'Value of analytic view measure classification'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.LANGUAGE is 'Language of analytic view measure classification'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.ORDER_NUM is 'Order number of analytic view measure classification'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

comment on column CDB_ANALYTIC_VIEW_MEAS_CLASS.CON_ID is 'container id'
/

