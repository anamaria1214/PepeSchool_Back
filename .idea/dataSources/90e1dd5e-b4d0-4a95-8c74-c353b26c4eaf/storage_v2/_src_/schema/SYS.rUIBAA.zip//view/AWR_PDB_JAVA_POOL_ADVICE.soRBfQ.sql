create view AWR_PDB_JAVA_POOL_ADVICE
            (SNAP_ID, DBID, INSTANCE_NUMBER, JAVA_POOL_SIZE_FOR_ESTIMATE, JAVA_POOL_SIZE_FACTOR, ESTD_LC_SIZE,
             ESTD_LC_MEMORY_OBJECTS, ESTD_LC_TIME_SAVED, ESTD_LC_TIME_SAVED_FACTOR, ESTD_LC_LOAD_TIME,
             ESTD_LC_LOAD_TIME_FACTOR, ESTD_LC_MEMORY_OBJECT_HITS, CON_DBID, CON_ID)
as
select jp.snap_id, jp.dbid, jp.instance_number,
       java_pool_size_for_estimate, java_pool_size_factor,
       estd_lc_size, estd_lc_memory_objects,
       estd_lc_time_saved, estd_lc_time_saved_factor,
       estd_lc_load_time, estd_lc_load_time_factor,
       estd_lc_memory_object_hits,
       decode(jp.con_dbid, 0, jp.dbid, jp.con_dbid),
       decode(jp.per_pdb, 0, 0,
         con_dbid_to_id(decode(jp.con_dbid, 0, jp.dbid, jp.con_dbid))) con_id
  from AWR_PDB_SNAPSHOT sn, WRH$_JAVA_POOL_ADVICE jp
  where     sn.snap_id         = jp.snap_id
        and sn.dbid            = jp.dbid
        and sn.instance_number = jp.instance_number
/

comment on table AWR_PDB_JAVA_POOL_ADVICE is 'Java Pool Advice History'
/

