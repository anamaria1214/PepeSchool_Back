create view KU$_SYSCALLOUT_VIEW
            (VERS_MAJOR, VERS_MINOR, USER_NAME, OBJ_NUM, BASE_OBJ, TAG, PACKAGE, PKG_SCHEMA, LEVEL_NUM, CLASS, PREPOST,
             TS_NAME, TS_NUM, INCL_CONST, INCL_TRIG, INCL_GRANT, TTS_FULL_CHK, TTS_CLOSURE_CHK, IDX_PROP, TS_FLAGS)
as
select '1','0',
  null, null, null,
  p.tag, p.package, p.schema,
  p.level#, p.class, pr.prepost,
  null, null, null, null, null, null, null, null, null
  FROM  sys.ku$_exppkgact_view p , ku$_prepost_view pr
  where p.class =5
  order by p.level#
/

