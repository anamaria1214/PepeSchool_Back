create view AWR_PDB_RESOURCE_LIMIT
            (SNAP_ID, DBID, INSTANCE_NUMBER, RESOURCE_NAME, CURRENT_UTILIZATION, MAX_UTILIZATION, INITIAL_ALLOCATION,
             LIMIT_VALUE, CON_DBID, CON_ID)
as
select rl.snap_id, rl.dbid, rl.instance_number, resource_name,
       current_utilization, max_utilization, initial_allocation,
       limit_value,
       decode(rl.con_dbid, 0, rl.dbid, rl.con_dbid),
       decode(rl.per_pdb, 0, 0,
         con_dbid_to_id(decode(rl.con_dbid, 0, rl.dbid, rl.con_dbid))) con_id
  from AWR_PDB_SNAPSHOT sn, WRH$_RESOURCE_LIMIT rl
  where     sn.snap_id         = rl.snap_id
        and sn.dbid            = rl.dbid
        and sn.instance_number = rl.instance_number
/

comment on table AWR_PDB_RESOURCE_LIMIT is 'Resource Limit Historical Statistics Information'
/

