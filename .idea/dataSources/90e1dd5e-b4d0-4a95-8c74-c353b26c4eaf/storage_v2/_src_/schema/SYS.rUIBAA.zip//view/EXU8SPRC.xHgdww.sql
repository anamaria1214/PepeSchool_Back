create view EXU8SPRC (OWNERID, UNAME, ID, NAME, TIME, TYPEID, TYPE, AUDT, SQLVER) as
SELECT  s."OWNERID",s."UNAME",s."ID",s."NAME",s."TIME",s."TYPEID",s."TYPE",s."AUDT",s."SQLVER"
        FROM    sys.exu8spr s, sys.incexp i, sys.incvid v
        WHERE   s.name = i.name(+) AND
                s.ownerid = i.owner#(+) AND
                NVL(i.type#, 7) IN (7, 8, 9, 11) AND
                (NVL(i.ctime, TO_DATE('01-01-1900', 'DD-MM-YYYY')) < i.itime OR
                 NVL(i.expid, 9999) > v.expid)
/

