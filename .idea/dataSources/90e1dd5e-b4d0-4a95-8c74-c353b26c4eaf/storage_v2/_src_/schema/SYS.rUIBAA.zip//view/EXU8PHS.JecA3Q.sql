create view EXU8PHS (USERID, UNAME, PASSWORD, PASSWORD_DATE) as
SELECT  h.user#, u.name, h.password,
                to_char(h.password_date,'YYYY-MM-DD HH24:MI:SS')
        FROM    sys.user_history$ h, sys.user$ u
        WHERE   h.user# = u.user#
/

