create view AWR_PDB_IOSTAT_FILETYPE_NAME (DBID, FILETYPE_ID, FILETYPE_NAME, CON_DBID, CON_ID) as
select dbid,
       filetype_id,
       filetype_name,
       decode(con_dbid, 0, dbid, con_dbid),
       decode(con_dbid_to_id(dbid), 1, 0, con_dbid_to_id(dbid)) con_id
  from WRH$_IOSTAT_FILETYPE_NAME
/

comment on table AWR_PDB_IOSTAT_FILETYPE_NAME is 'File type names for historical I/O statistics'
/

