create view CDB_EDITION_COMMENTS (EDITION_NAME, COMMENTS, CON_ID) as
SELECT k."EDITION_NAME",k."COMMENTS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_EDITION_COMMENTS") k
/

comment on table CDB_EDITION_COMMENTS is 'Describes comments on all editions in the database in all containers'
/

comment on column CDB_EDITION_COMMENTS.EDITION_NAME is 'Name of the edition'
/

comment on column CDB_EDITION_COMMENTS.COMMENTS is 'Edition comments'
/

comment on column CDB_EDITION_COMMENTS.CON_ID is 'container id'
/

