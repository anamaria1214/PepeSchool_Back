create view USER_EDITIONING_VIEW_COLS_AE
            (VIEW_NAME, VIEW_COLUMN_ID, VIEW_COLUMN_NAME, TABLE_COLUMN_ID, TABLE_COLUMN_NAME, EDITION_NAME) as
select ev_obj.name,
       view_col.col#,
       view_col.name,
       tbl_col.col#,
       tbl_col.name
       , ev_obj.defining_edition
from   sys."_ACTUAL_EDITION_OBJ" ev_obj, sys.obj$ base_tbl_obj,
       sys.ev$ ev, sys.evcol$ ev_col, sys.col$ view_col, sys.col$ tbl_col
where  /* get all columns of a given EV */
       ev.ev_obj# = ev_col.ev_obj#
       /* join EVCOL$ to COL$ on EV id and column id to obtain EV column */
       /* name */
  and  ev_col.ev_obj# = view_col.obj#
  and  ev_col.ev_col_id = view_col.col#
       /* join EV$ to OBJ$ on base table owner id and base table name so we */
       /* can determine base table id */
  and  ev.base_tbl_owner# = base_tbl_obj.owner#
  and  ev.base_tbl_name   = base_tbl_obj.name
       /* exclude [sub]partitions by restricting base_tbl_obj.type# to */
       /* "table"; since COL$ will not contain rows for [sub]partitions, */
       /* this restriction is not, strictly speaking, necessary, but it */
       /* does ensure that the above join will return exactly one row */
  and base_tbl_obj.type# = 2
       /* join EVCOL$ row and OBJ$ row describing the EV's base table to */
       /* COL$ to obtain base table column id */
  and  base_tbl_obj.obj# = tbl_col.obj#
  and  ev_col.base_tbl_col_name = tbl_col.name
       /* join EV$ to _*_EDITION_OBJ on EV id so we can determine */
       /* name of the EV and ensure that the EV belongs to the current */
       /* schema */
  and  ev_obj.obj# = ev.ev_obj#
  and  ev_obj.owner# = userenv('SCHEMAID')
/

comment on table USER_EDITIONING_VIEW_COLS_AE is 'Relationship between columns of user''s Editioning Views and the table columns to which they map'
/

comment on column USER_EDITIONING_VIEW_COLS_AE.VIEW_NAME is 'Name of an Editioning View'
/

comment on column USER_EDITIONING_VIEW_COLS_AE.VIEW_COLUMN_ID is 'Column number within the Editioning View'
/

comment on column USER_EDITIONING_VIEW_COLS_AE.VIEW_COLUMN_NAME is 'The name of the column in the Editioning View'
/

comment on column USER_EDITIONING_VIEW_COLS_AE.TABLE_COLUMN_ID is 'Column number of a table column to which this EV column maps'
/

comment on column USER_EDITIONING_VIEW_COLS_AE.TABLE_COLUMN_NAME is 'Name of a table column to which this EV column maps'
/

comment on column USER_EDITIONING_VIEW_COLS_AE.EDITION_NAME is 'Name of the Application Edition where the Editioning View is defined'
/

