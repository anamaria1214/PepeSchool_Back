create view DBA_FREE_SPACE_COALESCED_TMP5 (TS#, TOTAL_EXTENTS, TOTAL_BLOCKS) as
select ts#, sum(total_extents), sum(total_blocks)
    from DBA_FREE_SPACE_COALESCED_TMP2
  group by ts#
/

comment on column DBA_FREE_SPACE_COALESCED_TMP5.TS# is 'Number of Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP5.TOTAL_EXTENTS is 'Number of Free Extents in Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP5.TOTAL_BLOCKS is 'Total Free Blocks in Tablespace'
/

