create view DBA_GOLDENGATE_RULES
            (COMPONENT_NAME, COMPONENT_TYPE, COMPONENT_RULE_TYPE, RULE_SET_OWNER, RULE_SET_NAME, RULE_SET_TYPE,
             RULE_OWNER, RULE_NAME, RULE_TYPE, RULE_CONDITION, SCHEMA_NAME, OBJECT_NAME, INCLUDE_TAGGED_LCR,
             SUBSETTING_OPERATION, DML_CONDITION, SOURCE_DATABASE, ORIGINAL_RULE_CONDITION, SAME_RULE_CONDITION,
             SOURCE_ROOT_NAME, SOURCE_CONTAINER_NAME)
as
select
  r1.streams_name component_name, r1.streams_type component_type,
  r1.streams_rule_type component_rule_type,
  r1.rule_set_owner, r1.rule_set_name, r1.rule_set_type,
  r1.rule_owner, r1.rule_name, r1.rule_type,
  cast(null as varchar2(1)) rule_condition,
  r1.schema_name, r1.object_name, r1.include_tagged_lcr,
  r1.subsetting_operation, r1.dml_condition, r1.source_database,
  r1.original_rule_condition, r1.same_rule_condition, r1.source_root_name,
  dm.source_container_name
from "_DBA_STREAMS_RULES_H2" r1, repl$_dbname_mapping dm
  where ((r1.streams_type = 'CAPTURE') or
         (r1.streams_type = 'APPLY')) and
        ((r1.streams_type, r1.streams_name) IN
      (select 'APPLY', apply_name from dba_apply
       where purpose in ('GoldenGate Capture', 'GoldenGate Apply')
         union
       select 'CAPTURE', capture_name from dba_capture
       where purpose = 'GoldenGate Capture')) and
       r1.source_root_name = dm.source_root_name(+) and
       r1.source_database = dm.source_database_name(+)
union
select streams_name component_name,
  decode(streams_type, 1, 'CAPTURE',
                       3, 'APPLY') component_type,
  decode(object_type, 1, 'TABLE',
                      2, 'SCHEMA',
                      3, 'GLOBAL',
                      4, 'PROCEDURE') component_rule_type,
       null rule_set_owner, null rule_set_name, null rule_set_type,
  rule_owner, rule_name,
  decode(rule_type, 1, 'DML',
                    2, 'DDL',
                    3, 'PROCEDURE') rule_type,
  cast(null as varchar2(1)) rule_condition, schema_name, object_name,
  decode(include_tagged_lcr, 0, 'NO',
                                     1, 'YES') include_tagged_lcr,
  null subsetting_operation, dml_condition, source_database,
  null original_rule_condition, null same_rule_condition,
  r1.source_root_name, source_container_name
  from sys.streams$_rules r1, repl$_dbname_mapping dm
  where rule_owner is null and
   r1.source_root_name = dm.source_root_name(+) and
   r1.source_database = dm.source_database_name(+)
/

comment on table DBA_GOLDENGATE_RULES is 'Details about the GoldenGate server rules'
/

comment on column DBA_GOLDENGATE_RULES.COMPONENT_NAME is 'Name of the GoldenGate process'
/

comment on column DBA_GOLDENGATE_RULES.COMPONENT_TYPE is 'Type of the GoldenGate process: CAPTURE or APPLY'
/

comment on column DBA_GOLDENGATE_RULES.COMPONENT_RULE_TYPE is 'For global, schema or table rules, type of rule: TABLE, SCHEMA or GLOBAL'
/

comment on column DBA_GOLDENGATE_RULES.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column DBA_GOLDENGATE_RULES.RULE_SET_NAME is 'Name of the rule set'
/

comment on column DBA_GOLDENGATE_RULES.RULE_SET_TYPE is 'Type of the rule set: POSITIVE or NEGATIVE'
/

comment on column DBA_GOLDENGATE_RULES.RULE_OWNER is 'Owner of the rule'
/

comment on column DBA_GOLDENGATE_RULES.RULE_NAME is 'Name of the rule'
/

comment on column DBA_GOLDENGATE_RULES.RULE_TYPE is 'For global, schema or table rules, type of rule: DML, DDL or PROCEDURE'
/

comment on column DBA_GOLDENGATE_RULES.RULE_CONDITION is 'Current rule condition'
/

comment on column DBA_GOLDENGATE_RULES.SCHEMA_NAME is 'For table and schema rules, the schema name'
/

comment on column DBA_GOLDENGATE_RULES.OBJECT_NAME is 'For table rules, the table name'
/

comment on column DBA_GOLDENGATE_RULES.INCLUDE_TAGGED_LCR is 'For global, schema or table rules, whether or not to include tagged LCRs'
/

comment on column DBA_GOLDENGATE_RULES.SUBSETTING_OPERATION is 'For subset rules, the type of operation: INSERT, UPDATE, or DELETE'
/

comment on column DBA_GOLDENGATE_RULES.DML_CONDITION is 'For subset rules, the row subsetting condition'
/

comment on column DBA_GOLDENGATE_RULES.SOURCE_DATABASE is 'For global, schema or table rules, the name of the database where the LCRs originated'
/

comment on column DBA_GOLDENGATE_RULES.ORIGINAL_RULE_CONDITION is 'For rules created by GoldenGate administrative APIs, the original rule condition when the rule was created'
/

comment on column DBA_GOLDENGATE_RULES.SAME_RULE_CONDITION is 'For rules created by GoldenGate administrative APIs, whether or not the current rule condition is the same as the original rule condition'
/

comment on column DBA_GOLDENGATE_RULES.SOURCE_ROOT_NAME is 'Root Database where the transactions originated'
/

comment on column DBA_GOLDENGATE_RULES.SOURCE_CONTAINER_NAME is 'The short container name of the database where the LCRs originated'
/

