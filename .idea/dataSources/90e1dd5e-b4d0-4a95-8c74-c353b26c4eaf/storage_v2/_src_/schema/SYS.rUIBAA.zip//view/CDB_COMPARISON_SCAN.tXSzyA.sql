create view CDB_COMPARISON_SCAN
            (OWNER, COMPARISON_NAME, SCAN_ID, PARENT_SCAN_ID, ROOT_SCAN_ID, STATUS, CURRENT_DIF_COUNT,
             INITIAL_DIF_COUNT, COUNT_ROWS, SCAN_NULLS, LAST_UPDATE_TIME, CON_ID)
as
SELECT k."OWNER",k."COMPARISON_NAME",k."SCAN_ID",k."PARENT_SCAN_ID",k."ROOT_SCAN_ID",k."STATUS",k."CURRENT_DIF_COUNT",k."INITIAL_DIF_COUNT",k."COUNT_ROWS",k."SCAN_NULLS",k."LAST_UPDATE_TIME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_COMPARISON_SCAN") k
/

comment on table CDB_COMPARISON_SCAN is 'Details about a comparison scan in all containers'
/

comment on column CDB_COMPARISON_SCAN.OWNER is 'Owner of comparison'
/

comment on column CDB_COMPARISON_SCAN.COMPARISON_NAME is 'Name of comparison'
/

comment on column CDB_COMPARISON_SCAN.SCAN_ID is 'Scan id of scan'
/

comment on column CDB_COMPARISON_SCAN.PARENT_SCAN_ID is 'Immediate parent scan''s scan id'
/

comment on column CDB_COMPARISON_SCAN.ROOT_SCAN_ID is 'Scan_id of the root (top-most) parent'
/

comment on column CDB_COMPARISON_SCAN.STATUS is 'Status of scan: SUC, BUCKET DIF, FINAL BUCKET DIF, ROW DIF'
/

comment on column CDB_COMPARISON_SCAN.CURRENT_DIF_COUNT is 'Current cumulative (incl children) dif count of scan'
/

comment on column CDB_COMPARISON_SCAN.INITIAL_DIF_COUNT is 'Initial cumulative (incl children) dif count of scan'
/

comment on column CDB_COMPARISON_SCAN.COUNT_ROWS is 'Number of rows in the scan'
/

comment on column CDB_COMPARISON_SCAN.SCAN_NULLS is 'Whether NULLs are part of this scan'
/

comment on column CDB_COMPARISON_SCAN.LAST_UPDATE_TIME is 'The time that this row was updated'
/

comment on column CDB_COMPARISON_SCAN.CON_ID is 'container id'
/

