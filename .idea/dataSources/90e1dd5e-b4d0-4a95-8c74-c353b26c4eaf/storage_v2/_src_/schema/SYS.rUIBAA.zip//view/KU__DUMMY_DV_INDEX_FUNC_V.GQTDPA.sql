create view KU$_DUMMY_DV_INDEX_FUNC_V (VERS_MAJOR, VERS_MINOR, OBJECT_NAME) as
select '0','0',NULL
    from dual
   where 1=0      -- return 0 rows
/

