create view CDB_AUTOTASK_CLIENT_JOB
            (CLIENT_NAME, JOB_NAME, JOB_SCHEDULER_STATUS, TASK_NAME, TASK_TARGET_TYPE, TASK_TARGET_NAME, TASK_PRIORITY,
             TASK_OPERATION, CON_ID)
as
SELECT k."CLIENT_NAME",k."JOB_NAME",k."JOB_SCHEDULER_STATUS",k."TASK_NAME",k."TASK_TARGET_TYPE",k."TASK_TARGET_NAME",k."TASK_PRIORITY",k."TASK_OPERATION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_AUTOTASK_CLIENT_JOB") k
/

comment on table CDB_AUTOTASK_CLIENT_JOB is 'Current automated maintenance jobs in all containers'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.CLIENT_NAME is 'Client name'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.JOB_NAME is 'Job name'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.JOB_SCHEDULER_STATUS is 'Jobs Scheduling Status'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.TASK_NAME is 'Program associated with the job'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.TASK_TARGET_TYPE is 'Kind of target being processed'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.TASK_TARGET_NAME is 'Name of target'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.TASK_PRIORITY is 'Task level prority'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.TASK_OPERATION is 'Operation name'
/

comment on column CDB_AUTOTASK_CLIENT_JOB.CON_ID is 'container id'
/

