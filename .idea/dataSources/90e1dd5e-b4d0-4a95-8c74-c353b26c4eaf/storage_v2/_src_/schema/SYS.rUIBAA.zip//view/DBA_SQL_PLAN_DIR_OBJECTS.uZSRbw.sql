create view DBA_SQL_PLAN_DIR_OBJECTS (DIRECTIVE_ID, OWNER, OBJECT_NAME, SUBOBJECT_NAME, OBJECT_TYPE, NUM_ROWS, NOTES) as
SELECT
    d.dir_id,
    u.name,
    o.name,
    c.name,
    'COLUMN',
    NULL,
    NULL
FROM
    sys."_BASE_OPT_DIRECTIVE" d,
    sys."_BASE_OPT_FINDING_OBJ_COL" ft,
    (select obj#, owner#, name from sys.obj$
     union all
     select object_id obj#, 0 owner#, name from  v$fixed_table) o,
    (select obj#, intcol#, name from sys.col$
     union all
     select kqfcotob obj#, kqfcocno intcol#, kqfconam name
     from sys.x$kqfco) c,
    sys.user$ u
WHERE
    d.f_id = ft.f_id and ft.f_obj# = o.obj# and o.owner# = u.user#
    and o.obj# = c.obj# and ft.intcol# = c.intcol#
union all
SELECT
    d.dir_id,
    u.name,
    o.name,
    NULL,
    'TABLE',
    fo.nrows,
    fo.notes
FROM
    sys."_BASE_OPT_DIRECTIVE" d,
    sys."_BASE_OPT_FINDING_OBJ" fo,
    (select obj#, owner#, name from sys.obj$
     union all
     select object_id obj#, 0 owner#, name from  v$fixed_table) o,
    sys.user$ u
WHERE
    d.f_id = fo.f_id and fo.f_obj# = o.obj# and o.owner# = u.user#
union all
-- Directives that store DS result have an object of type SQL
-- STATEMENT (which represents the DS Sql Statement). The following
-- branch gives the sqlid of that SQL.
SELECT
    d.dir_id,
    null,
    dbms_spd_internal.ub8_to_sqlid(fo.f_obj#),
    NULL,
    'SQL STATEMENT',
    NULL,
    NULL
FROM
    sys."_BASE_OPT_DIRECTIVE" d,
    sys."_BASE_OPT_FINDING_OBJ" fo
WHERE
    d.f_id = fo.f_id and d.type = 'DYNAMIC_SAMPLING_RESULT' and
    fo.obj_type = 4
union all
-- Directives that store DS result have an object of type
-- SQL STATEMENT ENVIRONMENT (which is the signature of the enviornment
-- that affects the result of DS Sql Statement like bind values).
-- The following branch gives that signature.
SELECT
    d.dir_id,
    null,
    dbms_spd_internal.ub8_to_sqlid(fo.f_obj#),
    NULL,
    'SQL STATEMENT ENVIRONMENT',
    NULL,
    NULL
FROM
    sys."_BASE_OPT_DIRECTIVE" d,
    sys."_BASE_OPT_FINDING_OBJ" fo
WHERE
    d.f_id = fo.f_id and d.type = 'DYNAMIC_SAMPLING_RESULT' and
    fo.obj_type = 5
/

comment on table DBA_SQL_PLAN_DIR_OBJECTS is 'Set of objects in sql plan directive'
/

comment on column DBA_SQL_PLAN_DIR_OBJECTS.DIRECTIVE_ID is 'The identifier of the sql plan directive'
/

comment on column DBA_SQL_PLAN_DIR_OBJECTS.OWNER is 'The username of the owner of the object in the sql plan directive'
/

comment on column DBA_SQL_PLAN_DIR_OBJECTS.OBJECT_NAME is 'The name of the object in the sql plan directive'
/

comment on column DBA_SQL_PLAN_DIR_OBJECTS.SUBOBJECT_NAME is 'The name of the sub-object (for example column) in the sql plan directive'
/

comment on column DBA_SQL_PLAN_DIR_OBJECTS.OBJECT_TYPE is 'The type of the (sub-)object in the sql plan directive'
/

comment on column DBA_SQL_PLAN_DIR_OBJECTS.NUM_ROWS is 'The number of rows in the object when directive is created'
/

comment on column DBA_SQL_PLAN_DIR_OBJECTS.NOTES is 'Other notes about the object'
/

