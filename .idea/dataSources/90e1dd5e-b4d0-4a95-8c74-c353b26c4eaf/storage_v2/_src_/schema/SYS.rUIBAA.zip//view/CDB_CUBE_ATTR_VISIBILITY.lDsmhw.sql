create view CDB_CUBE_ATTR_VISIBILITY
            (OWNER, DIMENSION_NAME, ATTRIBUTE_NAME, HIERARCHY_NAME, LEVEL_NAME, FROM_TYPE, TO_TYPE, CON_ID) as
SELECT k."OWNER",k."DIMENSION_NAME",k."ATTRIBUTE_NAME",k."HIERARCHY_NAME",k."LEVEL_NAME",k."FROM_TYPE",k."TO_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CUBE_ATTR_VISIBILITY") k
/

comment on table CDB_CUBE_ATTR_VISIBILITY is 'OLAP Attributes visible for Dimensions, Hierarchies, and Levels in all containers'
/

comment on column CDB_CUBE_ATTR_VISIBILITY.OWNER is 'Owner of OLAP Attribute'
/

comment on column CDB_CUBE_ATTR_VISIBILITY.DIMENSION_NAME is 'Name of the OLAP Cube Dimension that owns the OLAP Attribute'
/

comment on column CDB_CUBE_ATTR_VISIBILITY.ATTRIBUTE_NAME is 'Name of the OLAP Attribute'
/

comment on column CDB_CUBE_ATTR_VISIBILITY.HIERARCHY_NAME is 'Name of the OLAP Hierarchy for which the Attribute is visible'
/

comment on column CDB_CUBE_ATTR_VISIBILITY.LEVEL_NAME is 'Name of the OLAP Level for which the Attribute is visible'
/

comment on column CDB_CUBE_ATTR_VISIBILITY.FROM_TYPE is 'Object type on which the visibility has been explicitly set'
/

comment on column CDB_CUBE_ATTR_VISIBILITY.TO_TYPE is 'Object type on which the visibility has been implicitly derived'
/

comment on column CDB_CUBE_ATTR_VISIBILITY.CON_ID is 'container id'
/

