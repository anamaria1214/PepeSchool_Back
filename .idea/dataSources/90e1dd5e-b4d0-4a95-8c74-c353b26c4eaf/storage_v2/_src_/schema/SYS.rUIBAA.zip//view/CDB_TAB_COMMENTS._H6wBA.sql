create view CDB_TAB_COMMENTS (OWNER, TABLE_NAME, TABLE_TYPE, COMMENTS, ORIGIN_CON_ID, CON_ID) as
SELECT k."OWNER",k."TABLE_NAME",k."TABLE_TYPE",k."COMMENTS",k."ORIGIN_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_TAB_COMMENTS") k
/

comment on table CDB_TAB_COMMENTS is 'Comments on all tables and views in the database in all containers'
/

comment on column CDB_TAB_COMMENTS.OWNER is 'Owner of the object'
/

comment on column CDB_TAB_COMMENTS.TABLE_NAME is 'Name of the object'
/

comment on column CDB_TAB_COMMENTS.TABLE_TYPE is 'Type of the object'
/

comment on column CDB_TAB_COMMENTS.COMMENTS is 'Comment on the object'
/

comment on column CDB_TAB_COMMENTS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

comment on column CDB_TAB_COMMENTS.CON_ID is 'container id'
/

