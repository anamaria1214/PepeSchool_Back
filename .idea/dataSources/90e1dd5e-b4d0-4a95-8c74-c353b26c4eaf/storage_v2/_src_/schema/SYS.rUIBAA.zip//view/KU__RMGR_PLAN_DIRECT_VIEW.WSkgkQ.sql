create view KU$_RMGR_PLAN_DIRECT_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, BASE_OBJ, GROUP_OR_SUBPLAN, TYPE, CPU_P1, CPU_P2, CPU_P3, CPU_P4, CPU_P5,
             CPU_P6, CPU_P7, CPU_P8, ACTIVE_SESS_POOL_P1, QUEUEING_P1, PARALLEL_DEGREE_LIMIT_P1, SWITCH_GROUP,
             SWITCH_TIME, SWITCH_ESTIMATE, MAX_EST_EXEC_TIME, UNDO_POOL, COMMENTS, STATUS, MANDATORY)
as
select '1','0',
         r.obj#,
         (select value(o) from  sys.ku$_schemaobj_view o where
             o.obj_num=r.obj#),
         r.group_or_subplan,
         r.is_subplan,
         decode(r.mgmt_p1,4294967295,0,r.mgmt_p1),
         decode(r.mgmt_p2,4294967295,0,r.mgmt_p2),
         decode(r.mgmt_p3,4294967295,0,r.mgmt_p3),
         decode(r.mgmt_p4,4294967295,0,r.mgmt_p4),
         decode(r.mgmt_p5,4294967295,0,r.mgmt_p5),
         decode(r.mgmt_p6,4294967295,0,r.mgmt_p6),
         decode(r.mgmt_p7,4294967295,0,r.mgmt_p7),
         decode(r.mgmt_p8,4294967295,0,r.mgmt_p8),
         decode(r.active_sess_pool_p1,4294967295,0,r.active_sess_pool_p1),
         decode(r.queueing_p1,4294967295,0,r.queueing_p1),
         decode(r.parallel_degree_limit_p1,4294967295,0,
                r.parallel_degree_limit_p1),
         r.switch_group,
         decode(r.switch_time,4294967295,0,r.switch_time),
         decode(r.switch_estimate,4294967295,0,r.switch_estimate),
         decode(r.max_est_exec_time,4294967295,0,r.max_est_exec_time),
         decode(r.undo_pool,4294967295,0,r.undo_pool),
         r.description, r.status, r.mandatory
  from resource_plan_directive$ r
  where status not like '%FLAT'
/

