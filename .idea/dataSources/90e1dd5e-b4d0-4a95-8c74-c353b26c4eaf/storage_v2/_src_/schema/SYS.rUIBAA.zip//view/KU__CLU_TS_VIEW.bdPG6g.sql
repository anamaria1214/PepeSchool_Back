create view KU$_CLU_TS_VIEW (OWNER_NUM, OBJ_NUM, TS_NAME) as
select o.owner#, cl.obj#, ts.name
  from   sys.obj$ o, sys.clu$ cl, sys.ts$ ts
  where  cl.ts#  = ts.ts#
  and    o.obj# = cl.obj#
  and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles WHERE role='SELECT_CATALOG_ROLE'))
/

