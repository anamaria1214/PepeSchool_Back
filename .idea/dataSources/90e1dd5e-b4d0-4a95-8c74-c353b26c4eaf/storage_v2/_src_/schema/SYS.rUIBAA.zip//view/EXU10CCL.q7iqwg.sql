create view EXU10CCL (OWNERID, OWNERNAME, CNO, COLNAME, COLNO, INTCOL, PROPERTY, NOLOG) as
SELECT  o.owner#, u.name, cc.con#,
                DECODE(BITAND(c.property, 1), 1, at.name, c.name),
                cc.pos#, c.intcol#, c.property,
                DECODE(BITAND(cc.spare1, 1), 1, 1, 0)
        FROM    sys.obj$ o, sys.col$ c, sys.ccol$ cc, sys.attrcol$ at,
                sys.user$ u
        WHERE   o.obj# = cc.obj# AND
                o.owner# = u.user# AND
                c.obj# = cc.obj# AND
                c.intcol# = cc.intcol# AND
                BITAND(c.property, 2097152) = 0 AND               /* Not REA */
                BITAND(c.property, 1024) = 0 AND                /* Not SETID */
                c.obj# = at.obj# (+) AND
                c.intcol# = at.intcol# (+) AND
                NOT EXISTS (
                    SELECT  owner, name
                    FROM    sys.noexp$ ne
                    WHERE   ne.owner = u.name AND
                            ne.name = o.name AND
                            ne.obj_type = 2)
 UNION /* Nested Tables - SETID column */
        SELECT  o.owner#, u.name, cc.con#,
                DECODE(BITAND(c.property, 1), 1, at.name, c.name),
                cc.pos#, c.intcol#, c.property,
                DECODE(BITAND(cc.spare1, 1), 1, 1, 0)
        FROM    sys.obj$ o, sys.col$ c, sys.ccol$ cc, sys.attrcol$ at,
                sys.user$ u, sys.col$ cn
        WHERE   o.obj# = cc.obj# AND
                o.owner# = u.user# AND
                cn.obj# = cc.obj# AND
                cn.intcol# = cc.intcol# AND
                BITAND(cn.property, 1024) = 1024 AND                /* SETID */
                c.obj# = cc.obj# AND
                c.col# = cn.col# AND
                c.intcol# = (cn.intcol# - 1) AND
                c.segcol# = 0 AND
                c.obj# = at.obj# (+) AND
                c.intcol# = at.intcol# (+) AND
                NOT EXISTS (
                    SELECT  owner, name
                    FROM    sys.noexp$ ne
                    WHERE   ne.owner = u.name AND
                            ne.name = o.name AND
                            ne.obj_type = 2)
 UNION /* REFs - REF attribute columns */
        SELECT  o.owner#, u.name, cc.con#,
                DECODE(BITAND(rc.property, 1), 1, at.name, rc.name),
                cc.pos#, rc.intcol#, rc.property,
                DECODE(BITAND(cc.spare1, 1), 1, 1, 0)
        FROM    sys.obj$ o, sys.col$ c, sys.ccol$ cc, sys.attrcol$ at,
                sys.user$ u, sys.coltype$ ct, sys.col$ rc
        WHERE   o.obj# = cc.obj# AND
                o.owner# = u.user# AND
                c.obj# = cc.obj# AND
                c.intcol# = cc.intcol# AND
                BITAND(c.property, 2097152) = 2097152 AND             /* REA */
                ct.obj# = cc.obj# AND
                ct.col# = cc.col# AND
                UTL_RAW.CAST_TO_BINARY_INTEGER(SUBSTRB(ct.intcol#s, 1,2), 3) =
                  cc.intcol# AND            /* first list col# = constr col# */
                rc.obj# = cc.obj# AND
                rc.intcol# = ct.intcol# AND
                rc.obj# = at.obj# (+) AND
                rc.intcol# = at.intcol# (+) AND
                NOT EXISTS (
                    SELECT  owner, name
                    FROM    sys.noexp$ ne
                    WHERE   ne.owner = u.name AND
                            ne.name = o.name AND
                            ne.obj_type = 2)
/

