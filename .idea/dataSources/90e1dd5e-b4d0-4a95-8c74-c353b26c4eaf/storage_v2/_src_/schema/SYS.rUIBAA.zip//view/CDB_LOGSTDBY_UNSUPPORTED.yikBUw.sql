create view CDB_LOGSTDBY_UNSUPPORTED (OWNER, TABLE_NAME, COLUMN_NAME, ATTRIBUTES, DATA_TYPE, CON_ID) as
SELECT k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."ATTRIBUTES",k."DATA_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_LOGSTDBY_UNSUPPORTED") k
/

comment on table CDB_LOGSTDBY_UNSUPPORTED is 'List of all the columns that are not supported by Logical Standby in all containers'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED.OWNER is 'Schema name of unsupported column'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED.TABLE_NAME is 'Table name of unsupported column'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED.COLUMN_NAME is 'Column name of unsupported column'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED.ATTRIBUTES is 'If not a data type issue, gives the reason why the table is unsupported'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED.DATA_TYPE is 'Datatype of unsupported column'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED.CON_ID is 'container id'
/

