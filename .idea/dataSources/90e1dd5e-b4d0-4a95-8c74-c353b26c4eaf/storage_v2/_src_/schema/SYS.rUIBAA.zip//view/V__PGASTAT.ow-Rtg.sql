create view V_$PGASTAT (NAME, VALUE, UNIT, CON_ID) as
select "NAME","VALUE","UNIT","CON_ID" from v$pgastat
/

