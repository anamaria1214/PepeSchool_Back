create view CDB_PROFILES
            (PROFILE, RESOURCE_NAME, RESOURCE_TYPE, LIMIT, COMMON, INHERITED, IMPLICIT, ORACLE_MAINTAINED, MANDATORY,
             CON_ID) as
SELECT k."PROFILE",k."RESOURCE_NAME",k."RESOURCE_TYPE",k."LIMIT",k."COMMON",k."INHERITED",k."IMPLICIT",k."ORACLE_MAINTAINED",k."MANDATORY",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_PROFILES") k
/

comment on table CDB_PROFILES is 'Display all profiles and their limits in all containers'
/

comment on column CDB_PROFILES.PROFILE is 'Profile name'
/

comment on column CDB_PROFILES.RESOURCE_NAME is 'Resource name'
/

comment on column CDB_PROFILES.LIMIT is 'Limit placed on this resource for this profile'
/

comment on column CDB_PROFILES.COMMON is 'Is this a common profile?'
/

comment on column CDB_PROFILES.INHERITED is 'Was profile definition inherited from another container'
/

comment on column CDB_PROFILES.IMPLICIT is 'Was this profile created by an implicit application'
/

comment on column CDB_PROFILES.ORACLE_MAINTAINED is 'Denotes whether the profile was created by Oracle-supplied scripts. These profiles are local to all Pluggable Databases (PDBs) of a multi-tenant container database and can be changed inside the PDBs to suit individual Application requirements'
/

comment on column CDB_PROFILES.MANDATORY is 'Denotes whether the password profile limits are mandatorily enforced in a Pluggable Database (PDB). It is valid only for multitenant container database (CDB)'
/

comment on column CDB_PROFILES.CON_ID is 'container id'
/

