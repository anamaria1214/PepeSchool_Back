create view UMF_SCHEMA_XMLTYPE (SYS_NC_ROWINFO$) as
SELECT XMLElement("UMF_SCHEMA",
        /* Root element for umf$_topology */
        XMLElement("TOPOLOGY",
                    /* Aggregation of XML Elements, one for each row */
                    (SELECT XMLAgg(XMLElement("TOPOLOGY_INST",
                               /* XMLForest corresponds to the table columns */
                                        XMLForest(topology_name,
                                                  target_id,
                                                  topology_version,
                                                  topology_state)))
                     FROM umf$_topology)),
        /* Root element for umf$_registration */
        XMLElement("REGISTRATION",
                    /* Aggregation of XML Elements, one for each row */
                    (SELECT XMLAgg(XMLElement("REGISTRATION_INST",
                               /* XMLForest corresponds to the table columns */
                                        XMLForest(topology_name,
                                                  node_name,
                                                  node_id,
                                                  node_type,
                                                  as_source,
                                                  as_candidate_target,
                                                  state)))
                     FROM umf$_registration)),
        /* Root element for umf$_link */
        XMLElement("LINK",
                    /* Aggregation of XML Elements, one for each row */
                    (SELECT XMLAgg(XMLElement("LINK_INST",
                               /* XMLForest corresponds to the table columns */
                                        XMLForest(topology_name,
                                                  from_node_id,
                                                  to_node_id,
                                                  link_name)))
                     FROM umf$_link)),
        /* Root element for umf$_service */
        XMLElement("SERVICE",
                    /* Aggregation of XML Elements, one for each row */
                    (SELECT XMLAgg(XMLElement("SERVICE_INST",
                               /* XMLForest corresponds to the table columns */
                                        XMLForest(topology_name,
                                                  node_id,
                                                  service_id)))
                     FROM umf$_service))
)
AS "result" FROM dual
/

