create view DBA_SQL_PATCHES
            (NAME, CATEGORY, SIGNATURE, SQL_TEXT, CREATED, LAST_MODIFIED, DESCRIPTION, STATUS, FORCE_MATCHING, TASK_ID,
             TASK_EXEC_NAME, TASK_OBJ_ID, TASK_FND_ID, TASK_REC_ID)
as
SELECT
    so.name, so.category, so.signature, st.sql_text,
    ad.created, ad.last_modified, ad.description,
    DECODE(BITAND(so.flags, 1), 1, 'ENABLED', 'DISABLED'),
    DECODE(BITAND(sq.flags, 1), 1, 'YES', 'NO'),
    ad.task_id, ad.task_exec_name, ad.task_obj_id, ad.task_fnd_id,
    ad.task_rec_id
FROM
    sqlobj$        so,
    sqlobj$auxdata ad,
    sql$text       st,
    sql$           sq
WHERE
    so.signature = st.signature AND
    so.signature = ad.signature AND
    so.category  = ad.category  AND
    so.signature = sq.signature AND
    so.obj_type = 3 AND
    ad.obj_type = 3
/

comment on table DBA_SQL_PATCHES is 'set of sql patches'
/

comment on column DBA_SQL_PATCHES.NAME is 'name of sql patch'
/

comment on column DBA_SQL_PATCHES.CATEGORY is 'category of sql patch'
/

comment on column DBA_SQL_PATCHES.SIGNATURE is 'unique identifier generated from normalized SQL text'
/

comment on column DBA_SQL_PATCHES.SQL_TEXT is 'un-normalized SQL text'
/

comment on column DBA_SQL_PATCHES.CREATED is 'date stamp when sql patch created'
/

comment on column DBA_SQL_PATCHES.LAST_MODIFIED is 'date stamp when sql patch was last modified'
/

comment on column DBA_SQL_PATCHES.DESCRIPTION is 'text description provided for sql patch'
/

comment on column DBA_SQL_PATCHES.STATUS is 'enabled/disabled status of sql patch'
/

comment on column DBA_SQL_PATCHES.FORCE_MATCHING is 'signature is force matching or exact matching'
/

comment on column DBA_SQL_PATCHES.TASK_ID is 'advisor task id that generated the sql patch'
/

comment on column DBA_SQL_PATCHES.TASK_EXEC_NAME is 'advisor execution name for the sql patch'
/

comment on column DBA_SQL_PATCHES.TASK_OBJ_ID is 'advisor object id for the sql patch'
/

comment on column DBA_SQL_PATCHES.TASK_FND_ID is 'advisor finding id for the sql patch'
/

comment on column DBA_SQL_PATCHES.TASK_REC_ID is 'advisor recommendation id for the sql patch'
/

