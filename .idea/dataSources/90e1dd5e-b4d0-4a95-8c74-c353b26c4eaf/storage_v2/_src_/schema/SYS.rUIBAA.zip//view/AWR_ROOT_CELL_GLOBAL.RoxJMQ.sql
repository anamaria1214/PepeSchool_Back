create view AWR_ROOT_CELL_GLOBAL
            (SNAP_ID, DBID, CELL_HASH, INCARNATION_NUM, METRIC_ID, METRIC_NAME, METRIC_VALUE, CON_DBID, CON_ID) as
select s.snap_id, s.dbid, s.cell_hash, s.incarnation_num,
       s.metric_id, nm.metric_name, s.metric_value,
       decode(s.con_dbid, 0, s.dbid, s.con_dbid),
       decode(s.per_pdb, 0, 0,
         con_dbid_to_id(decode(s.con_dbid, 0, s.dbid, s.con_dbid))) con_id
from WRH$_CELL_GLOBAL s,
     WRH$_CELL_METRIC_DESC nm,
    (select distinct snap_id, dbid
       from AWR_ROOT_SNAPSHOT) sn
where      s.metric_id        = nm.metric_id
      and  s.dbid             = nm.dbid
      and  s.snap_id          = sn.snap_id
      and  s.dbid             = sn.dbid
/

comment on table AWR_ROOT_CELL_GLOBAL is 'Cell Global Statistics Information'
/

