create view CDB_APPLY_EXECUTE (RULE_OWNER, RULE_NAME, EXECUTE_EVENT, CON_ID) as
SELECT k."RULE_OWNER",k."RULE_NAME",k."EXECUTE_EVENT",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_APPLY_EXECUTE") k
/

comment on table CDB_APPLY_EXECUTE is 'Details about the apply execute action in all containers'
/

comment on column CDB_APPLY_EXECUTE.RULE_OWNER is 'Owner of the rule'
/

comment on column CDB_APPLY_EXECUTE.RULE_NAME is 'Name of the rule'
/

comment on column CDB_APPLY_EXECUTE.EXECUTE_EVENT is 'Whether the event satisfying the rule is executed'
/

comment on column CDB_APPLY_EXECUTE.CON_ID is 'container id'
/

