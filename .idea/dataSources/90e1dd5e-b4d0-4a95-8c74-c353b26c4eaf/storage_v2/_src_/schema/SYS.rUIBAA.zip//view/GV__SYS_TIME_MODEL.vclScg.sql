create view GV_$SYS_TIME_MODEL (INST_ID, STAT_ID, STAT_NAME, VALUE, CON_ID) as
select "INST_ID","STAT_ID","STAT_NAME","VALUE","CON_ID" from gv$sys_time_model
/

