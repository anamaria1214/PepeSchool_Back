create view DBA_CDB_RSRC_PLAN_DIRECTIVES
            (PLAN, PLUGGABLE_DATABASE, PROFILE, DIRECTIVE_TYPE, SHARES, UTILIZATION_LIMIT, PARALLEL_SERVER_LIMIT,
             MEMORY_MIN, MEMORY_LIMIT, COMMENTS, STATUS, MANDATORY)
as
select cdb_plan,
decode(directive_type, 'PROFILE', NULL, pdb),
decode(directive_type, 'PROFILE', pdb, NULL),
directive_type,
decode(shares, 4294967295, to_number(null), shares),
decode(utilization_limit, 4294967295, to_number(null), 100, to_number(null),
      utilization_limit),
decode(parallel_server_limit, 4294967295,
       to_number(null), 100, to_number(null), parallel_server_limit),
decode(memory_min, 4294967295, to_number(null), 0, to_number(null), memory_min),
decode(memory_limit, 4294967295, to_number(null), 100, to_number(null), memory_limit),
description,
decode(status,'PENDING',status, NULL),
decode(mandatory, 1, 'YES', 'NO')
from cdb_resource_plan_directive$
where sys_context('userenv', 'con_id') = 1
/

comment on table DBA_CDB_RSRC_PLAN_DIRECTIVES is 'all the CDB resource plan directives'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.PLAN is 'Name of the CDB plan to which this directive belongs'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.PLUGGABLE_DATABASE is 'Name of the pluggable database referred to'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.PROFILE is 'Name of database profile referred to'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.DIRECTIVE_TYPE is 'Type of CDB directive: PDB, PROFILE, AUTOTASK, or DEFAULT_DIRECTIVE'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.SHARES is 'Resource allocation for this pluggable database, expressed in shares'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.UTILIZATION_LIMIT is 'maximum resource utilization allowed, expressed in percentage'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.PARALLEL_SERVER_LIMIT is 'maximum percentage of the parallel target used before queueing subsequent
parallel queries'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.MEMORY_MIN is 'minimum memory available, expressed in percentage'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.MEMORY_LIMIT is 'maximum memory allowed, expressed in percentage'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.COMMENTS is 'Text comment on the plan directive'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.STATUS is 'PENDING if it is part of the pending area, NULL otherwise'
/

comment on column DBA_CDB_RSRC_PLAN_DIRECTIVES.MANDATORY is 'Whether the plan directive is mandatory'
/

