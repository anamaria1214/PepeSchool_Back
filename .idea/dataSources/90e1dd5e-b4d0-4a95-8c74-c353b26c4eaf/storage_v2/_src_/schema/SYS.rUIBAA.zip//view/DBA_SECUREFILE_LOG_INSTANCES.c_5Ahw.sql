create view DBA_SECUREFILE_LOG_INSTANCES
            (GUID, USER_NAME, LOG_NAME, LOG_ID, INST, SPLIT, FIXED_SIZE, FLUSH, MEM_READ, MAX_BUCKET_NO, NUM_BUCKETS,
             INC_SCN, INC_TIME, CRT_SCN, CRT_TIME, INC#)
as
select i.guid, u.name, d.name, d.log#, i.inst#,
         decode(bitand(i.flags, 8), 8, 'NO-SPLIT', 'SPLIT'),
         decode(bitand(i.flags, 16), 16, 'FIXED_MSG', 'VARIABLE_MSG'),
         decode(bitand(i.flags, 64), 64, 'BACKGROUND_FLUSH',
                'FOREGROUND_FLUSH'),
         decode(bitand(i.flags, 256), 256, 'ALLOW_MEM_READS', 'NO_MEM_READS'),
         i.max_bucket#, i.num_buckets, i.inc_scn, i.inc_time,
         i.crt_scn, i.crt_time, i.inc#
         from cli_log$ d, cli_inst$ i, user$ u
          where d.log# = i.log#
          and   i.user# = u.user#
/

