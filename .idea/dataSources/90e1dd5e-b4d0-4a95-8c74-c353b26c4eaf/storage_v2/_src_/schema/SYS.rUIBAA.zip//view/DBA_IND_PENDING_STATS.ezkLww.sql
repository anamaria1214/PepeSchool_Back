create view DBA_IND_PENDING_STATS
            (OWNER, INDEX_NAME, TABLE_OWNER, TABLE_NAME, PARTITION_NAME, SUBPARTITION_NAME, BLEVEL, LEAF_BLOCKS,
             DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY, AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, NUM_ROWS, SAMPLE_SIZE,
             LAST_ANALYZED)
as
select u.name, o.name, ut.name, ot.name, o.subname, null,
         h.blevel, h.leafcnt, h.distkey, h.lblkkey, h.dblkkey,
         h.clufac, h.rowcnt, h.samplesize, h.analyzetime
  from   sys.user$ u,  sys.obj$ o,  sys.ind$ i,
         sys.user$ ut, sys.obj$ ot, sys.wri$_optstat_ind_history h
  where  u.user# = o.owner#   -- user(i) X obj(i)
    and  o.obj#  = i.obj#     -- obj(i)  X ind
    and  h.obj#  = i.obj#     -- stat    X ind
    and  i.bo#   = ot.obj#    -- ind     X obj(t)
    and  ut.user# = ot.owner# -- user(t) X obj(t)
    and  o.namespace = 4 and o.remoteowner IS NULL and o.linkname IS NULL
    and  i.type# in (1, 2, 3, 4, 6, 7, 8)
    and  bitand(i.flags, 4096) = 0  -- not a fake index
    and  h.savtime = timestamp '3000-12-01 01:00:00 -0:0'
  union all
  -- partitions
  select u.name, o.name, ut.name, ot.name, o.subname, null,
         h.blevel, h.leafcnt, h.distkey, h.lblkkey, h.dblkkey,
         h.clufac, h.rowcnt, h.samplesize, h.analyzetime
  from   sys.user$ u,  sys.obj$ o,  sys.ind$ i, indpart$ ip,
         sys.user$ ut, sys.obj$ ot, sys.wri$_optstat_ind_history h
  where  u.user# = o.owner#   -- user(i) X obj(i)
    and  ip.bo# = i.obj#
    and  h.obj# = ip.obj#
    and  i.bo#  = ot.obj#
    and  o.obj# = ip.obj#
    and  ut.user# = ot.owner#
    and  o.namespace = 4 and o.remoteowner IS NULL and o.linkname IS NULL
    and  i.type# in (1, 2, 3, 4, 6, 7, 8)
    and  bitand(i.flags, 4096) = 0  -- not a fake index
    and  h.savtime = timestamp '3000-12-01 01:00:00 -0:0'
  union all
  select u.name, o.name, ut.name, ot.name, o.subname, null,
         h.blevel, h.leafcnt, h.distkey, h.lblkkey, h.dblkkey,
         h.clufac, h.rowcnt, h.samplesize, h.analyzetime
  from   sys.user$ u,  sys.obj$ o,  sys.ind$ i, indcompart$ ip,
         sys.user$ ut, sys.obj$ ot, sys.wri$_optstat_ind_history h
  where  u.user# = o.owner#   -- user(i) X obj(i)
    and  ip.bo# = i.obj#
    and  h.obj# = ip.obj#
    and  i.bo#  = ot.obj#
    and  o.obj# = ip.obj#
    and  ut.user# = ot.owner#
    and  o.namespace = 4 and o.remoteowner IS NULL and o.linkname IS NULL
    and  i.type# in (1, 2, 3, 4, 6, 7, 8)
    and  bitand(i.flags, 4096) = 0  -- not a fake index
    and  h.savtime = timestamp '3000-12-01 01:00:00 -0:0'
  union all
  -- sub partitions
  select ui.name, oi.name, ut.name, ot.name, os.name, os.subname,
         h.blevel, h.leafcnt, h.distkey, h.lblkkey, h.dblkkey,
         h.clufac, h.rowcnt, h.samplesize, h.analyzetime
  from   sys.obj$ os, sys.indsubpart$ isp, sys.indcompart$ icp,
         sys.user$ ut, sys.obj$ ot,
         sys.obj$ oi,  sys.ind$ i, sys.user$ ui,
         sys.wri$_optstat_ind_history h
  where  ui.user# = oi.owner#
    and  os.obj#  = isp.obj#
    and  h.obj#   = isp.obj#
    and  isp.pobj#= icp.obj#
    and  icp.bo#  = i.obj#
    and  oi.obj#  = i.obj#
    and  i.bo#    = ot.obj#
    and  ut.user# = ot.owner#
    and  oi.type# = 1
    and  os.type# = 35
    and  ot.type# = 2
    and  os.namespace = 4 and os.remoteowner IS NULL and os.linkname IS NULL
    and  i.type# in (1, 2, 3, 4, 6, 7, 8)
    and  bitand(i.flags, 4096) = 0  -- not a fake index
    and  h.savtime = timestamp '3000-12-01 01:00:00 -0:0'
/

comment on table DBA_IND_PENDING_STATS is 'Pending statistics of indexes, partitions, and subpartitions'
/

comment on column DBA_IND_PENDING_STATS.OWNER is 'Index owner name'
/

comment on column DBA_IND_PENDING_STATS.INDEX_NAME is 'Index name'
/

comment on column DBA_IND_PENDING_STATS.TABLE_OWNER is 'Table owner name'
/

comment on column DBA_IND_PENDING_STATS.TABLE_NAME is 'Table name'
/

comment on column DBA_IND_PENDING_STATS.PARTITION_NAME is 'Partition name'
/

comment on column DBA_IND_PENDING_STATS.SUBPARTITION_NAME is 'Subpartition name'
/

comment on column DBA_IND_PENDING_STATS.BLEVEL is 'Number of levels in the index'
/

comment on column DBA_IND_PENDING_STATS.LEAF_BLOCKS is 'Number of leaf blocks in the index'
/

comment on column DBA_IND_PENDING_STATS.DISTINCT_KEYS is 'Number of distinct keys in the index'
/

comment on column DBA_IND_PENDING_STATS.AVG_LEAF_BLOCKS_PER_KEY is 'Average number of leaf blocks per key'
/

comment on column DBA_IND_PENDING_STATS.AVG_DATA_BLOCKS_PER_KEY is 'Average number of data blocks per key'
/

comment on column DBA_IND_PENDING_STATS.CLUSTERING_FACTOR is 'Clustering factor'
/

comment on column DBA_IND_PENDING_STATS.NUM_ROWS is 'Number of rows in the index'
/

comment on column DBA_IND_PENDING_STATS.SAMPLE_SIZE is 'Sample size'
/

comment on column DBA_IND_PENDING_STATS.LAST_ANALYZED is 'Time of last analyze'
/

