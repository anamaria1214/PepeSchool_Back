create view KU$_10_1_DBLINK_VIEW
            (VERS_MAJOR, VERS_MINOR, OWNER_NAME, OWNER_NUM, NAME, CTIME, HOST, USERID, PASSWORD, FLAG, AUTHUSR, AUTHPWD,
             PASSWORDX, AUTHPWDX)
as
select t.* from ku$_dblink_view t
  where NVL(t.userid,'CURRENT_USER')='CURRENT_USER'
    and t.authusr is NULL
/

