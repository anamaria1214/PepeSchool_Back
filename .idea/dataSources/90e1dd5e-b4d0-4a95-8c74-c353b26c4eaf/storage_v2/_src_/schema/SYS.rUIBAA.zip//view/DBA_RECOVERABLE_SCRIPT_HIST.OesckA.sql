create view DBA_RECOVERABLE_SCRIPT_HIST
            (SCRIPT_ID, CREATION_TIME, INVOKING_PACKAGE_OWNER, INVOKING_PACKAGE, INVOKING_PROCEDURE, INVOKING_USER,
             STATUS, TOTAL_BLOCKS, DONE_BLOCK_NUM, SCRIPT_COMMENT)
as
select oid, ctime, invoking_package_owner, invoking_package,
  invoking_procedure, invoking_user,
  decode(status, 4, 'EXECUTED',
                 6, 'PURGED'),
  total_blocks, done_block_num, script_comment
from sys.reco_script$
where status in (4,6)
/

comment on table DBA_RECOVERABLE_SCRIPT_HIST is 'Details about executed or purged recoverable operations'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.SCRIPT_ID is 'Unique id of the operation'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.CREATION_TIME is 'Time the operation was invoked'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.INVOKING_PACKAGE_OWNER is 'Invoking package owner of the operation'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.INVOKING_PACKAGE is 'Invoking package of the operation'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.INVOKING_PROCEDURE is 'Invoking procedure of the operation'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.INVOKING_USER is 'Script owner'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.STATUS is 'state of the recoverable script: EXECUTED, PURGED'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.TOTAL_BLOCKS is 'total number of blocks for the recoverable script to be executed'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.DONE_BLOCK_NUM is 'last block so far executed'
/

comment on column DBA_RECOVERABLE_SCRIPT_HIST.SCRIPT_COMMENT is 'comment for the recoverable script'
/

