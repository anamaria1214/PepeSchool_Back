create view V_$CORRUPT_XID_LIST (CORRUPT_XID, CON_ID) as
select "CORRUPT_XID","CON_ID" from v$corrupt_xid_list
/

