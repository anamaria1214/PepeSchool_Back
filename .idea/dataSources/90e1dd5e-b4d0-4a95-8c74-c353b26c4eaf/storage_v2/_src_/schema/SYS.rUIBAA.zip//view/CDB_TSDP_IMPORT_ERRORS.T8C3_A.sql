create view CDB_TSDP_IMPORT_ERRORS (ERROR_CODE, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME, SENSITIVE_TYPE, CON_ID) as
SELECT k."ERROR_CODE",k."SCHEMA_NAME",k."TABLE_NAME",k."COLUMN_NAME",k."SENSITIVE_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_TSDP_IMPORT_ERRORS") k
/

comment on table CDB_TSDP_IMPORT_ERRORS is 'Lists the errors encountered during import of Discovery Result in all containers'
/

comment on column CDB_TSDP_IMPORT_ERRORS.ERROR_CODE is 'The ORA error code of the error encountered'
/

comment on column CDB_TSDP_IMPORT_ERRORS.SCHEMA_NAME is 'The Schema corresponding to the error'
/

comment on column CDB_TSDP_IMPORT_ERRORS.TABLE_NAME is 'The Table corresponding to the error'
/

comment on column CDB_TSDP_IMPORT_ERRORS.COLUMN_NAME is 'The Column corresponding to the error'
/

comment on column CDB_TSDP_IMPORT_ERRORS.SENSITIVE_TYPE is 'The Sensitive Type corresponding to the error'
/

comment on column CDB_TSDP_IMPORT_ERRORS.CON_ID is 'container id'
/

