create view MDX_ODBO_PROPERTIES
            (CATALOG_NAME, SCHEMA_NAME, CUBE_NAME, DIMENSION_UNIQUE_NAME, HIERARCHY_UNIQUE_NAME, LEVEL_UNIQUE_NAME,
             MEMBER_UNIQUE_NAME, PROPERTY_TYPE, PROPERTY_NAME, PROPERTY_CAPTION, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
             CHARACTER_OCTET_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, DESCRIPTION, PROPERTY_CONTENT_TYPE,
             SQL_COLUMN_NAME, LANGUAGE, PROPERTY_ORIGIN, PROPERTY_ATTRIBUTE_HIER_NAME, PROPERTY_CARDINALITY, MIME_TYPE,
             PROPERTY_IS_VISIBLE)
as
(
SELECT
  schema_name CATALOG_NAME,
  SCHEMA_NAME,
  CUBE_NAME,
  CAST(DIMENSION_UNIQUE_NAME AS VARCHAR2(4000)) DIMENSION_UNIQUE_NAME,
  CAST(HIERARCHY_UNIQUE_NAME AS VARCHAR2(4000)) HIERARCHY_UNIQUE_NAME,
  CAST(LEVEL_UNIQUE_NAME AS VARCHAR2(4000)) LEVEL_UNIQUE_NAME,
  MEMBER_UNIQUE_NAME,
  PROPERTY_TYPE,
  PROPERTY_NAME,
  PROPERTY_CAPTION,
  DATA_TYPE,
  CHARACTER_MAXIMUM_LENGTH,
  CHARACTER_OCTET_LENGTH,
  decode(data_type, 139, nvl(numeric_precision, 38), numeric_precision)
    NUMERIC_PRECISION,
  decode(data_type, 139, nvl2(numeric_precision, nvl(numeric_scale, 0), 127),
    numeric_scale) NUMERIC_SCALE,
  DESCRIPTION,
  PROPERTY_CONTENT_TYPE,
  NULL SQL_COLUMN_NAME,  /* not supported by this schema rowset, set to NULL */
  LANGUAGE,
  PROPERTY_ORIGIN,
  PROPERTY_ATTRIBUTE_HIER_NAME,
  'ONE' PROPERTY_CARDINALITY,
  NULL MIME_TYPE,        /* not supported by this schema rowset, set to NULL */
  1 PROPERTY_IS_VISIBLE
FROM(
SELECT
  SCHEMA_NAME,
  CUBE_NAME,
  DIMENSION_UNIQUE_NAME,
  HIERARCHY_UNIQUE_NAME,
  LEVEL_UNIQUE_NAME,
  MEMBER_UNIQUE_NAME,
  PROPERTY_TYPE,
  PROPERTY_NAME,
  NVL(property_caption_raw, property_name) PROPERTY_CAPTION,
  DATA_TYPE,
  CHARACTER_MAXIMUM_LENGTH,
  CHARACTER_OCTET_LENGTH,
  NUMERIC_PRECISION,
  NUMERIC_SCALE,
  NVL(description_raw, NVL(property_caption_raw, property_name)) DESCRIPTION,
  PROPERTY_CONTENT_TYPE,
  LANGUAGE,
  PROPERTY_ORIGIN,
  PROPERTY_ATTRIBUTE_HIER_NAME
FROM (
SELECT /* dimension properties */
  avc.owner SCHEMA_NAME,
  avc.analytic_view_name CUBE_NAME,
  dbms_mdx_odbo.mdx_component_id(NVL(avc.dimension_name, 'MEASURES'))
    DIMENSION_UNIQUE_NAME,
  dbms_mdx_odbo.mdx_component_id(NVL(avc.dimension_name, 'MEASURES'),
    avc.hier_name) HIERARCHY_UNIQUE_NAME,
  dbms_mdx_odbo.mdx_component_id(NVL(avc.dimension_name, 'MEASURES'),
    avc.hier_name, avl.level_name) LEVEL_UNIQUE_NAME,
  NULL MEMBER_UNIQUE_NAME,
  dbms_mdx_odbo.mdx_property_type('MDPROP_MEMBER') PROPERTY_TYPE,
  avc.column_name PROPERTY_NAME,
  NVL(avac_cap_l.value, avac_cap_n.value) PROPERTY_CAPTION_RAW,
  dbms_mdx_odbo.mdx_datatype(avc.data_type) DATA_TYPE,
  avc.char_col_decl_length CHARACTER_MAXIMUM_LENGTH,
  avc.data_length CHARACTER_OCTET_LENGTH,
  avc.data_precision NUMERIC_PRECISION,
  avc.data_scale NUMERIC_SCALE,
  NVL(avac_desc_l.value, avac_desc_n.value) DESCRIPTION_RAW,
  CASE avc.role
    WHEN 'KEY' THEN
      dbms_mdx_odbo.mdx_property_content_type('MD_PROPTYPE_ID')
    WHEN 'AKEY' THEN
      dbms_mdx_odbo.mdx_property_content_type('MD_PROPTYPE_ID')
    ELSE dbms_mdx_odbo.mdx_property_content_type('MD_PROPTYPE_REGULAR')
  END PROPERTY_CONTENT_TYPE,
  NULL LANGUAGE,
  dbms_mdx_odbo.mdx_property_origin('MD_ORIGIN_USER_DEFINED') PROPERTY_ORIGIN,
  avc.column_name PROPERTY_ATTRIBUTE_HIER_NAME
 FROM all_analytic_view_columns avc,
     all_analytic_view_levels avl,
     v$nls_parameters nls,
     all_analytic_view_attr_class avac_cap_l,
     all_analytic_view_attr_class avac_cap_n,
     all_analytic_view_attr_class avac_desc_l,
     all_analytic_view_attr_class avac_desc_n,
     all_objects ao
WHERE 1 != 1 AND /* TEMPORARILY return 0 rows */
      nls.parameter = 'NLS_LANGUAGE' AND
      avc.role not in ('BASE', 'CALC') AND
      avc.owner = avl.owner AND
      avc.analytic_view_name = avl.analytic_view_name AND
      avc.dimension_name = avl.dimension_alias AND
      avc.hier_name = avl.hier_alias AND
      avac_cap_l.owner (+)= avc.owner AND
      avac_cap_l.analytic_view_name (+)= avc.analytic_view_name AND
      avac_cap_l.dimension_alias (+)= avc.dimension_name AND
      avac_cap_l.hier_alias (+)= avc.hier_name AND
      avac_cap_l.attribute_name (+)= avc.column_name AND
      avac_cap_l.classification (+)= 'CAPTION' AND
      avac_cap_l.language (+)= nls.value AND
      avac_cap_n.owner (+)= avc.owner AND
      avac_cap_n.analytic_view_name (+)= avc.analytic_view_name AND
      avac_cap_n.dimension_alias (+)= avc.dimension_name AND
      avac_cap_n.hier_alias (+)= avc.hier_name AND
      avac
/

