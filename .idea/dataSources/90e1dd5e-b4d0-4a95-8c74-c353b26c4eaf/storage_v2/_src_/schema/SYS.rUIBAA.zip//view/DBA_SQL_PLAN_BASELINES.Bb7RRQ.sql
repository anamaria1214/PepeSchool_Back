create view DBA_SQL_PLAN_BASELINES
            (SIGNATURE, SQL_HANDLE, SQL_TEXT, PLAN_NAME, CREATOR, ORIGIN, PARSING_SCHEMA_NAME, DESCRIPTION, VERSION,
             CREATED, LAST_MODIFIED, LAST_EXECUTED, LAST_VERIFIED, ENABLED, ACCEPTED, FIXED, REPRODUCED, AUTOPURGE,
             ADAPTIVE, OPTIMIZER_COST, MODULE, ACTION, EXECUTIONS, ELAPSED_TIME, CPU_TIME, BUFFER_GETS, DISK_READS,
             DIRECT_WRITES, ROWS_PROCESSED, FETCHES, END_OF_FETCH_COUNT)
as
SELECT /*+ dynamic_sampling(3) */
    so.signature,
    st.sql_handle,
    st.sql_text,
    so.name,
    ad.creator,
    DECODE(ad.origin, 1,  'MANUAL-LOAD',
                      2,  'AUTO-CAPTURE',
                      3,  'MANUAL-SQLTUNE',
                      4,  'AUTO-SQLTUNE',
                      5,  'STORED-OUTLINE',
                      6,  'EVOLVE-CREATE-FROM-ADAPTIVE',
                      7,  'MANUAL-LOAD-FROM-STS',
                      8,  'MANUAL-LOAD-FROM-AWR',
                      9,  'MANUAL-LOAD-FROM-CURSOR-CACHE',
                      10, 'EVOLVE-LOAD-FROM-STS',
                      11, 'EVOLVE-LOAD-FROM-AWR',
                      12, 'EVOLVE-LOAD-FROM-CURSOR-CACHE',
                      13, 'ADDM-SQLTUNE',
                      14, 'EVOLVE-AUTO-INDEX-LOAD',
                         'UNKNOWN'),
    ad.parsing_schema_name,
    ad.description,
    ad.version,
    ad.created,
    ad.last_modified,
    so.last_executed,
    ad.last_verified,
    DECODE(BITAND(so.flags, 1),   0, 'NO', 'YES'),
    DECODE(BITAND(so.flags, 2),   0, 'NO', 'YES'),
    DECODE(BITAND(so.flags, 4),   0, 'NO', 'YES'),
    DECODE(BITAND(so.flags, 64),  0, 'YES', 'NO'),
    DECODE(BITAND(so.flags, 8),   0, 'NO', 'YES'),
    DECODE(BITAND(so.flags, 256), 0, 'NO', 'YES'),
    ad.optimizer_cost,
    substrb(ad.module,1,(select ksumodlen from x$modact_length)) module,
    substrb(ad.action,1,(select ksuactlen from x$modact_length)) action,
    ad.executions,
    ad.elapsed_time,
    ad.cpu_time,
    ad.buffer_gets,
    ad.disk_reads,
    ad.direct_writes,
    ad.rows_processed,
    ad.fetches,
    ad.end_of_fetch_count
FROM
    sqlobj$        so,
    sqlobj$auxdata ad,
    sql$text       st
WHERE
    so.signature = st.signature AND
    ad.signature = st.signature AND
    so.signature = ad.signature AND
    so.category = ad.category AND
    so.plan_id = ad.plan_id AND
    so.obj_type = 2 AND
    ad.obj_type = 2
/

comment on table DBA_SQL_PLAN_BASELINES is 'set of plan baselines'
/

comment on column DBA_SQL_PLAN_BASELINES.SIGNATURE is 'unique SQL identifier generated from normalized SQL text'
/

comment on column DBA_SQL_PLAN_BASELINES.SQL_HANDLE is 'unique SQL identifier in string form as a search key'
/

comment on column DBA_SQL_PLAN_BASELINES.SQL_TEXT is 'un-normalized SQL text'
/

comment on column DBA_SQL_PLAN_BASELINES.PLAN_NAME is 'unique plan identifier in string form as a search key'
/

comment on column DBA_SQL_PLAN_BASELINES.CREATOR is 'user who created the plan baseline'
/

comment on column DBA_SQL_PLAN_BASELINES.ORIGIN is 'how plan baseline was created'
/

comment on column DBA_SQL_PLAN_BASELINES.PARSING_SCHEMA_NAME is 'name of parsing schema'
/

comment on column DBA_SQL_PLAN_BASELINES.DESCRIPTION is 'text description provided for plan baseline'
/

comment on column DBA_SQL_PLAN_BASELINES.VERSION is 'database version at time of plan baseline creation'
/

comment on column DBA_SQL_PLAN_BASELINES.CREATED is 'time when plan baseline was created'
/

comment on column DBA_SQL_PLAN_BASELINES.LAST_MODIFIED is 'time when plan baseline was last modified'
/

comment on column DBA_SQL_PLAN_BASELINES.LAST_EXECUTED is 'time when plan baseline was last executed'
/

comment on column DBA_SQL_PLAN_BASELINES.LAST_VERIFIED is 'time when plan baseline was last verified'
/

comment on column DBA_SQL_PLAN_BASELINES.ENABLED is 'enabled status of plan baseline'
/

comment on column DBA_SQL_PLAN_BASELINES.ACCEPTED is 'accepted status of plan baseline'
/

comment on column DBA_SQL_PLAN_BASELINES.FIXED is 'fixed status of plan baseline'
/

comment on column DBA_SQL_PLAN_BASELINES.REPRODUCED is 'reproduced status of plan baseline'
/

comment on column DBA_SQL_PLAN_BASELINES.AUTOPURGE is 'auto-purge status of plan baseline'
/

comment on column DBA_SQL_PLAN_BASELINES.ADAPTIVE is 'adaptive status of plan baseline'
/

comment on column DBA_SQL_PLAN_BASELINES.OPTIMIZER_COST is 'plan baseline optimizer cost'
/

comment on column DBA_SQL_PLAN_BASELINES.MODULE is 'application module name'
/

comment on column DBA_SQL_PLAN_BASELINES.ACTION is 'application action'
/

comment on column DBA_SQL_PLAN_BASELINES.EXECUTIONS is 'number of plan baseline executions'
/

comment on column DBA_SQL_PLAN_BASELINES.ELAPSED_TIME is 'total elapse time'
/

comment on column DBA_SQL_PLAN_BASELINES.CPU_TIME is 'total CPU time'
/

comment on column DBA_SQL_PLAN_BASELINES.BUFFER_GETS is 'total buffer gets'
/

comment on column DBA_SQL_PLAN_BASELINES.DISK_READS is 'total disk reads'
/

comment on column DBA_SQL_PLAN_BASELINES.DIRECT_WRITES is 'total direct writes'
/

comment on column DBA_SQL_PLAN_BASELINES.ROWS_PROCESSED is 'total rows processed'
/

comment on column DBA_SQL_PLAN_BASELINES.FETCHES is 'total number of fetches'
/

comment on column DBA_SQL_PLAN_BASELINES.END_OF_FETCH_COUNT is 'total number of full fetches'
/

