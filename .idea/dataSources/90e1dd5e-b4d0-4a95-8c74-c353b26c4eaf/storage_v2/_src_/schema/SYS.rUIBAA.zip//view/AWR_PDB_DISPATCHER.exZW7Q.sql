create view AWR_PDB_DISPATCHER
            (SNAP_ID, DBID, INSTANCE_NUMBER, NAME, SERIAL#, IDLE, BUSY, WAIT, TOTALQ, SAMPLED_TOTAL_CONN, CON_DBID,
             CON_ID) as
select
  sn.snap_id, sn.dbid, sn.instance_number,
  d.name, d.serial#, d.idle, d.busy, d.wait, d.totalq, d.sampled_total_conn,
  decode(d.con_dbid, 0, d.dbid, d.con_dbid),
  decode(d.per_pdb, 0, 0,
    con_dbid_to_id(decode(d.con_dbid, 0, d.dbid, d.con_dbid))) con_id
from AWR_PDB_SNAPSHOT sn, WRH$_DISPATCHER d
where     sn.snap_id         = d.snap_id
      and sn.dbid            = d.dbid
      and sn.instance_number = d.instance_number
/

comment on table AWR_PDB_DISPATCHER is 'Dispatcher statistics'
/

