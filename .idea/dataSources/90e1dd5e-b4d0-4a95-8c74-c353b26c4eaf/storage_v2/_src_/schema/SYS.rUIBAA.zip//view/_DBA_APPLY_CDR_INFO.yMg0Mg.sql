create view "_DBA_APPLY_CDR_INFO"
            (LOCAL_TRANSACTION_ID, SOURCE_TRANSACTION_ID, SOURCE_DATABASE, ERROR_NUMBER, ERROR_MESSAGE,
             SOURCE_OBJECT_OWNER, SOURCE_OBJECT_NAME, DEST_OBJECT_OWNER, DEST_OBJECT_NAME, OPERATION, POSITION, SEQ#,
             RBA, INDEX#, RESOLUTION_STATUS, RESOLUTION_COLUMN, RESOLUTION_METHOD, RESOLUTION_TIME,
             TABLE_SUCCESSFUL_CDR, TABLE_FAILED_CDR, ALL_SUCCESSFUL_CDR, ALL_FAILED_CDR, FLAGS, SPARE1, SPARE2, SPARE3)
as
select
  local_transaction_id,source_transaction_id,source_database,
  error_number,error_message,source_object_owner, source_object_name,
  dest_object_owner, dest_object_name, operation, position,
  seq#, rba, index#, resolution_status,resolution_column,
  resolution_method, resolution_time, table_successful_cdr,
  table_failed_cdr, all_successful_cdr, all_failed_cdr,
  flags, spare1, spare2, spare3
from sys.apply$_cdr_info
/

