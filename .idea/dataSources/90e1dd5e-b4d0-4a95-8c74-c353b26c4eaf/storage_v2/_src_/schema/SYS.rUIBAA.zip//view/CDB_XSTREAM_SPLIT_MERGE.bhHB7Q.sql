create view CDB_XSTREAM_SPLIT_MERGE
            (ORIGINAL_CAPTURE_NAME, CLONED_CAPTURE_NAME, ORIGINAL_CAPTURE_STATUS, CLONED_CAPTURE_STATUS,
             ORIGINAL_XSTREAM_NAME, CLONED_XSTREAM_NAME, XSTREAM_TYPE, RECOVERABLE_SCRIPT_ID, SCRIPT_STATUS,
             ACTION_TYPE, ACTION_THRESHOLD, STATUS, STATUS_UPDATE_TIME, CREATION_TIME, LAG, JOB_OWNER, JOB_NAME,
             JOB_STATE, JOB_NEXT_RUN_DATE, ERROR_NUMBER, ERROR_MESSAGE, CON_ID)
as
SELECT k."ORIGINAL_CAPTURE_NAME",k."CLONED_CAPTURE_NAME",k."ORIGINAL_CAPTURE_STATUS",k."CLONED_CAPTURE_STATUS",k."ORIGINAL_XSTREAM_NAME",k."CLONED_XSTREAM_NAME",k."XSTREAM_TYPE",k."RECOVERABLE_SCRIPT_ID",k."SCRIPT_STATUS",k."ACTION_TYPE",k."ACTION_THRESHOLD",k."STATUS",k."STATUS_UPDATE_TIME",k."CREATION_TIME",k."LAG",k."JOB_OWNER",k."JOB_NAME",k."JOB_STATE",k."JOB_NEXT_RUN_DATE",k."ERROR_NUMBER",k."ERROR_MESSAGE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XSTREAM_SPLIT_MERGE") k
/

comment on table CDB_XSTREAM_SPLIT_MERGE is 'view of details of split/merge jobs/status about XStream in all containers'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.ORIGINAL_CAPTURE_NAME is 'name of the original capture'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.CLONED_CAPTURE_NAME is 'name of the cloned capture'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.ORIGINAL_CAPTURE_STATUS is 'status of the original capture'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.CLONED_CAPTURE_STATUS is 'status of the cloned capture'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.ORIGINAL_XSTREAM_NAME is 'name of original XStream (propagation or local apply)'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.CLONED_XSTREAM_NAME is 'name of cloned XStream (propagation or local apply)'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.XSTREAM_TYPE is 'type of XStream (propagation or local apply)'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.RECOVERABLE_SCRIPT_ID is 'unique oid of the script to split or merge XStream'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.SCRIPT_STATUS is 'status of the script to split or merge XStream'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.ACTION_TYPE is 'type of action performed on this XStream (either split or merge)'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.ACTION_THRESHOLD is 'value of split_threshold or merge_threshold'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.STATUS is 'status of XStream'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.STATUS_UPDATE_TIME is 'time when status was last updated'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.CREATION_TIME is 'time when this row was created'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.LAG is 'the time in seconds that the cloned capture lags behind the original capture'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.JOB_OWNER is 'name of the owner of the job'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.JOB_NAME is 'name of the job to split or merge XStream'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.JOB_STATE is 'state of the job'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.JOB_NEXT_RUN_DATE is 'when will the job run next time'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.ERROR_NUMBER is 'Error number if the capture process was aborted'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.ERROR_MESSAGE is 'Error message if the capture process was aborted'
/

comment on column CDB_XSTREAM_SPLIT_MERGE.CON_ID is 'container id'
/

