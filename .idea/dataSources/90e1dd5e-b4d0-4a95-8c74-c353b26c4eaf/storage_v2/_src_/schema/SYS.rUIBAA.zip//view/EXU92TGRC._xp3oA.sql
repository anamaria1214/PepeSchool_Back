create view EXU92TGRC
            (OWNERID, OWNER, BASEOBJECT, DEFINITION, WHENCLAUSE, ACTION, ENABLED, TPROPERTY, NAME, BASENAME, BASETYPE,
             PROPERTY, BTOWNER, BTOWNERID, ACTIONSIZE, TRIG_OBJNO)
as
SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","TPROPERTY","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE","TRIG_OBJNO"
        FROM    sys.exu92itgr
        WHERE   (ownerid, basename) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu9tabc)
      UNION ALL
        SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","TPROPERTY","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE","TRIG_OBJNO"
        FROM    sys.exu92itgr
        WHERE   (ownerid, basename) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu8vinfc)
/

