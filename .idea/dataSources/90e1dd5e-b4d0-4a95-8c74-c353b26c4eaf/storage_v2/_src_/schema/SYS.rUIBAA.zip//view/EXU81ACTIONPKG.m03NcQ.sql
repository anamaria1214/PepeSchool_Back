create view EXU81ACTIONPKG (PACKAGE, PKG_SCHEMA, CLASS, LEVEL#) as
SELECT  package, schema, class, level#
        FROM    sys.exppkgact$
/

