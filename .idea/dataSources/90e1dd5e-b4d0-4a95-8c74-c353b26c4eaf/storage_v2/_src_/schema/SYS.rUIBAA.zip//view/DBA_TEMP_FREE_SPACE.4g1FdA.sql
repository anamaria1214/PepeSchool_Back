create view DBA_TEMP_FREE_SPACE (TABLESPACE_NAME, TABLESPACE_SIZE, ALLOCATED_SPACE, FREE_SPACE, SHARED, INST_ID) as
SELECT tsh.tablespace_name,
         tsh.total_bytes/tsh.inst_count,
         tsh.bytes_used/tsh.inst_count,
         (tsh.bytes_free/tsh.inst_count) + (nvl(ss.free_blocks, 0) * ts$.blocksize),
         decode(bitand(ts$.flags, 18155135997837312),
                140737488355328, 'LOCAL_ON_LEAF',
                18155135997837312, 'LOCAL_ON_ALL', 'SHARED') shared,
         null as inst_id
    FROM (SELECT tablespace_name, sum(bytes_used + bytes_free) total_bytes,
                 sum(bytes_used) bytes_used, sum(bytes_free) bytes_free,
                 count(distinct inst_id) inst_count
            FROM gv$temp_space_header
            where (con_id is NULL or con_id = sys_context('USERENV', 'CON_ID'))
            GROUP BY tablespace_name) tsh,
         (SELECT tablespace_name, sum(free_blocks) free_blocks
            FROM gv$sort_segment
            where (con_id is NULL or con_id = sys_context('USERENV', 'CON_ID'))
            GROUP BY tablespace_name) ss,
         ts$
    WHERE ts$.name = tsh.tablespace_name and
          decode(bitand(ts$.flags, 18155135997837312),
                            140737488355328, 1,
                            18155135997837312, 1, 0) = 0 and
          tsh.tablespace_name = ss.tablespace_name (+)
   UNION
  SELECT tsh.tablespace_name,
         tsh.total_bytes,
         tsh.bytes_used,
         (tsh.bytes_free) + (nvl(ss.free_blocks, 0) * ts$.blocksize),
         decode(bitand(ts$.flags, 18155135997837312),
                140737488355328, 'LOCAL_ON_LEAF',
                18155135997837312, 'LOCAL_ON_ALL', 'SHARED') shared,
         tsh.inst_id
    FROM (SELECT tablespace_name, inst_id, sum(bytes_used + bytes_free) total_bytes,
                 sum(bytes_used) bytes_used, sum(bytes_free) bytes_free
            FROM gv$temp_space_header
            WHERE (con_id is NULL or con_id = sys_context('USERENV', 'CON_ID'))
            GROUP BY tablespace_name, inst_id) tsh,
         (SELECT tablespace_name, inst_id, sum(free_blocks) free_blocks
            FROM gv$sort_segment
            WHERE (con_id is NULL or con_id = sys_context('USERENV', 'CON_ID'))
            GROUP BY tablespace_name, inst_id) ss,
         ts$
   WHERE ts$.name = tsh.tablespace_name and
         decode(bitand(ts$.flags, 18155135997837312),
                140737488355328, 1,
                18155135997837312, 1, 0) = 1 and
         tsh.tablespace_name = ss.tablespace_name (+)
/

comment on table DBA_TEMP_FREE_SPACE is 'Summary of temporary space usage'
/

comment on column DBA_TEMP_FREE_SPACE.TABLESPACE_NAME is 'Tablespace name'
/

comment on column DBA_TEMP_FREE_SPACE.TABLESPACE_SIZE is 'Total size of the tablespace'
/

comment on column DBA_TEMP_FREE_SPACE.ALLOCATED_SPACE is 'Total allocated space for sort segments'
/

comment on column DBA_TEMP_FREE_SPACE.FREE_SPACE is 'Total free space available'
/

comment on column DBA_TEMP_FREE_SPACE.SHARED is 'Type of temporary tablespace'
/

comment on column DBA_TEMP_FREE_SPACE.INST_ID is 'Instance id of corresponding temporary tablespace'
/

