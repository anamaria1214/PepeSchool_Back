create view DBA_EDITION_COMMENTS (EDITION_NAME, COMMENTS) as
select o.name, c.comment$
from sys.obj$ o, sys.com$ c
where o.obj# = c.obj# (+)
  and o.type# = 57
/

comment on table DBA_EDITION_COMMENTS is 'Describes comments on all editions in the database'
/

comment on column DBA_EDITION_COMMENTS.EDITION_NAME is 'Name of the edition'
/

comment on column DBA_EDITION_COMMENTS.COMMENTS is 'Edition comments'
/

