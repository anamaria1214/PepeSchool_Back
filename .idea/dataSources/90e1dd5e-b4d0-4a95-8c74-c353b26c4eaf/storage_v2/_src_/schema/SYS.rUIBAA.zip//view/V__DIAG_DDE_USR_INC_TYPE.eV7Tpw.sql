create view V_$DIAG_DDE_USR_INC_TYPE (TYPE_NAME, DESCRIPTION, CON_ID) as
select
   "TYPE_NAME",
   "DESCRIPTION",
   "CON_ID"
  from x$diag_DDE_USR_INC_TYPE
/

