create view KU$_INDARRAYTYPE_VIEW (OBJ_NUM, TYPE_NUM, BASETYPE_OBJ, ARRAYTYPE_OBJ) as
select ia.obj#, ia.type,
         (select value(o1) from ku$_schemaobj_view o1
               where o1.obj_num=ia.basetypeobj#),
         (select value(o2) from ku$_schemaobj_view o2
               where o2.obj_num=ia.arraytypeobj#)
  from sys.indarraytype$ ia
/

