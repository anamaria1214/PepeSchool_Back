create view ALL_STREAMS_GLOBAL_RULES
            (STREAMS_NAME, STREAMS_TYPE, RULE_TYPE, INCLUDE_TAGGED_LCR, SOURCE_DATABASE, RULE_NAME, RULE_OWNER,
             RULE_CONDITION) as
select r.streams_name, r.streams_type, r.rule_type, r.include_tagged_lcr,
       r.source_database, r.rule_name, r.rule_owner, r.rule_condition
 from  dba_streams_global_rules r, "_ALL_STREAMS_PROCESSES" p, all_rules ar
 where r.streams_name = p.streams_name
   and r.streams_type = p.streams_type
   and ar.rule_owner = r.rule_owner
   and ar.rule_name = r.rule_name
/

comment on table ALL_STREAMS_GLOBAL_RULES is 'Global rules created on the streams capture/apply/propagation process that interact with the queue visible to the current user'
/

comment on column ALL_STREAMS_GLOBAL_RULES.STREAMS_NAME is 'Name of the streams process: capture/propagation/apply process'
/

comment on column ALL_STREAMS_GLOBAL_RULES.STREAMS_TYPE is 'Type of the streams process: CAPTURE, PROPAGATION or APPLY'
/

comment on column ALL_STREAMS_GLOBAL_RULES.RULE_TYPE is 'Type of rule: DML, DDL or PROCEDURE'
/

comment on column ALL_STREAMS_GLOBAL_RULES.INCLUDE_TAGGED_LCR is 'Whether or not to include tagged LCR'
/

comment on column ALL_STREAMS_GLOBAL_RULES.SOURCE_DATABASE is 'Name of the database where the LCRs originated'
/

comment on column ALL_STREAMS_GLOBAL_RULES.RULE_NAME is 'Name of the rule to be applied'
/

comment on column ALL_STREAMS_GLOBAL_RULES.RULE_OWNER is 'Owner of the rule'
/

comment on column ALL_STREAMS_GLOBAL_RULES.RULE_CONDITION is 'Generated rule condition evaluated by the rules engine'
/

