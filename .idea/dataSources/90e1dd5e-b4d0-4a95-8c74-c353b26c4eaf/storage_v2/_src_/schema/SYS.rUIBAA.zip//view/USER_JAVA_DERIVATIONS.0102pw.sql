create view USER_JAVA_DERIVATIONS (SOURCE_NAME, CLASS_INDEX, CLASS_NAME) as
select nvl(j.longdbcs, o.name),
       t.joxftderivedclassnumber,
       nvl(j2.longdbcs, t.joxftderivedclassname)
from sys.javasnm$ j, sys.javasnm$ j2, sys.obj$ o, sys.x$joxdrc t
where o.obj# = t.joxftobn
  and o.type# = 28
  and j.short(+) = o.name
  and j2.short(+) = t.joxftderivedclassname
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_JAVA_DERIVATIONS is 'this view maps java source objects and their derived java class objects and java resource objects  for the java class owned by user'
/

comment on column USER_JAVA_DERIVATIONS.SOURCE_NAME is 'name of the java source object'
/

comment on column USER_JAVA_DERIVATIONS.CLASS_INDEX is 'index of the derived java class object'
/

comment on column USER_JAVA_DERIVATIONS.CLASS_NAME is 'name of the derived java class object'
/

