create view V_$DATAPUMP_SESSION (ATTACH_ID, JOB_ID, SADDR, TYPE, CON_ID) as
SELECT "ATTACH_ID","JOB_ID","SADDR","TYPE","CON_ID" FROM     sys.v$datapump_session
/

