create view DBA_EXPORT_PATHS (HET_TYPE, OBJECT_PATH) as
select a.htype,a.name
 from sys.metanametrans$ a
 order by a.htype,a.name
/

