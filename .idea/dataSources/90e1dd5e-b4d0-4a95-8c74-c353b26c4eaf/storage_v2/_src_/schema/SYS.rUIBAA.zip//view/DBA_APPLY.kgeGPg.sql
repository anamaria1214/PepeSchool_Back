create view DBA_APPLY
            (APPLY_NAME, QUEUE_NAME, QUEUE_OWNER, APPLY_CAPTURED, RULE_SET_NAME, RULE_SET_OWNER, APPLY_USER,
             APPLY_DATABASE_LINK, APPLY_TAG, DDL_HANDLER, PRECOMMIT_HANDLER, MESSAGE_HANDLER, STATUS,
             MAX_APPLIED_MESSAGE_NUMBER, NEGATIVE_RULE_SET_NAME, NEGATIVE_RULE_SET_OWNER, STATUS_CHANGE_TIME,
             ERROR_NUMBER, ERROR_MESSAGE, MESSAGE_DELIVERY_MODE, PURPOSE, LCRID_VERSION)
as
select ap.apply_name, ap.queue_name, ap.queue_owner,
       decode(bitand(ap.flags, 1), 1, 'YES',
                                   0, 'NO'),
       ap.ruleset_name, ap.ruleset_owner,
       u.name, ap.apply_dblink, ap.apply_tag, ap.ddl_handler,
       ap.precommit_handler, ap.message_handler,
       -- if uncommitted XOut show capture's status else show apply status
       case when (bitand(ap.flags, 1280) = 1280)
         then (select decode(cp.status, 1, 'DISABLED',
                         2, 'ENABLED',
                         4, 'ABORTED', 'UNKNOWN')
               from sys.streams$_capture_process cp, sys.xstream$_server xs
                 where ap.apply_name = xs.server_name and
                       xs.queue_owner = cp.queue_owner and
                       xs.queue_name = cp.queue_name)
         else decode(ap.status,
                         1, 'DISABLED',
                         2, 'ENABLED',
                         4, 'ABORTED', 'UNKNOWN') end,
       ap.spare1,
       ap.negative_ruleset_name, ap.negative_ruleset_owner,
       ap.status_change_time, ap.error_number, ap.error_message,
       decode(bitand(ap.flags, 1), 1, 'CAPTURED',
              decode(bitand(ap.flags, 128), 128, 'CAPTURED',
                                              0, 'PERSISTENT')),
       -- if uncommitted XOut, purpose can only be 'GoldenGate'
       (case
          when (bitand(ap.flags, 1280)     = 1280)  then 'GoldenGate Capture'
          when (bitand(ap.flags, 16)       = 16)    then 'CHANGE DATA CAPTURE'
          when (bitand(ap.flags, 32)       = 32)    then 'AUDIT VAULT'
          when (bitand(ap.flags, 16384)    = 16384) then
            (case
               when (bitand(ap.flags, 256) = 256)   then 'GoldenGate Capture'
               when (bitand(ap.flags, 512) = 512)   then 'GoldenGate Apply'
             end)
          when (bitand(ap.flags, 256)      = 256)   then 'XStream Out'
          when (bitand(ap.flags, 512)      = 512)   then 'XStream In'
          else
             ( select 'XStream Streams' from dual where exists
                (select 1 from sys.props$
                  where name = 'GG_XSTREAM_FOR_STREAMS' and value$ = 'T')
               union
               select 'Streams' from dual where NOT exists
                (select 1 from sys.props$
                  where name = 'GG_XSTREAM_FOR_STREAMS' and value$ = 'T'))
       end),
       ap.lcrid_version
  from "_DBA_APPLY" ap, sys.user$ u
 where  ap.apply_userid = u.user# (+)
/

comment on table DBA_APPLY is 'Details about the apply process'
/

comment on column DBA_APPLY.APPLY_NAME is 'Name of the apply process'
/

comment on column DBA_APPLY.QUEUE_NAME is 'Name of the queue the apply process dequeues from'
/

comment on column DBA_APPLY.QUEUE_OWNER is 'Owner of the queue the apply process dequeues from'
/

comment on column DBA_APPLY.APPLY_CAPTURED is 'Yes, if applying captured messages; No, if applying enqueued messages'
/

comment on column DBA_APPLY.RULE_SET_NAME is 'Rule set used by apply process for filtering'
/

comment on column DBA_APPLY.RULE_SET_OWNER is 'Owner of the negative rule set'
/

comment on column DBA_APPLY.APPLY_USER is 'Current user who is applying the messages'
/

comment on column DBA_APPLY.APPLY_DATABASE_LINK is 'For remote objects, the database link pointing to the remote database'
/

comment on column DBA_APPLY.APPLY_TAG is 'Tag associated with DDL and DML change records that will be applied'
/

comment on column DBA_APPLY.DDL_HANDLER is 'Name of the user specified ddl handler'
/

comment on column DBA_APPLY.PRECOMMIT_HANDLER is 'Name of the user specified precommit handler'
/

comment on column DBA_APPLY.MESSAGE_HANDLER is 'User specified procedure to handle messages other than DDL and DML messages'
/

comment on column DBA_APPLY.STATUS is 'Status of the apply process: DISABLED, ENABLED, ABORTED'
/

comment on column DBA_APPLY.MAX_APPLIED_MESSAGE_NUMBER is 'Maximum value of message that has been applied'
/

comment on column DBA_APPLY.NEGATIVE_RULE_SET_NAME is 'Negative rule set used by apply process for filtering'
/

comment on column DBA_APPLY.STATUS_CHANGE_TIME is 'The time that STATUS of the apply process was changed'
/

comment on column DBA_APPLY.ERROR_NUMBER is 'Error number if the apply process was aborted'
/

comment on column DBA_APPLY.ERROR_MESSAGE is 'Error message if the apply process was aborted'
/

comment on column DBA_APPLY.PURPOSE is 'Purpose of this apply process '
/

comment on column DBA_APPLY.LCRID_VERSION is 'LCRID format currently being used'
/

