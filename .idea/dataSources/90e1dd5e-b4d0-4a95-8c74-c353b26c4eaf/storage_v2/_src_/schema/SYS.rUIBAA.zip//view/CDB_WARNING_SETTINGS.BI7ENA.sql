create view CDB_WARNING_SETTINGS (OWNER, OBJECT_NAME, OBJECT_ID, OBJECT_TYPE, WARNING, SETTING, CON_ID) as
SELECT k."OWNER",k."OBJECT_NAME",k."OBJECT_ID",k."OBJECT_TYPE",k."WARNING",k."SETTING",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_WARNING_SETTINGS") k
/

comment on table CDB_WARNING_SETTINGS is 'warning settings for all objects in all containers'
/

comment on column CDB_WARNING_SETTINGS.OWNER is 'Username of the owner of the object'
/

comment on column CDB_WARNING_SETTINGS.OBJECT_NAME is 'Name of the object'
/

comment on column CDB_WARNING_SETTINGS.OBJECT_ID is 'Object number of the object'
/

comment on column CDB_WARNING_SETTINGS.OBJECT_TYPE is 'Type of the object'
/

comment on column CDB_WARNING_SETTINGS.WARNING is 'Warning number or category'
/

comment on column CDB_WARNING_SETTINGS.SETTING is 'Value of the warning setting'
/

comment on column CDB_WARNING_SETTINGS.CON_ID is 'container id'
/

