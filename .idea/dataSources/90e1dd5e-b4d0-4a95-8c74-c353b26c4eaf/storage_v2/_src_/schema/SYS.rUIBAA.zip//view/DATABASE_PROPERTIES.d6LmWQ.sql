create view DATABASE_PROPERTIES (PROPERTY_NAME, PROPERTY_VALUE, DESCRIPTION) as
select name, value$, comment$
  from x$props
  where name != 'NO_USERID_VERIFIER_SALT'
/

comment on table DATABASE_PROPERTIES is 'Permanent database properties'
/

comment on column DATABASE_PROPERTIES.PROPERTY_NAME is 'Property name'
/

comment on column DATABASE_PROPERTIES.PROPERTY_VALUE is 'Property value'
/

comment on column DATABASE_PROPERTIES.DESCRIPTION is 'Property description'
/

