create view AWR_CDB_RECOVERY_PROGRESS
            (SNAP_ID, DBID, INSTANCE_NUMBER, START_TIME, TYPE, ITEM, UNITS, SOFAR, TOTAL, TIMESTAMP, CON_DBID,
             CON_ID) as
select rp.snap_id, rp.dbid, rp.instance_number, start_time, type,
       item, units, sofar, total, timestamp,
       decode(rp.con_dbid, 0, rp.dbid, rp.con_dbid),
       decode(rp.per_pdb, 0, 0,
         con_dbid_to_id(decode(rp.con_dbid, 0, rp.dbid, rp.con_dbid))) con_id
  from AWR_CDB_SNAPSHOT sn, WRH$_RECOVERY_PROGRESS rp
  where    sn.snap_id  = rp.snap_id
       and sn.dbid     = rp.dbid
       and sn.instance_number = rp.instance_number
/

comment on table AWR_CDB_RECOVERY_PROGRESS is 'Recovery Progress'
/

