create view DBA_WORKLOAD_REPLAY_FILTER_SET (CAPTURE_ID, SET_NAME, FILTER_NAME, ATTRIBUTE, VALUE) as
select capture_id, set_name, filter_name, attribute, value
 from WRR$_REPLAY_FILTER_SET
/

