create view DBA_FLASHBACK_ARCHIVE
            (OWNER_NAME, FLASHBACK_ARCHIVE_NAME, FLASHBACK_ARCHIVE#, RETENTION_IN_DAYS, CREATE_TIME, LAST_PURGE_TIME,
             STATUS) as
select f.OWNERNAME, f.FANAME, f.FA#, f.RETENTION,
          case when f.CREATESCN < f.PURGESCN then NULL
               else scn_to_timestamp(f.CREATESCN)
               end,
          scn_to_timestamp(f.PURGESCN),
          decode(bitand(f.flags, 1), 1, 'DEFAULT', NULL)
from SYS_FBA_FA f
/

comment on table DBA_FLASHBACK_ARCHIVE is 'Description of the flashback archives available in the system'
/

comment on column DBA_FLASHBACK_ARCHIVE.OWNER_NAME is 'Name of the creator of the flashback archive'
/

comment on column DBA_FLASHBACK_ARCHIVE.FLASHBACK_ARCHIVE_NAME is 'Name of the flashback archive'
/

comment on column DBA_FLASHBACK_ARCHIVE.FLASHBACK_ARCHIVE# is 'Number of the flashback archive'
/

comment on column DBA_FLASHBACK_ARCHIVE.RETENTION_IN_DAYS is 'Maximum duration in days for which data is retained in the flashback archive'
/

comment on column DBA_FLASHBACK_ARCHIVE.CREATE_TIME is 'Time at which the flashback archive was created'
/

comment on column DBA_FLASHBACK_ARCHIVE.LAST_PURGE_TIME is 'Time at which the data in the flashback archive was last purged by the system'
/

comment on column DBA_FLASHBACK_ARCHIVE.STATUS is 'Indicates whether the flashback archive is a default flashback archive for the system'
/

