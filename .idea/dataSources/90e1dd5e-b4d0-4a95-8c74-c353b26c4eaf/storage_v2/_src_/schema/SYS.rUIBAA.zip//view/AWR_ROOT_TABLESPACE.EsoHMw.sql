create view AWR_ROOT_TABLESPACE
            (DBID, TS#, TSNAME, CONTENTS, SEGMENT_SPACE_MANAGEMENT, EXTENT_MANAGEMENT, BLOCK_SIZE, CON_DBID, CON_ID) as
select tbs.dbid, tbs.ts#, tbs.tsname, tbs.contents,
       tbs.segment_space_management, tbs.extent_management, tbs.block_size,
       decode(tbs.con_dbid, 0, tbs.dbid, tbs.con_dbid),
       decode(tbs.per_pdb, 0, 0,
         con_dbid_to_id(
           decode(tbs.con_dbid, 0, tbs.dbid, tbs.con_dbid))) con_id
  from WRH$_TABLESPACE tbs
/

comment on table AWR_ROOT_TABLESPACE is 'Tablespace Static Information'
/

