create view USER_JOINGROUPS (JOINGROUP_NAME, TABLE_OWNER, TABLE_NAME, COLUMN_NAME, FLAGS, GD_ADDRESS) as
select JOINGROUP_NAME, TABLE_OWNER, TABLE_NAME,
       COLUMN_NAME, a.FLAGS as FLAGS, b.head_address as GD_ADDRESS
from
(select id.objn, id.col#, jg.name as JOINGROUP_NAME, o.name as TABLE_NAME,
        u1.name as TABLE_OWNER,
        oc.name as COLUMN_NAME, id.flags as FLAGS, id.domain# as domain#
   from im_domain$ id, im_joingroup$ jg, obj$ o, user$ u1, user$ u2,
        col$ oc
  where id.domain# = jg.domain# and
        id.flags = 1 and
        id.objn = o.obj# and
        u1.user# = o.owner# and
        u2.user# = jg.owner# and
        id.objn = oc.obj# and
        id.col# = oc.intcol# and
        u2.user# = userenv('SCHEMAID')) a
left outer join
        v$im_globaldict b
    on a.domain# = b.domain#
/

comment on table USER_JOINGROUPS is 'Join groups belonging to the user'
/

comment on column USER_JOINGROUPS.JOINGROUP_NAME is 'Join group name'
/

comment on column USER_JOINGROUPS.TABLE_OWNER is 'Table owner'
/

comment on column USER_JOINGROUPS.TABLE_NAME is 'Table name'
/

comment on column USER_JOINGROUPS.COLUMN_NAME is 'Column name'
/

comment on column USER_JOINGROUPS.FLAGS is 'Flags'
/

comment on column USER_JOINGROUPS.GD_ADDRESS is 'Global dictionary address'
/

