create view DBA_OPARGUMENTS (OWNER, OPERATOR_NAME, BINDING#, POSITION, ARGUMENT_TYPE) as
select  c.name, b.name, a.bind#, a.position, a.type
  from  sys.oparg$ a, sys.obj$ b, sys.user$ c
  where a.obj# = b.obj# and b.owner# = c.user#
/

comment on table DBA_OPARGUMENTS is 'All operator arguments'
/

comment on column DBA_OPARGUMENTS.OWNER is 'Owner of the operator'
/

comment on column DBA_OPARGUMENTS.OPERATOR_NAME is 'Name of the operator'
/

comment on column DBA_OPARGUMENTS.BINDING# is 'Binding# of the operator'
/

comment on column DBA_OPARGUMENTS.POSITION is 'Position of the operator argument'
/

comment on column DBA_OPARGUMENTS.ARGUMENT_TYPE is 'Datatype of the operator argument'
/

