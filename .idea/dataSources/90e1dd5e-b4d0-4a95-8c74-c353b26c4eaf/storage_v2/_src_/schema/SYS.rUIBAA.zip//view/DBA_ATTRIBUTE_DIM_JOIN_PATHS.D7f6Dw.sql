create view DBA_ATTRIBUTE_DIM_JOIN_PATHS
            (OWNER, DIMENSION_NAME, JOIN_PATH_NAME, ON_CONDITION, ORDER_NUM, ORIGIN_CON_ID) as
select OWNER, DIMENSION_NAME, JOIN_PATH_NAME, ON_CONDITION, ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_ATTR_DIM_JOIN_PATHS
/

comment on table DBA_ATTRIBUTE_DIM_JOIN_PATHS is 'Attribute dimension join paths in the database'
/

comment on column DBA_ATTRIBUTE_DIM_JOIN_PATHS.OWNER is 'Owner of the attribute dimension join path'
/

comment on column DBA_ATTRIBUTE_DIM_JOIN_PATHS.DIMENSION_NAME is 'Name of the owning attribute dimension join path'
/

comment on column DBA_ATTRIBUTE_DIM_JOIN_PATHS.JOIN_PATH_NAME is 'Name of the attribute dimension join path'
/

comment on column DBA_ATTRIBUTE_DIM_JOIN_PATHS.ON_CONDITION is 'Condition of the attribute dimension join path'
/

comment on column DBA_ATTRIBUTE_DIM_JOIN_PATHS.ORDER_NUM is 'Order number of Dimension join path within the Dimension'
/

comment on column DBA_ATTRIBUTE_DIM_JOIN_PATHS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

