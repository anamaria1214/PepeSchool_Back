create view TABPARTV$
            (OBJ#, DATAOBJ#, BO#, PART#, HIBOUNDLEN, HIBOUNDVAL, TS#, FILE#, BLOCK#, PCTFREE$, PCTUSED$, INITRANS,
             MAXTRANS, FLAGS, ANALYZETIME, SAMPLESIZE, ROWCNT, BLKCNT, EMPCNT, AVGSPC, CHNCNT, AVGRLN, PHYPART#)
as
select obj#, dataobj#, bo#,
          row_number() over (partition by bo# order by part#),
          hiboundlen, hiboundval, ts#, file#, block#, pctfree$, pctused$,
          initrans, maxtrans, flags, analyzetime, samplesize, rowcnt, blkcnt,
          empcnt, avgspc, chncnt, avgrln, part#
from tabpart$
where bitand(flags, 8388608) = 0           /* filter out hidden partitions */
/

