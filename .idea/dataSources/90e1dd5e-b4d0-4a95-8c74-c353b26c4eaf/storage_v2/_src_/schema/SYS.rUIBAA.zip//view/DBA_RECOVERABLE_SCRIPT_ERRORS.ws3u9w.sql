create view DBA_RECOVERABLE_SCRIPT_ERRORS (SCRIPT_ID, BLOCK_NUM, ERROR_NUMBER, ERROR_MESSAGE, ERROR_CREATION_TIME) as
select oid, block_num, error_number, error_message, error_creation_time
from sys.reco_script_error$
/

comment on table DBA_RECOVERABLE_SCRIPT_ERRORS is 'Details showing errors during script execution'
/

comment on column DBA_RECOVERABLE_SCRIPT_ERRORS.SCRIPT_ID is 'global unique id of the recoverable script'
/

comment on column DBA_RECOVERABLE_SCRIPT_ERRORS.BLOCK_NUM is 'nth block that failed'
/

comment on column DBA_RECOVERABLE_SCRIPT_ERRORS.ERROR_NUMBER is 'error number of error encountered while executing the block'
/

comment on column DBA_RECOVERABLE_SCRIPT_ERRORS.ERROR_MESSAGE is 'error message of error encountered while executing the block'
/

comment on column DBA_RECOVERABLE_SCRIPT_ERRORS.ERROR_CREATION_TIME is 'time error was created'
/

