create view DBA_CAPTURE_PREPARED_SCHEMAS
            (SCHEMA_NAME, TIMESTAMP, SUPPLEMENTAL_LOG_DATA_PK, SUPPLEMENTAL_LOG_DATA_UI, SUPPLEMENTAL_LOG_DATA_FK,
             SUPPLEMENTAL_LOG_DATA_ALL)
as
select u.name, pd.timestamp,
       decode(bitand(u.spare1, 1), 1,
              decode(bitand(pd.flags, 1), 1, 'IMPLICIT', 'EXPLICIT'), 'NO'),
       decode(bitand(u.spare1, 2), 2,
              decode(bitand(pd.flags, 2), 2, 'IMPLICIT', 'EXPLICIT'), 'NO'),
       decode(bitand(u.spare1, 4), 4,
              decode(bitand(pd.flags, 4), 4, 'IMPLICIT', 'EXPLICIT'), 'NO'),
       decode(bitand(u.spare1, 8), 8,
              decode(bitand(pd.flags, 8), 8, 'IMPLICIT', 'EXPLICIT'), 'NO')
  from streams$_prepare_ddl pd, user$ u
 where u.user# = pd.usrid and global_flag = 0
/

comment on table DBA_CAPTURE_PREPARED_SCHEMAS is 'All schemas at the local database that are prepared for instantiation'
/

comment on column DBA_CAPTURE_PREPARED_SCHEMAS.SCHEMA_NAME is 'Name of schema prepared for instantiation'
/

comment on column DBA_CAPTURE_PREPARED_SCHEMAS.TIMESTAMP is 'Time at which the schema was ready to be instantiated'
/

comment on column DBA_CAPTURE_PREPARED_SCHEMAS.SUPPLEMENTAL_LOG_DATA_PK is 'Status of schema-level PRIMARY KEY COLUMNS supplemental logging'
/

comment on column DBA_CAPTURE_PREPARED_SCHEMAS.SUPPLEMENTAL_LOG_DATA_UI is 'Status of schema-level UNIQUE INDEX COLUMNS supplemental logging'
/

comment on column DBA_CAPTURE_PREPARED_SCHEMAS.SUPPLEMENTAL_LOG_DATA_FK is 'Status of schema-level FOREIGN KEY COLUMNS supplemental logging'
/

comment on column DBA_CAPTURE_PREPARED_SCHEMAS.SUPPLEMENTAL_LOG_DATA_ALL is 'Status of schema-level ALL COLUMNS supplemental logging'
/

