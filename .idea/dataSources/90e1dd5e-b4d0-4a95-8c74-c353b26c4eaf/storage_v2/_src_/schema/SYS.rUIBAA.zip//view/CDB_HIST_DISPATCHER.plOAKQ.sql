create view CDB_HIST_DISPATCHER
            (SNAP_ID, DBID, INSTANCE_NUMBER, NAME, SERIAL#, IDLE, BUSY, WAIT, TOTALQ, SAMPLED_TOTAL_CONN, CON_DBID,
             CON_ID) as
SELECT k."SNAP_ID",k."DBID",k."INSTANCE_NUMBER",k."NAME",k."SERIAL#",k."IDLE",k."BUSY",k."WAIT",k."TOTALQ",k."SAMPLED_TOTAL_CONN",k."CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_DISPATCHER") k
/

comment on table CDB_HIST_DISPATCHER is 'Dispatcher statistics in all containers'
/

comment on column CDB_HIST_DISPATCHER.CON_ID is 'container id'
/

