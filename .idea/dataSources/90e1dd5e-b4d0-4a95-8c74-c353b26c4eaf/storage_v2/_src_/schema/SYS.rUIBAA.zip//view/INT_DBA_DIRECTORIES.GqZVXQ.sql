create view INT$DBA_DIRECTORIES
            (OWNER, DIRECTORY_NAME, OBJECT_ID, OBJECT_TYPE#, DIRECTORY_PATH, SHARING, ORIGIN_CON_ID) as
select u.name, o.name, o.obj#, o.type#, d.os_path,
       case when bitand(o.flags, 196608)>0 then 1 else 0 end,
       to_number(sys_context('USERENV', 'CON_ID'))
from sys.user$ u, sys.obj$ o, sys.x$dir d
where u.user# = o.owner#
  and o.obj# = d.obj#
/

