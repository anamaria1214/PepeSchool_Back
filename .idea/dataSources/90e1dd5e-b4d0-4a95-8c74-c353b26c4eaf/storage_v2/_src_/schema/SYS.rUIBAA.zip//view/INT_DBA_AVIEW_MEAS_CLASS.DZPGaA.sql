create view INT$DBA_AVIEW_MEAS_CLASS
            (OWNER, ANALYTIC_VIEW_NAME, OWNER_ID, OBJECT_ID, OBJECT_TYPE, MEASURE_NAME, CLASSIFICATION, VALUE, LANGUAGE,
             ORDER_NUM, SHARING, ORIGIN_CON_ID)
as
select u.name owner,
       o.name ANALYTIC_VIEW_NAME,
       o.owner# owner_id,
       o.obj# object_id,
       o.type# object_type,
       m.meas_name measure_name,
       c.clsfction_name classification,
       c.clsfction_value value,
       c.clsfction_lang language,
       c.order_num order_num,
       case when bitand(o.flags, 196608)>0 then 1 else 0 end sharing,
       to_number(sys_context('USERENV','CON_ID')) origin_con_id
from   sys.obj$ o, hcs_clsfctn$ c, user$ u, hcs_av_meas$ m
where   u.user# = o.owner#
        and c.obj# = o.obj#
        and c.obj_type = '7' -- MEASURE
        and m.av# = c.obj#
        and m.meas# = c.sub_obj#
/

