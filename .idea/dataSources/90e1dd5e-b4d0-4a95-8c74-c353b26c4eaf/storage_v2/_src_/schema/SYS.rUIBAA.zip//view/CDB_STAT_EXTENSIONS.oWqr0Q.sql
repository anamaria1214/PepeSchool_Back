create view CDB_STAT_EXTENSIONS (OWNER, TABLE_NAME, EXTENSION_NAME, EXTENSION, CREATOR, DROPPABLE, CON_ID) as
SELECT k."OWNER",k."TABLE_NAME",k."EXTENSION_NAME",k."EXTENSION",k."CREATOR",k."DROPPABLE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_STAT_EXTENSIONS") k
/

comment on table CDB_STAT_EXTENSIONS is 'Optimizer statistics extensions in all containers'
/

comment on column CDB_STAT_EXTENSIONS.OWNER is 'Owner of the extension'
/

comment on column CDB_STAT_EXTENSIONS.TABLE_NAME is 'Name of the table to which the extension belongs'
/

comment on column CDB_STAT_EXTENSIONS.EXTENSION_NAME is 'The extension (the expression or column group)'
/

comment on column CDB_STAT_EXTENSIONS.DROPPABLE is 'Is this extension drppable using dbms_stats.drop_extended_stats ?'
/

comment on column CDB_STAT_EXTENSIONS.CON_ID is 'container id'
/

