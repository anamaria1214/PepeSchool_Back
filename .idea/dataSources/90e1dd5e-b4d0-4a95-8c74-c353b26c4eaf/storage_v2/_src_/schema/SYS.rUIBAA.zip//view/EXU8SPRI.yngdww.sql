create view EXU8SPRI (OWNERID, UNAME, ID, NAME, TIME, TYPEID, TYPE, AUDT, SQLVER) as
SELECT  s."OWNERID",s."UNAME",s."ID",s."NAME",s."TIME",s."TYPEID",s."TYPE",s."AUDT",s."SQLVER"
        FROM    sys.exu8spr s, sys.incexp i, sys.incvid v
        WHERE   s.name = i.name(+) AND
                s.ownerid = i.owner#(+) AND
                NVL(i.type#, 7) IN (7, 8, 9, 11) AND
                NVL(i.expid, 9999) > v.expid
/

