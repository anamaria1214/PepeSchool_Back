create view AWR_ROOT_RSRC_PDB_METRIC
            (SNAP_ID, DBID, INSTANCE_NUMBER, BEGIN_TIME, END_TIME, INTSIZE_CSEC, SEQUENCE#, CPU_CONSUMED_TIME,
             CPU_WAIT_TIME, AVG_RUNNING_SESSIONS, AVG_WAITING_SESSIONS, AVG_CPU_UTILIZATION, IOPS, IOMBPS,
             IOPS_THROTTLE_EXEMPT, IOMBPS_THROTTLE_EXEMPT, AVG_IO_THROTTLE, AVG_ACTIVE_PARALLEL_STMTS,
             AVG_QUEUED_PARALLEL_STMTS, AVG_ACTIVE_PARALLEL_SERVERS, AVG_QUEUED_PARALLEL_SERVERS, SGA_BYTES,
             BUFFER_CACHE_BYTES, SHARED_POOL_BYTES, PGA_BYTES, PLAN_ID, CON_DBID, CON_ID, MAX_AVG_RUNNING_SESSIONS)
as
select
  rm.snap_id,
  rm.dbid,
  rm.instance_number,
  rm.begin_time,
  rm.end_time,
  rm.intsize_csec,                                           /* centiseconds */
  rm.sequence#,
  rm.cpu_consumed_time,                                      /* milliseconds */
  rm.cpu_wait_time,                                          /* milliseconds */
  rm.cpu_consumed_time  / (10 * rm.intsize_csec),    /* avg running sessions */
  rm.cpu_wait_time      / (10 * rm.intsize_csec),    /* avg waiting sessions */
  decode(rm.os_num_cpus, 0, 0,
         (10 * rm.cpu_consumed_time / rm.intsize_csec / rm.os_num_cpus)),
  rm.io_requests  / (rm.intsize_csec / 100),      /* I/O requests per second */
  rm.io_megabytes / (rm.intsize_csec / 100),     /* I/O megabytes per second */
  rm.io_requests_throttle_exempt  / (rm.intsize_csec / 100),
                           /* I/O requests per second exempt from throttling */
  rm.io_megabytes_throttle_exempt / (rm.intsize_csec / 100),
                          /* I/O megabytes per second exempt from throttling */
  decode(rm.io_requests, 0, 0,      /* avg I/O throttle time per I/O request */
         rm.io_throttle_time / rm.io_requests),
  rm.pq_active_time / (10 * rm.intsize_csec),   /* avg active parallel stmts */
  rm.pq_queued_time / (10 * rm.intsize_csec),   /* avg queued parallel stmts */
  rm.ps_active_time / (10 * rm.intsize_csec),/* avg running parallel servers */
  rm.ps_queued_time / (10 * rm.intsize_csec),/* avg parallel servers requested
                                              * by queued parallel servers   */
  rm.sga_bytes,                                                     /* bytes */
  rm.buffer_cache_bytes,                                            /* bytes */
  rm.shared_pool_bytes,                                             /* bytes */
  rm.pga_bytes,                                                     /* bytes */
  rm.plan_id,
  decode(rm.con_dbid, 0, rm.dbid, rm.con_dbid),
  decode(rm.per_pdb, 0, 0,
    con_dbid_to_id(decode(rm.con_dbid, 0, rm.dbid, rm.con_dbid))) con_id,
  rm.max_avg_rng_sess                        /* max average running sessions */
  from AWR_ROOT_SNAPSHOT sn, WRH$_RSRC_PDB_METRIC rm
  where     rm.dbid            = sn.dbid
        and rm.snap_id         = sn.snap_id
        and rm.instance_number = sn.instance_number
/

comment on table AWR_ROOT_RSRC_PDB_METRIC is 'Historical resource manager metrics by PDB'
/

