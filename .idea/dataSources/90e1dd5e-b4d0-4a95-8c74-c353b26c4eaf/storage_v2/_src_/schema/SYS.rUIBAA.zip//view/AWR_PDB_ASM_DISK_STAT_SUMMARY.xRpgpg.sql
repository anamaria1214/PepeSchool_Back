create view AWR_PDB_ASM_DISK_STAT_SUMMARY
            (SNAP_ID, DBID, INSTANCE_NUMBER, GROUP_NUMBER, READS, WRITES, READ_ERRS, WRITE_ERRS, READ_TIMEOUT,
             WRITE_TIMEOUT, READ_TIME, WRITE_TIME, BYTES_READ, BYTES_WRITTEN, CON_DBID, CON_ID)
as
select snap_id, dbid, instance_number, GROUP_NUMBER,
       READS, WRITES, READ_ERRS, WRITE_ERRS, READ_TIMEOUT, WRITE_TIMEOUT,
       READ_TIME, WRITE_TIME, BYTES_READ, BYTES_WRITTEN,
       decode(con_dbid, 0, dbid, con_dbid),
       decode(per_pdb, 0, 0,
         con_dbid_to_id(decode(con_dbid, 0, dbid, con_dbid))) con_id
  from WRH$_ASM_DISK_STAT_SUMMARY
/

comment on table AWR_PDB_ASM_DISK_STAT_SUMMARY is 'Statistics for ASM Disk summary statistics'
/

