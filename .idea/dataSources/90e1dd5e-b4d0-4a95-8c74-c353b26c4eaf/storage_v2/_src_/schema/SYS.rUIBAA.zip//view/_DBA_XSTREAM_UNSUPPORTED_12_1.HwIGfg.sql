create view "_DBA_XSTREAM_UNSUPPORTED_12_1" (OWNER, TABLE_NAME) as
select owner, table_name from dba_logstdby_unsupported_table where owner
  not in ('SYS', 'SYSTEM', 'CTXSYS', 'DBSNMP', 'LBACSYS', 'MDDATA', 'MDSYS',
     'DMSYS', 'OLAPSYS', 'ORDPLUGINS', 'ORDSYS', 'SI_INFORMTN_SCHEMA',
     'SYSMAN', 'OUTLN', 'EXFSYS', 'WMSYS', 'XDB', 'DVSYS', 'ORDDATA')
  and owner not like 'APEX_%' and owner not like 'FLOWS_%'
/

