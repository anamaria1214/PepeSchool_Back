create view "_DBA_APPLY_INST_OBJECTS"
            (SOURCE_DATABASE, SOURCE_OBJECT_OWNER, SOURCE_OBJECT_NAME, SOURCE_OBJECT_TYPE,
             INSTANTIATION_EXTERNAL_POS) as
select source_db_name, owner, name,
       type, inst_external_pos
  from "_DBA_APPLY_SOURCE_OBJ"
/

comment on table "_DBA_APPLY_INST_OBJECTS" is 'Details about objects instantiated'
/

comment on column "_DBA_APPLY_INST_OBJECTS".SOURCE_DATABASE is 'Name of the database where the objects originated'
/

comment on column "_DBA_APPLY_INST_OBJECTS".SOURCE_OBJECT_OWNER is 'Owner of the object at the source database'
/

comment on column "_DBA_APPLY_INST_OBJECTS".SOURCE_OBJECT_NAME is 'Name of the object at source'
/

comment on column "_DBA_APPLY_INST_OBJECTS".SOURCE_OBJECT_TYPE is 'Type of the object at source'
/

comment on column "_DBA_APPLY_INST_OBJECTS".INSTANTIATION_EXTERNAL_POS is 'Point in time when the object was instantiated at source'
/

