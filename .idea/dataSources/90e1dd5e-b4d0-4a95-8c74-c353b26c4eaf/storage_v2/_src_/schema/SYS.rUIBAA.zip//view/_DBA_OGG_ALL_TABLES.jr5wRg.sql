create view "_DBA_OGG_ALL_TABLES" (OWNER, TABLE_NAME, GENSBY, EXPLANATION) as
with redo_compat as
         (select nvl((select min(s.redo_compat)
                      from system.logstdby$parameters p,
                           system.logmnr_session$ s
                      where p.name in ('LMNR_SID', 'FUTURE_SESSION') and
                            p.value = s.session#),
                     (select p.value
                      from sys.v$parameter p
                      where p.name = 'compatible')) compat
          from dual)
select owner, name table_name, gensby, explanation from
  (
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_support_tab_10_1 u, redo_compat c
    where c.compat like '10.0%' or c.compat like '10.1%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_support_tab_10_2 u, redo_compat c
    where c.compat like '10.2%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_support_tab_11_1 u, redo_compat c
    where c.compat like '11.0%' or c.compat like '11.1%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from ogg_support_tab_11_2 u, redo_compat c
    where c.compat like '11.2%' and c.compat not like '11.2.0.3%'
                                and c.compat not like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from ogg_support_tab_11_2b u, redo_compat c
    where c.compat like '11.2.0.3%' or c.compat like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from ogg_support_tab_12_1 u, redo_compat c
    where c.compat like '12.0%' or c.compat like '12.1%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from ogg_support_tab_12_2 u, redo_compat c
    where c.compat like '12.2%' and c.compat not like '12.2.0.2%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from ogg_support_tab_12_2_0_2 u, redo_compat c
    where c.compat like '12.2.0.2%' or c.compat like '18.0%'
          or c.compat like '18.1%'
    UNION ALL
    -- If replication metadata maintenance is disabled via event, then we must
    -- use the 19.0 compat-specific view.
    select u.owner, u.name, u.gensby, '' explanation
    from ogg_support_tab_19 u, redo_compat c
    where c.compat like '19.%' or
          (c.compat like '2%.%' and
           sys_context('userenv', 'IS_REPL_META_DISABLED') = 'TRUE')
    UNION ALL
    select u.owner, u.name, u.gensby, u.explanation
    from ogg_support_tab_common u, redo_compat c
    where c.compat like '2%.%' and
          sys_context('userenv', 'IS_REPL_META_DISABLED') = 'FALSE'
  )
  where owner not like 'APEX_%' and owner not like 'FLOWS_%'
/

