create view INT$AUDIT_UNIFIED_POLICIES
            (POLICY_NAME, AUDIT_CONDITION, CONDITION_EVAL_OPT, AUDIT_OPTION, AUDIT_OPTION_TYPE, OBJECT_SCHEMA,
             OBJECT_NAME, OBJECT_TYPE, COMMON, INHERITED, AUDIT_ONLY_TOPLEVEL, SHARING, ORIGIN_CON_ID, ORACLE_SUPPLIED)
as
select obj.name,
       NVL(pol.condition, 'NONE'),
       decode(pol.condition_eval, 1, 'STATEMENT',
                                  2, 'SESSION',
                                  3, 'INSTANCE', 'NONE'),
       spm.name,
       'SYSTEM PRIVILEGE',
       'NONE',
       'NONE',
       'NONE',
       decode(bitand(pol.type, 152), 8, 'NO', 16, 'YES', 128, 'YES', NULL),
       decode(bitand(pol.type, 152),
              8, 'NO',
              16, decode(SYS_CONTEXT('USERENV', 'CON_ID'), 1, 'NO', 'YES'),
              128, decode(SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB'),
                          'YES', 'YES', 'NO')),
       decode(bitand(pol.type, 256), 256, 'YES', 'NO'),
       case when bitand(obj.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
       to_number(sys_context('USERENV', 'CON_ID')),
       decode(bitand(pol.type, 512),
              512, 'YES', 'NO')
from sys.obj$ obj, sys.aud_policy$ pol, sys.system_privilege_map spm
where obj.obj# = pol.policy# and
      bitand(pol.type, 1) = 1 and
      substr(pol.syspriv, -spm.privilege+1, 1) = 'S'
UNION all
select obj.name,
       NVL(pol.condition, 'NONE'),
       decode(pol.condition_eval, 1, 'STATEMENT',
                                  2, 'SESSION',
                                  3, 'INSTANCE', 'NONE'),
       asa.name,
       decode(asa.type, 4,  'STANDARD ACTION',
                        6,  'XS ACTION',
                        8,  'OLS ACTION',
                        10, 'DATAPUMP ACTION',
                        11, 'DIRECT_LOAD ACTION',
                        13, 'PROTOCOL ACTION', 'NONE'),
       'NONE',
       'NONE',
       'NONE',
       decode(bitand(pol.type, 152), 8, 'NO', 16, 'YES', 128, 'YES', NULL),
       decode(bitand(pol.type, 152),
              8, 'NO',
              16, decode(SYS_CONTEXT('USERENV', 'CON_ID'), 1, 'NO', 'YES'),
              128, decode(SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB'),
                          'YES', 'YES', 'NO')),
       decode(bitand(pol.type, 256), 256, 'YES', 'NO'),
       case when bitand(obj.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
       to_number(sys_context('USERENV', 'CON_ID')),
       decode(bitand(pol.type, 512),
              512, 'YES', 'NO')
from sys.obj$ obj, sys.aud_policy$ pol, sys.auditable_system_actions asa
where obj.obj# = pol.policy# and
      bitand(pol.type, 2) = 2 and
      ((asa.type = 4 and              /* selecting STANDARD ACTION options */
        substr(pol.sysactn, asa.action+1, 1) = 'S') or
       (asa.type = 6 and                    /* selecting XS ACTION options */
        substr(pol.sysactn,
               ((select max(action)+1 from sys.auditable_system_actions
                               where type = 4) + asa.action + 1), 1) = 'S') or
       (asa.type = 8 and                   /* selecting OLS ACTION options */
        substr(pol.sysactn,
               (((select max(action)+1 from sys.auditable_system_actions
                               where type = 4) +
                 (select count(*)+1 from sys.auditable_system_actions
                               where type = 6)) + asa.action + 1), 1) = 'S') or
       (asa.type = 10 and             /* selecting DATAPUMP ACTION options */
        substr(pol.sysactn,
               (((select max(action)+1 from sys.auditable_system_actions
                               where type = 4) +
                 (select count(*)+1 from sys.auditable_system_actions
                               where type = 6) +
                 (select count(*)+1 from sys.auditable_system_actions
                               where type = 8)) + asa.action + 1), 1) = 'S') or
       (asa.type = 11 and          /* selecting DIRECT_LOAD ACTION options */
       substr(pol.sysactn,
               (((select max(action)+1 from sys.auditable_system_actions
                               where type = 4) +
                 (select count(*)+1 from sys.auditable_system_actions
                               where type = 6) + /

