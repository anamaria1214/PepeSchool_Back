create view CDB_HIST_WAITSTAT (SNAP_ID, DBID, INSTANCE_NUMBER, CLASS, WAIT_COUNT, TIME, CON_DBID, CON_ID) as
SELECT k."SNAP_ID",k."DBID",k."INSTANCE_NUMBER",k."CLASS",k."WAIT_COUNT",k."TIME",k."CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_WAITSTAT") k
/

comment on table CDB_HIST_WAITSTAT is 'Wait Historical Statistics Information in all containers'
/

comment on column CDB_HIST_WAITSTAT.CON_ID is 'container id'
/

