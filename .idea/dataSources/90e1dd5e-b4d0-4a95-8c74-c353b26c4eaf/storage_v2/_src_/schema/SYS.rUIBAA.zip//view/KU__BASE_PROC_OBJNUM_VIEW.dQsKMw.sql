create view KU$_BASE_PROC_OBJNUM_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, TYPE_NUM, SCHEMA_OBJ) as
select '1','1',
         oo.obj#,
         oo.type#,
         value(o)
  from  sys.ku$_edition_schemaobj_view o, sys.ku$_edition_obj_view oo
  where (oo.type# = 7 or oo.type# = 8 or oo.type# = 9 or oo.type# = 11)
    and oo.obj#  = o.obj_num and oo.linkname is NULL
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles WHERE role='SELECT_CATALOG_ROLE'))
/

