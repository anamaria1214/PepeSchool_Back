create view AWR_ROOT_ACTIVE_SESS_HISTORY
            (SNAP_ID, DBID, INSTANCE_NUMBER, SAMPLE_ID, SAMPLE_TIME, SAMPLE_TIME_UTC, USECS_PER_ROW, SESSION_ID,
             SESSION_SERIAL#, SESSION_TYPE, FLAGS, USER_ID, SQL_ID, IS_SQLID_CURRENT, SQL_CHILD_NUMBER, SQL_OPCODE,
             SQL_OPNAME, FORCE_MATCHING_SIGNATURE, TOP_LEVEL_SQL_ID, TOP_LEVEL_SQL_OPCODE, SQL_PLAN_HASH_VALUE,
             SQL_FULL_PLAN_HASH_VALUE, SQL_ADAPTIVE_PLAN_RESOLVED, SQL_PLAN_LINE_ID, SQL_PLAN_OPERATION,
             SQL_PLAN_OPTIONS, SQL_EXEC_ID, SQL_EXEC_START, PLSQL_ENTRY_OBJECT_ID, PLSQL_ENTRY_SUBPROGRAM_ID,
             PLSQL_OBJECT_ID, PLSQL_SUBPROGRAM_ID, QC_INSTANCE_ID, QC_SESSION_ID, QC_SESSION_SERIAL#, PX_FLAGS, EVENT,
             EVENT_ID, SEQ#, P1TEXT, P1, P2TEXT, P2, P3TEXT, P3, WAIT_CLASS, WAIT_CLASS_ID, WAIT_TIME, SESSION_STATE,
             TIME_WAITED, BLOCKING_SESSION_STATUS, BLOCKING_SESSION, BLOCKING_SESSION_SERIAL#, BLOCKING_INST_ID,
             BLOCKING_HANGCHAIN_INFO, CURRENT_OBJ#, CURRENT_FILE#, CURRENT_BLOCK#, CURRENT_ROW#, TOP_LEVEL_CALL#,
             TOP_LEVEL_CALL_NAME, CONSUMER_GROUP_ID, XID, REMOTE_INSTANCE#, TIME_MODEL, IN_CONNECTION_MGMT, IN_PARSE,
             IN_HARD_PARSE, IN_SQL_EXECUTION, IN_PLSQL_EXECUTION, IN_PLSQL_RPC, IN_PLSQL_COMPILATION, IN_JAVA_EXECUTION,
             IN_BIND, IN_CURSOR_CLOSE, IN_SEQUENCE_LOAD, IN_INMEMORY_QUERY, IN_INMEMORY_POPULATE,
             IN_INMEMORY_PREPOPULATE, IN_INMEMORY_REPOPULATE, IN_INMEMORY_TREPOPULATE, IN_TABLESPACE_ENCRYPTION,
             CAPTURE_OVERHEAD, REPLAY_OVERHEAD, IS_CAPTURED, IS_REPLAYED, IS_REPLAY_SYNC_TOKEN_HOLDER, SERVICE_HASH,
             PROGRAM, MODULE, ACTION, CLIENT_ID, MACHINE, PORT, ECID, DBREPLAY_FILE_ID, DBREPLAY_CALL_COUNTER,
             TM_DELTA_TIME, TM_DELTA_CPU_TIME, TM_DELTA_DB_TIME, DELTA_TIME, DELTA_READ_IO_REQUESTS,
             DELTA_WRITE_IO_REQUESTS, DELTA_READ_IO_BYTES, DELTA_WRITE_IO_BYTES, DELTA_INTERCONNECT_IO_BYTES,
             PGA_ALLOCATED, TEMP_SPACE_ALLOCATED, DBOP_NAME, DBOP_EXEC_ID, CON_DBID, CON_ID)
as
select /* ASH/AWR meta attributes */
       ash.snap_id, ash.dbid, ash.instance_number,
       ash.sample_id, ash.sample_time, ash.sample_time_utc,
       ash.usecs_per_row,
       /* Session/User attributes */
       ash.session_id, ash.session_serial#,
       decode(ash.session_type, 1,'FOREGROUND', 'BACKGROUND'),
       ash.flags,
       ash.user_id,
       /* SQL attributes */
       ash.sql_id,
       decode(bitand(ash.flags, power(2, 4)), NULL, 'N', 0, 'N', 'Y'),
       ash.sql_child_number, ash.sql_opcode,
       (select command_name
          from WRH$_SQLCOMMAND_NAME s
         where s.command_type = ash.sql_opcode
           and s.dbid = ash.dbid
           and  rownum = 1) as sql_opname,
       ash.force_matching_signature,
       decode(ash.top_level_sql_id, NULL, ash.sql_id, ash.top_level_sql_id),
       decode(ash.top_level_sql_id, NULL, ash.sql_opcode,
              ash.top_level_sql_opcode),
       /* SQL Plan/Execution attributes */
       ash.sql_plan_hash_value,
       ash.sql_full_plan_hash_value,
       ash.sql_adaptive_plan_resolved,
       decode(ash.sql_plan_line_id, 0, to_number(NULL), ash.sql_plan_line_id),
       (select operation_name
          from WRH$_PLAN_OPERATION_NAME pn
         where  pn.operation_id = ash.sql_plan_operation#
           and  pn.dbid = ash.dbid
           and  rownum = 1) as sql_plan_operation,
       (select option_name
          from WRH$_PLAN_OPTION_NAME po
         where  po.option_id = ash.sql_plan_options#
           and  po.dbid = ash.dbid
           and  rownum = 1) as sql_plan_options,
       decode(ash.sql_exec_id, 0, to_number(NULL), ash.sql_exec_id),
       ash.sql_exec_start,
       /* PL/SQL attributes */
       decode(ash.plsql_entry_object_id,0,to_number(NULL),
              ash.plsql_entry_object_id),
       decode(ash.plsql_entry_object_id,0,to_number(NULL),
              ash.plsql_entry_subprogram_id),
       decode(ash.plsql_object_id,0,to_number(NULL),
              ash.plsql_object_id),
       decode(ash.plsql_object_id,0,to_number(NULL),
              ash.plsql_subprogram_id),
       /* PQ attributes */
       decode(ash.qc_session_id, 0, to_number(NULL), ash.qc_instance_id),
       decode(ash.qc_session_id, 0, to_number(NULL), ash.qc_session_id),
       decode(ash.qc_session_id, 0, to_number(NULL), ash.qc_session_serial#),
       decode(ash.px_flags,      0, to_number(NULL), ash.px_flags),
       /* Wait event attributes */
       decode(ash.wait_time, 0, evt.event_name, NULL),
       decode(ash.wait_time, 0, evt.event_id,   NULL),
       ash.seq#,
       evt.parameter1, ash.p1,
       evt.parameter2, ash.p2,
       evt.parameter3, ash.p3,
       decode(ash.wait_time, 0, evt.wait_class,    NULL),
       decode(ash.wait_time, 0, evt.wait_class_id, NULL),
       ash.wait_time,
       decode(ash.wait_time, 0, 'WAITING', 'ON CPU'),
       ash.time_waited,
       (case when ash.blocking_session = 4294967295
               then 'UNKNOWN'
             when ash.blocking_session = 4294967294
               then 'GLOBAL'
             when ash.blocking_session = 4294967293
               then 'UNKNOWN'
             when ash.blocking_session = 4294967292
               then 'NO HOLDER'
             when ash.blocking_session = 4294967291
               then 'NOT IN WAIT'
             else 'VALID'
        end),
       (case when ash.blocking_session between 4294967291 and 4294967295
               then to_number(NULL)
             else ash.blocking_session
        end),
       (case when ash.blocking_session between 4294967291 and 4294967295
               then to_number(NULL)
             else ash.blocking_session_serial#
        end),
       (case when ash.blocking_session between 4294967291 and 4294967295
               then to_number(NULL)
             else ash.blocking_inst_id
          end),
       (case when ash.blocking_session between 4294967291 and 4294967295
               then NULL
             else decode(bitand(ash.flags, power(2, 3)), NULL, 'N',
                 /
                 
                 comment on table AWR_ROOT_ACTIVE_SESS_HISTORY is 'Active Session Historical Statistics Information'
                 /

