create view GV_$ENABLEDPRIVS (INST_ID, PRIV_NUMBER, SCOPE, CON_ID) as
select "INST_ID","PRIV_NUMBER","SCOPE","CON_ID" from gv$enabledprivs
/

