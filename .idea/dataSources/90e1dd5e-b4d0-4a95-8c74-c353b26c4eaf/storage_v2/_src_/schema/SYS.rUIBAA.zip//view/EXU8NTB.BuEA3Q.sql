create view EXU8NTB
            (POBJID, OBJID, NAME, DOBJID, OWNER, OWNERID, TABLESPACE, TSNO, FILENO, BLOCKNO, AUDIT$, COMMENT$,
             CLUSTERFLAG, MTIME, MODIFIED, PCTFREE$, PCTUSED$, INITRANS, MAXTRANS, DEGREE, INSTANCES, CACHE, TEMPFLAGS,
             PROPERTY, DEFLOG, TSDEFLOG, ROID, COLPROP, EXPNAME, ROWCNT, BLKCNT, AVGRLEN, TFLAGS, NTCOLFLGS, INTCOLID,
             OBJSTATUS, COLTYPE)
as
SELECT  nt$.obj#, o$.obj#, o$.name, o$.dataobj#, u$.name, o$.owner#,
                ts$.name, t$.ts#, t$.file#, t$.block#, t$.audit$, c$.comment$,
                NVL(t$.bobj#, 0), o$.mtime,
                DECODE(BITAND(t$.flags, 1), 1, 1, 0), MOD(t$.pctfree$, 100),
                t$.pctused$, t$.initrans, t$.maxtrans, NVL(t$.degree, 1),
                NVL(t$.instances, 1), DECODE(BITAND(t$.flags, 128), 128, 1, 0),
                MOD(TRUNC(o$.flags/2), 2), t$.property,
                DECODE(BITAND(t$.flags, 32), 32, 1, 0), ts$.dflogging, o$.oid$,
                cl$.property,
                DECODE(BITAND(cl$.property, 1), 1, a$.name, cl$.name),
                NVL(t$.rowcnt, -1), NVL(t$.blkcnt, -1), NVL(t$.avgrln, -1),
                t$.flags, NVL(ct$.flags, 0), cl$.intcol#, o$.status,
                cl$.type#
        FROM    sys.tab$ t$, sys.obj$ o$, sys.ts$ ts$, sys.user$ u$,
                sys.com$ c$, sys.ntab$ nt$, sys.col$ cl$, sys.attrcol$ a$,
                sys.coltype$ ct$
        WHERE   t$.obj# = o$.obj# AND
                t$.ts# = ts$.ts# AND
                u$.user# = o$.owner# AND
                o$.obj# = c$.obj#(+) AND
                c$.col#(+) IS NULL AND
                nt$.ntab# = o$.obj# AND
                cl$.obj# = ct$.obj# (+) AND
                cl$.intcol# = ct$.intcol# (+)  AND
                nt$.obj# = cl$.obj# AND
                nt$.intcol# = cl$.intcol# AND
                cl$.obj# = a$.obj# (+) AND
                cl$.intcol# = a$.intcol# (+) AND
                BITAND(cl$.property, 32768) != 32768    /* not unused column */
/

