create view DBA_ROLLING_EVENTS (EVENTID, EVENT_TIME, TYPE, MESSAGE, STATUS, INSTID, REVISION) as
select eventid, event_time,
         decode(type, 1, 'INFO', 2, 'NOTICE', 3, 'WARNING',
                      4, 'ERROR', 5, 'DEBUG', 'NONE') type,
         message, status, instid, revision
       from system.rolling$events
   order by eventid
/

comment on table DBA_ROLLING_EVENTS is 'List of all events reported from DBMS_ROLLING PL/SQL package'
/

comment on column DBA_ROLLING_EVENTS.EVENTID is 'Event identifier which identifies event order'
/

comment on column DBA_ROLLING_EVENTS.EVENT_TIME is 'Time associated with the event'
/

comment on column DBA_ROLLING_EVENTS.TYPE is 'Type of event: INFO, NOTICE, WARNING, or ERROR'
/

comment on column DBA_ROLLING_EVENTS.MESSAGE is 'Text describing the event details'
/

comment on column DBA_ROLLING_EVENTS.STATUS is 'Status code associated with an event'
/

comment on column DBA_ROLLING_EVENTS.INSTID is 'Instruction ID associated with an event'
/

comment on column DBA_ROLLING_EVENTS.REVISION is 'Plan revision number associated with an event'
/

