create view CDB_SCHEDULER_WINDOW_GROUPS
            (WINDOW_GROUP_NAME, ENABLED, NUMBER_OF_WINDOWS, NEXT_START_DATE, COMMENTS, CON_ID) as
SELECT k."WINDOW_GROUP_NAME",k."ENABLED",k."NUMBER_OF_WINDOWS",k."NEXT_START_DATE",k."COMMENTS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SCHEDULER_WINDOW_GROUPS") k
/

comment on table CDB_SCHEDULER_WINDOW_GROUPS is 'All scheduler window groups in the database in all containers'
/

comment on column CDB_SCHEDULER_WINDOW_GROUPS.WINDOW_GROUP_NAME is 'Name of the window group'
/

comment on column CDB_SCHEDULER_WINDOW_GROUPS.ENABLED is 'Whether the window group is enabled'
/

comment on column CDB_SCHEDULER_WINDOW_GROUPS.NUMBER_OF_WINDOWS is 'Number of members in this window group'
/

comment on column CDB_SCHEDULER_WINDOW_GROUPS.NEXT_START_DATE is 'Next start date of this window group'
/

comment on column CDB_SCHEDULER_WINDOW_GROUPS.COMMENTS is 'An optional comment about this window group'
/

comment on column CDB_SCHEDULER_WINDOW_GROUPS.CON_ID is 'container id'
/

