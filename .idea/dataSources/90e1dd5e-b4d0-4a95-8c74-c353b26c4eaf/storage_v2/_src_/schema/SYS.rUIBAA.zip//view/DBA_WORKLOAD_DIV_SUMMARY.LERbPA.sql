create view DBA_WORKLOAD_DIV_SUMMARY
            (REPLAY_ID, DIVERGENCE_TYPE, IS_QUERY_DATA_DIVERGENCE, IS_DML_DATA_DIVERGENCE, IS_ERROR_DIVERGENCE,
             IS_THREAD_FAILURE, IS_DATA_MASKED, IS_CLIENT_FAILURE, STREAM_ID, SQL_ID, EXPECTED_ERROR#,
             EXPECTED_ERROR_MESSAGE, OBSERVED_ERROR#, OBSERVED_ERROR_MESSAGE, SERVICE, MODULE, INSTANCE_NUMBER, WRC_ID,
             OCCURRENCES)
as
select
 replay_id
 , type
 , decode(bitand(type, 1), 0, 'N','Y') as IS_QUERY_DATA_DIVERGENCE
 , decode(bitand(type, 2), 0, 'N','Y') as IS_DML_DATA_DIVERGENCE
 , decode(bitand(type, 4), 0, 'N','Y') as IS_ERROR_DIVERGENCE
 , decode(bitand(type,16), 0, 'N','Y') as IS_THREAD_FAILURE
 , decode(bitand(type,64), 0, 'N','Y') as IS_DATA_MASKED
 , decode(bitand(type,128),0, 'N','Y') as IS_CLIENT_FAILURE
 , file_id
 , sql_id
 , exp_error
 , decode(exp_error, 0, NULL, dbms_advisor.format_message(exp_error))
 , obs_error
 , decode(obs_error, 0, NULL, dbms_advisor.format_message(obs_error))
 , service
 , module
 , instance_number
 , wrc_id
 , sum(occurrences)
 from  WRR$_REPLAY_DIV_SUMMARY
 group by replay_id, type, file_id, sql_id, exp_error, obs_error, service,
          module, instance_number, wrc_id
/

