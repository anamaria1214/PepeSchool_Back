create view CDB_FILE_GROUPS
            (FILE_GROUP_OWNER, FILE_GROUP_NAME, KEEP_FILES, MIN_VERSIONS, MAX_VERSIONS, RETENTION_DAYS, CREATED,
             COMMENTS, DEFAULT_DIRECTORY, CON_ID)
as
SELECT k."FILE_GROUP_OWNER",k."FILE_GROUP_NAME",k."KEEP_FILES",k."MIN_VERSIONS",k."MAX_VERSIONS",k."RETENTION_DAYS",k."CREATED",k."COMMENTS",k."DEFAULT_DIRECTORY",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_FILE_GROUPS") k
/

comment on table CDB_FILE_GROUPS is 'Details about file groups in all containers'
/

comment on column CDB_FILE_GROUPS.FILE_GROUP_OWNER is 'Owner of the file group'
/

comment on column CDB_FILE_GROUPS.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column CDB_FILE_GROUPS.KEEP_FILES is 'Should on-disk files be purged when removed?'
/

comment on column CDB_FILE_GROUPS.MIN_VERSIONS is 'Minimum number of versions to keep'
/

comment on column CDB_FILE_GROUPS.MAX_VERSIONS is 'Maximum number of versions to keep'
/

comment on column CDB_FILE_GROUPS.RETENTION_DAYS is 'Keep versions at least this number of days'
/

comment on column CDB_FILE_GROUPS.CREATED is 'When the file group was created'
/

comment on column CDB_FILE_GROUPS.COMMENTS is 'User specified comment'
/

comment on column CDB_FILE_GROUPS.DEFAULT_DIRECTORY is 'Default directory object'
/

comment on column CDB_FILE_GROUPS.CON_ID is 'container id'
/

