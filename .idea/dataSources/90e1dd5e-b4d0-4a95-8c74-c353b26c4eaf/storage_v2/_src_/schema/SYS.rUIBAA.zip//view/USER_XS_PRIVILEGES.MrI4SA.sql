create view USER_XS_PRIVILEGES (NAME, SECURITY_CLASS, DESCRIPTION) as
select name, security_class, description from sys.dba_xs_privileges
 where security_class_owner = sys_context('USERENV','CURRENT_USER')
/

comment on table USER_XS_PRIVILEGES is 'All the Real Application Security privileges scoped by the security classes owned by the current user'
/

comment on column USER_XS_PRIVILEGES.NAME is 'Name of the privilege'
/

comment on column USER_XS_PRIVILEGES.SECURITY_CLASS is 'Name of the security class that scopes the privilege'
/

comment on column USER_XS_PRIVILEGES.DESCRIPTION is 'Description of the privilege'
/

