create view DBA_RSRC_CAPABILITY (CPU_CAPABLE, IO_CAPABLE, STATUS) as
select cpu_capable, io_capable, decode(status,'PENDING',status, NULL)
  from sys.resource_capability$
  order by status
/

comment on table DBA_RSRC_CAPABILITY is 'settings for database resources that are capable of being managed by the
Resource Manager'
/

comment on column DBA_RSRC_CAPABILITY.CPU_CAPABLE is 'TRUE if the CPU can be managed, FALSE otherwise'
/

comment on column DBA_RSRC_CAPABILITY.IO_CAPABLE is 'type of I/O resource management that can be enabled'
/

comment on column DBA_RSRC_CAPABILITY.STATUS is 'PENDING if it is part of the pending area, NULL otherwise'
/

