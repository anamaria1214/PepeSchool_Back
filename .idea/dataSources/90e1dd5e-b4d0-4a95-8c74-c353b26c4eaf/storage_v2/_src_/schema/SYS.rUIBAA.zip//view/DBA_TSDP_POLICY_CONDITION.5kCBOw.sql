create view DBA_TSDP_POLICY_CONDITION (POLICY_NAME, SUB_POLICY, PROPERTY, VALUE) as
select
 p.name,
 s.subpolnum,
 decode(c.property, 1, 'DATATYPE', 2, 'LENGTH', 3,
        'SCHEMA_NAME', 4, 'TABLE_NAME'),
 c.value
from tsdp_policy$ p, tsdp_condition$ c, tsdp_subpol$ s
where c.subpol# = s.subpol# and s.policy# = p.policy#
/

comment on table DBA_TSDP_POLICY_CONDITION is 'The conditions of TSDP policies'
/

comment on column DBA_TSDP_POLICY_CONDITION.POLICY_NAME is 'The TSDP policy'
/

comment on column DBA_TSDP_POLICY_CONDITION.SUB_POLICY is 'The sub policy of the TSDP policy'
/

comment on column DBA_TSDP_POLICY_CONDITION.PROPERTY is 'The condition property'
/

comment on column DBA_TSDP_POLICY_CONDITION.VALUE is 'The value of the condition property'
/

