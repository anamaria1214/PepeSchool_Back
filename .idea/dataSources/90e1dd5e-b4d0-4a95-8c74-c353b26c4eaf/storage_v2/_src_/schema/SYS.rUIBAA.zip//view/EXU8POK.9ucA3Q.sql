create view EXU8POK (OBJID, OWNERID, POSNO, NAME, PROPERTY, FUNCTION, FUNCLEN) as
SELECT  o$.obj#, o$.owner#, p$.pos#,
                DECODE(BITAND(c$.property, 1), 1, a$.name, c$.name),
                c$.property, c$.default$, c$.deflength
        FROM    sys.obj$ o$, sys.partcol$ p$, sys.col$ c$, sys.attrcol$ a$
        WHERE   o$.obj# = c$.obj# AND
                o$.obj# = p$.obj# AND
                p$.intcol# = c$.intcol# AND
                p$.obj# = a$.obj# (+) AND
                p$.intcol# = a$.intcol# (+)
/

