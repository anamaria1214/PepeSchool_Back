create view DBA_FREE_SPACE_COALESCED_TMP6 (TS#, EXTENTS_COALESCED, BLOCKS_COALESCED) as
select ts#, sum(extents_coalesced), sum(blocks_coalesced)
    from DBA_FREE_SPACE_COALESCED_TMP1
  group by ts#
/

comment on column DBA_FREE_SPACE_COALESCED_TMP6.TS# is 'Number of Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP6.EXTENTS_COALESCED is 'Number of Coalesced Free Extents in Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP6.BLOCKS_COALESCED is 'Total Coalesced Free Oracle Blocks in Tablespace'
/

