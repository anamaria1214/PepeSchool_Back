create view DBA_HIST_OSSTAT_NAME (DBID, STAT_ID, STAT_NAME, CON_DBID, CON_ID) as
select "DBID","STAT_ID","STAT_NAME","CON_DBID","CON_ID" from AWR_CDB_OSSTAT_NAME
/

comment on table DBA_HIST_OSSTAT_NAME is 'Operating System Statistic Names'
/

