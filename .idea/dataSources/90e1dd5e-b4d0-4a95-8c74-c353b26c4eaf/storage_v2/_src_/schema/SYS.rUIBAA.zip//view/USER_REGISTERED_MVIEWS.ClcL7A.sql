create view USER_REGISTERED_MVIEWS
            (OWNER, NAME, MVIEW_SITE, CAN_USE_LOG, UPDATABLE, REFRESH_METHOD, MVIEW_ID, VERSION, QUERY_TXT) as
select "OWNER","NAME","MVIEW_SITE","CAN_USE_LOG","UPDATABLE","REFRESH_METHOD","MVIEW_ID","VERSION","QUERY_TXT" from dba_registered_mviews s
where exists (select u.mview_id from user_base_table_mviews u
                  where s.mview_id = u.mview_id)
/

comment on table USER_REGISTERED_MVIEWS is 'Remote materialized views of local tables currently using logs owned by the user'
/

comment on column USER_REGISTERED_MVIEWS.OWNER is 'Owner of the materialized view'
/

comment on column USER_REGISTERED_MVIEWS.NAME is 'The name of the materialized view'
/

comment on column USER_REGISTERED_MVIEWS.MVIEW_SITE is 'Global name of the materialized view site'
/

comment on column USER_REGISTERED_MVIEWS.CAN_USE_LOG is 'If NO, this materialized view is complex and cannot fast refresh'
/

comment on column USER_REGISTERED_MVIEWS.UPDATABLE is 'If NO, the materialized view is read only'
/

comment on column USER_REGISTERED_MVIEWS.REFRESH_METHOD is 'Whether the materialized view uses rowid or primary key or object id for fast refresh'
/

comment on column USER_REGISTERED_MVIEWS.MVIEW_ID is 'Identifier for the materialized view used by the master for fast refresh'
/

comment on column USER_REGISTERED_MVIEWS.VERSION is 'Version of materialized view'
/

comment on column USER_REGISTERED_MVIEWS.QUERY_TXT is 'Query defining the materialized view'
/

