create view DBA_PDB_SNAPSHOTS
            (CON_ID, CON_UID, CON_NAME, SNAPSHOT_NAME, SNAPSHOT_SCN, PREVIOUS_SNAPSHOT_SCN, SNAPSHOT_TIME,
             PREVIOUS_SNAPSHOT_TIME, FULL_SNAPSHOT_PATH)
as
select ps.con_id#, ps.con_uid, o.name, ps.snapname, ps.snapscn, ps.prevsnapscn,
       ps.snaptime, ps.prevsnaptime, ps.archivepath
 from sys.pdb_snapshot$ ps, sys.container$ c, sys.obj$ o
 where ps.con_id#=c.con_id# and c.obj#=o.obj# and bitand(ps.flags,8)=0
/

comment on table DBA_PDB_SNAPSHOTS is 'Describes all snapshots for a given pluggable database'
/

comment on column DBA_PDB_SNAPSHOTS.CON_ID is 'Id of the pluggable database'
/

comment on column DBA_PDB_SNAPSHOTS.CON_UID is 'Uid of the pluggable database'
/

comment on column DBA_PDB_SNAPSHOTS.CON_NAME is 'Name of the pluggable database'
/

comment on column DBA_PDB_SNAPSHOTS.SNAPSHOT_NAME is 'Snapshot name of the pluggable database'
/

comment on column DBA_PDB_SNAPSHOTS.SNAPSHOT_SCN is 'SCN at which the snapshot was taken'
/

comment on column DBA_PDB_SNAPSHOTS.PREVIOUS_SNAPSHOT_SCN is 'SCN of the previous snapshot for the pdb was taken'
/

comment on column DBA_PDB_SNAPSHOTS.SNAPSHOT_TIME is 'Timestamp at which the snapshot was taken'
/

comment on column DBA_PDB_SNAPSHOTS.PREVIOUS_SNAPSHOT_TIME is 'Timestamp of the previous snapshot for this pdb'
/

comment on column DBA_PDB_SNAPSHOTS.FULL_SNAPSHOT_PATH is 'full path for the snapshot'
/

