create view ALL_STREAMS_SCHEMA_RULES
            (STREAMS_NAME, STREAMS_TYPE, SCHEMA_NAME, RULE_TYPE, INCLUDE_TAGGED_LCR, SOURCE_DATABASE, RULE_NAME,
             RULE_OWNER, RULE_CONDITION)
as
select sr.streams_name, sr.streams_type, sr.schema_name, sr.rule_type,
       sr.include_tagged_lcr, sr.source_database, sr.rule_name, sr.rule_owner,
       sr.rule_condition
  from dba_streams_schema_rules sr, "_ALL_STREAMS_PROCESSES" p, all_rules r
 where sr.rule_owner = r.rule_owner
   and sr.rule_name = r.rule_name
   and sr.streams_name = p.streams_name
   and sr.streams_type = p.streams_type
/

comment on table ALL_STREAMS_SCHEMA_RULES is 'Rules created by streams administrative APIs on all user schemas'
/

comment on column ALL_STREAMS_SCHEMA_RULES.STREAMS_NAME is 'Name of the streams process: capture/propagation/apply process'
/

comment on column ALL_STREAMS_SCHEMA_RULES.STREAMS_TYPE is 'Type of the streams process: CAPTURE, PROPAGATION or APPLY'
/

comment on column ALL_STREAMS_SCHEMA_RULES.SCHEMA_NAME is 'Name of the schema selected by this rule'
/

comment on column ALL_STREAMS_SCHEMA_RULES.RULE_TYPE is 'Type of rule: DML or DDL'
/

comment on column ALL_STREAMS_SCHEMA_RULES.INCLUDE_TAGGED_LCR is 'Whether or not to include tagged LCR'
/

comment on column ALL_STREAMS_SCHEMA_RULES.SOURCE_DATABASE is 'Name of the database where the LCRs originated'
/

comment on column ALL_STREAMS_SCHEMA_RULES.RULE_NAME is 'Name of the rule to be applied'
/

comment on column ALL_STREAMS_SCHEMA_RULES.RULE_OWNER is 'Owner of the rule'
/

comment on column ALL_STREAMS_SCHEMA_RULES.RULE_CONDITION is 'Generated rule condition evaluated by the rules engine'
/

