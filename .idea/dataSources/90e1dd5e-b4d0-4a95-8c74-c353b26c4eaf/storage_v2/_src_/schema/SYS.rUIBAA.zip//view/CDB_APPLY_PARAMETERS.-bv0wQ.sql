create view CDB_APPLY_PARAMETERS (APPLY_NAME, PARAMETER, VALUE, SET_BY_USER, CON_ID) as
SELECT k."APPLY_NAME",k."PARAMETER",k."VALUE",k."SET_BY_USER",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_APPLY_PARAMETERS") k
/

comment on table CDB_APPLY_PARAMETERS is 'All parameters for apply process in all containers'
/

comment on column CDB_APPLY_PARAMETERS.APPLY_NAME is 'Name of the apply process'
/

comment on column CDB_APPLY_PARAMETERS.PARAMETER is 'Name of the parameter'
/

comment on column CDB_APPLY_PARAMETERS.VALUE is 'Either the default value or the value set by the user for the parameter'
/

comment on column CDB_APPLY_PARAMETERS.SET_BY_USER is 'YES if the value is set by the user, NO otherwise'
/

comment on column CDB_APPLY_PARAMETERS.CON_ID is 'container id'
/

