create view V_$DLM_MISC (STATISTIC#, NAME, VALUE, CON_ID) as
select "STATISTIC#","NAME","VALUE","CON_ID" from v$dlm_misc
/

