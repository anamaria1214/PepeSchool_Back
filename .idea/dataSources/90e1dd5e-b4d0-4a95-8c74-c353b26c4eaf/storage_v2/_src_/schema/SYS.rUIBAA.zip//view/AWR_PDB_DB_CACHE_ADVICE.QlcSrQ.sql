create view AWR_PDB_DB_CACHE_ADVICE
            (SNAP_ID, DBID, INSTANCE_NUMBER, BPID, BUFFERS_FOR_ESTIMATE, NAME, BLOCK_SIZE, ADVICE_STATUS,
             SIZE_FOR_ESTIMATE, SIZE_FACTOR, PHYSICAL_READS, BASE_PHYSICAL_READS, ACTUAL_PHYSICAL_READS,
             ESTD_PHYSICAL_READ_TIME, CON_DBID, CON_ID)
as
select db.snap_id, db.dbid, db.instance_number,
       bpid, buffers_for_estimate,
       name, block_size, advice_status, size_for_estimate,
       size_factor, physical_reads, base_physical_reads,
       actual_physical_reads, estd_physical_read_time,
       decode(db.con_dbid, 0, db.dbid, db.con_dbid),
       decode(db.per_pdb, 0, 0,
         con_dbid_to_id(decode(db.con_dbid, 0, db.dbid, db.con_dbid))) con_id
from AWR_PDB_SNAPSHOT sn, WRH$_DB_CACHE_ADVICE db
where      db.snap_id          = sn.snap_id
      and  db.dbid             = sn.dbid
      and  db.instance_number  = sn.instance_number
/

comment on table AWR_PDB_DB_CACHE_ADVICE is 'DB Cache Advice History Information'
/

