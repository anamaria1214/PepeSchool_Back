create view USER_BLOCKCHAIN_TABLE_EPOCHS
            (SCHEMA_NAME, TABLE_NAME, EPOCH_NUMBER, EPOCH_NAME, PDB_GUID, HASH_ALGORITHM, HASH_DATA_FORMAT_VERSION) as
select u.name,
       o.name,
       l.epoch#,
       decode(l.reason#, 1, 'CREATE',
                         2, 'IMPORT', 'INVALID'),
       l.pdb_guid,
       decode(l.hash_algorithm#, 1, 'SHA2_512', 'NONE'),
       l.hash_data_format_version#
from sys.obj$ o, sys.user$ u, sys.blockchain_table_epoch$ l,
     sys.blockchain_table$ b, sys.tab$ t
where  l.obj#   = o.obj# and
       o.owner# = u.user# and
       o.obj#   = b.obj# and
       o.obj#   = t.obj# and
       o.owner# = userenv('SCHEMAID')
/

