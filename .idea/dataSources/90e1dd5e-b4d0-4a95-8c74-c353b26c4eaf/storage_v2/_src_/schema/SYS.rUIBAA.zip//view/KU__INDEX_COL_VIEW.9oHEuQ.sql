create view KU$_INDEX_COL_VIEW
            (OBJ_NUM, BO_NUM, INTCOL_NUM, COL, POS_NUM, SEGCOL_NUM, SEGCOLLEN, OFFSET, FLAGS, SPARE2, SPARE3, SPARE4,
             SPARE5, SPARE6, OID_OR_SETID, ORG_COL_NAME)
as
select ic.obj#, ic.bo#, ic.intcol#,
          value(c), ic.pos#,
          ic.segcol#, ic.segcollength, ic.offset, ic.spare1,
          ic.spare2, ic.spare3, ic.spare4, ic.spare5, to_char(ic.spare6,'YYYY/MM/DD HH24:MI:SS'),
          decode(bitand(c.property,1024+2),0,0,2,1,1024,2,0),
          case when bitand(i.property, 16) = 16 then
            (select c1.name from col$ c1
                           /* Get collation intcol# if the column is
                              (virtual + system generated + hidden) and
                              has collation column expression */
                           where c1.intcol# = (select c2.collintcol# from col$ c2
                                                      where c2.obj#=ic.bo# and c2.intcol#=ic.intcol# and
                                                            bitand(c2.property,65536+256+32) = (65536+256+32) and
                                                            bitand(trunc(c2.property / power(2,32)),16384) = 16384)
                                 and c1.obj#=ic.bo#)
          else
            null
          end
  from ku$_simple_col_view c, ind$ i, icol$ ic
  where ic.bo#     = c.obj_num
  and   i.obj# = ic.obj#
  and c.intcol_num =
   case
      /* join index : 0x0400 */
    when (bitand(i.property, 1024) = 1024) then ic.spare2
     /* not a join index */
     /* Is this a functional index ? */
    when bitand(i.property, 16) = 16 then
      dbms_metadata.get_index_intcol(ic.bo#, ic.intcol#)
    else
      ic.intcol#
   end
/

