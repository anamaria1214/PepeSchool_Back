create view HS_CLASS_CAPS
            (CAP_NUMBER, CAP_DESCRIPTION, CONTEXT, TRANSLATION, ADDITIONAL_INFO, FDS_CLASS_NAME, FDS_CLASS_ID) as
select cc.cap_number, bc.cap_description, cc.context, cc.translation,
       cc.additional_info, fc.fds_class_name, fc.fds_class_id
from   hs$_class_caps cc,
       hs$_base_caps bc,
       hs$_fds_class fc
where  bc.cap_number = cc.cap_number
and cc.fds_class_id = fc.fds_class_id
/

