create view DBA_SECUREFILE_LOG_TABLES
            (GUID, USER_NAME, LOG_NAME, LOG_ID, TABLE_SEQUENCE, TABLE_VERSION, TABLE_NAME, SPLIT, FIXED_SIZE, FLUSH,
             MEM_READ, SFILE_CACHE, SFILE_LOG, SFILE_DEDUPLICATE, SFILE_COMPRESS, HIGH_TSNAME, TABLE_CRT_SCN,
             TABLE_CRT_TIME, MIN_RECORD_SCN, MIN_RECORD_TIME, HIGH_PART_NO, NUM_PARTS)
as
select i.guid, u.name, l.name, i.log#, i.tab#, i.ver#, i.name,
    decode(bitand(i.flags, 8), 8, 'NO-SPLIT', 'SPLIT'),
         decode(bitand(i.flags, 16), 16, 'FIXED_MSG', 'VARIABLE_MSG'),
         decode(bitand(i.flags, 64), 64, 'BACKGROUND_FLUSH',
                'FOREGROUND_FLUSH'),
         decode(bitand(i.flags, 256), 256, 'ALLOW_MEM_READS', 'NO_MEM_READS'),
         decode(bitand(i.lob_flags, 2), 2, 'SFILE_CACHE', 'SFILE_NOCACHE'),
         decode(bitand(i.lob_flags, 12),
                    4, 'SFILE_NOLOGGED',
                    8, 'SFILE_FS_LOGGED',
                    'SFILE_LOGGED'),
         decode(bitand(i.lob_flags, 16), 16, 'DEDUPLICATE',
                'NO_DEDUPLICATE'),
         decode(bitand(i.lob_flags, 224),
                  32, 'SFILE_COMPRESS_HIGH',
                  64, 'SFILE_COMPRESS_LOW',
                  128, 'SFILE_COMPRESS_MEDIUM',
                  'SFILE_NOCOMPRESS'),
         t.name, i.crt_scn, i.crt_time, i.min_scn, i.min_time,
         i.high_part#, i.num_parts
    from cli_tab$ i, cli_log$ l, ts$ t, user$ u
    where i.log# = l.log# and  i.cur_ts# = t.ts# and i.user# = u.user#
/

