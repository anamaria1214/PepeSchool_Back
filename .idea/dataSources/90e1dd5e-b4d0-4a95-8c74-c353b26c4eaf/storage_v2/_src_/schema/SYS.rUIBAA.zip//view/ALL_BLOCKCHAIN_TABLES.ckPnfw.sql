create view ALL_BLOCKCHAIN_TABLES
            (SCHEMA_NAME, TABLE_NAME, ROW_RETENTION, ROW_RETENTION_LOCKED, TABLE_INACTIVITY_RETENTION,
             HASH_ALGORITHM) as
select u.name,
       o.name,
       NVL(b.row_retention, 365000),
       decode(bitand(t.spare7, power(2,10)), power(2,10), 'YES', 'NO'),
       NVL(b.table_inactivity_retention, 365000),
       decode(l.hash_algorithm#, 1, 'SHA2_512', 'NONE')
from sys.obj$ o, sys.user$ u, sys.blockchain_table_epoch$ l,
     sys.blockchain_table$ b, sys.tab$ t
where  l.obj# = o.obj# and
       b.obj# = o.obj# and
       t.obj# = o.obj# and
       o.owner# = u.user# and
       b.current_epoch = l.epoch# and
       bitand(t.spare7,power(2,7)) = power(2,7) and
       ( u.user# in (userenv('SCHEMAID'), 1)
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
       or /* user has system privileges */
         ora_check_sys_privilege(o.owner#, o.type#) = 1
      )
 order by o.obj#
/

