create view CDB_JAVA_IMPLEMENTS (OWNER, NAME, INTERFACE_INDEX, INTERFACE_NAME, CON_ID) as
SELECT k."OWNER",k."NAME",k."INTERFACE_INDEX",k."INTERFACE_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_JAVA_IMPLEMENTS") k
/

comment on table CDB_JAVA_IMPLEMENTS is 'interfaces implemented by all java classes in all containers'
/

comment on column CDB_JAVA_IMPLEMENTS.OWNER is 'owner of the class'
/

comment on column CDB_JAVA_IMPLEMENTS.NAME is 'name of the class'
/

comment on column CDB_JAVA_IMPLEMENTS.INTERFACE_INDEX is 'index of the interfaces implemented by the class'
/

comment on column CDB_JAVA_IMPLEMENTS.INTERFACE_NAME is 'name of the interface identified by the column INTERFACE_INDEX'
/

comment on column CDB_JAVA_IMPLEMENTS.CON_ID is 'container id'
/

