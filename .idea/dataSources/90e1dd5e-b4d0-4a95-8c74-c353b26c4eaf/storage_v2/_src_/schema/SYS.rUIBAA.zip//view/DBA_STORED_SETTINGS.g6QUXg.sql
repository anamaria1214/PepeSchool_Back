create view DBA_STORED_SETTINGS (OWNER, OBJECT_NAME, OBJECT_ID, OBJECT_TYPE, PARAM_NAME, PARAM_VALUE, ORIGIN_CON_ID) as
SELECT owner, object_name, object_id, object_type, param_name, param_value,
       origin_con_id
FROM int$dba_stored_settings
/

comment on table DBA_STORED_SETTINGS is 'Parameter settings for all objects'
/

comment on column DBA_STORED_SETTINGS.OWNER is 'Username of the owner of the object'
/

comment on column DBA_STORED_SETTINGS.OBJECT_NAME is 'Name of the object'
/

comment on column DBA_STORED_SETTINGS.OBJECT_ID is 'Object number of the object'
/

comment on column DBA_STORED_SETTINGS.OBJECT_TYPE is 'Type of the object'
/

comment on column DBA_STORED_SETTINGS.PARAM_NAME is 'Name of the parameter'
/

comment on column DBA_STORED_SETTINGS.PARAM_VALUE is 'Value of the parameter'
/

comment on column DBA_STORED_SETTINGS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

