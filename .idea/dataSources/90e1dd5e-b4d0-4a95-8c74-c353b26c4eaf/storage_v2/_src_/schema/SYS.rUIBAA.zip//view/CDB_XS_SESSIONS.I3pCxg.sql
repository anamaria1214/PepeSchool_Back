create view CDB_XS_SESSIONS
            (USER_NAME, SESSIONID, PROXY_USER, COOKIE, CREATE_TIME, AUTH_TIME, ACCESS_TIME, INACTIVE_TIMEOUT, CON_ID) as
SELECT k."USER_NAME",k."SESSIONID",k."PROXY_USER",k."COOKIE",k."CREATE_TIME",k."AUTH_TIME",k."ACCESS_TIME",k."INACTIVE_TIMEOUT",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XS_SESSIONS") k
/

comment on table CDB_XS_SESSIONS is 'All the application sessions in the database in all containers'
/

comment on column CDB_XS_SESSIONS.USER_NAME is 'User name of the application session'
/

comment on column CDB_XS_SESSIONS.SESSIONID is 'Application session ID'
/

comment on column CDB_XS_SESSIONS.PROXY_USER is 'Name of the proxy user'
/

comment on column CDB_XS_SESSIONS.COOKIE is 'Cookie associated with the application session'
/

comment on column CDB_XS_SESSIONS.CREATE_TIME is 'Creation time of the application session'
/

comment on column CDB_XS_SESSIONS.AUTH_TIME is 'The most recent authentication time of the application session'
/

comment on column CDB_XS_SESSIONS.ACCESS_TIME is 'The most recent access time of the application session'
/

comment on column CDB_XS_SESSIONS.INACTIVE_TIMEOUT is 'Application session inactivity timeout'
/

comment on column CDB_XS_SESSIONS.CON_ID is 'container id'
/

