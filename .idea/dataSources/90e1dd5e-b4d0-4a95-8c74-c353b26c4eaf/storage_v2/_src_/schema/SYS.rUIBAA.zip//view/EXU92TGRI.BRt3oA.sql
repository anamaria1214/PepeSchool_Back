create view EXU92TGRI
            (OWNERID, OWNER, BASEOBJECT, DEFINITION, WHENCLAUSE, ACTION, ENABLED, TPROPERTY, NAME, BASENAME, BASETYPE,
             PROPERTY, BTOWNER, BTOWNERID, ACTIONSIZE, TRIG_OBJNO)
as
SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","TPROPERTY","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE","TRIG_OBJNO"
        FROM    sys.exu92itgr
        WHERE   (ownerid, basename) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu9tabi)
      UNION ALL
        SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","TPROPERTY","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE","TRIG_OBJNO"
        FROM    sys.exu92itgr
        WHERE   (ownerid, basename) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu8vinfi)
/

