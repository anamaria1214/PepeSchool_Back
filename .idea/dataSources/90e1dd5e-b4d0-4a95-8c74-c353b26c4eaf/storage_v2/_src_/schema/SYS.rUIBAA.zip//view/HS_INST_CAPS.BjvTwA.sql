create view HS_INST_CAPS
            (CAP_NUMBER, CAP_DESCRIPTION, CONTEXT, TRANSLATION, ADDITIONAL_INFO, FDS_CLASS_NAME, FDS_INST_NAME,
             FDS_CLASS_ID, FDS_INST_ID)
as
select bc.cap_number, bc.cap_description, ic.context, ic.translation,
       ic.additional_info, fc.fds_class_name, f.fds_inst_name,
       fc.fds_class_id, f.fds_inst_id
from   hs$_inst_caps ic,
       hs$_base_caps bc,
       hs$_fds_class fc,
       hs$_fds_inst f
where  bc.cap_number = ic.cap_number
and    ic.fds_inst_id = f.fds_inst_id
and    f.fds_class_id = fc.fds_class_id
/

