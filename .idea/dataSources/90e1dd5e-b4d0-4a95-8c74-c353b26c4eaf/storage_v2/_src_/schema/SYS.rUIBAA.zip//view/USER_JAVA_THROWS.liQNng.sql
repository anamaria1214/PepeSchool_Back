create view USER_JAVA_THROWS (NAME, METHOD_INDEX, METHOD_NAME, EXCEPTION_INDEX, EXCEPTION_CLASS) as
select /*+ no_cartesian(mmd) no_cartesian(mex) ordered use_nl(o mmd) */
       mmd.kln, mmd.mix, mmd.mnm, mex.xix, mex.xln
from sys.x$joxmex mex, sys.x$joxmmd mmd
where mmd.own = userenv('SCHEMAID')
  and mmd.mix != -1
  and mmd.mix = mex.mix
  and mmd.obn = mex.obn
/

comment on table USER_JAVA_THROWS is 'list of exceptions thrown from methods of classes owned by the current user'
/

comment on column USER_JAVA_THROWS.NAME is 'name of the class'
/

comment on column USER_JAVA_THROWS.METHOD_INDEX is 'the index of the method throwing the exception'
/

comment on column USER_JAVA_THROWS.METHOD_NAME is 'the name of the method throwing the exception'
/

comment on column USER_JAVA_THROWS.EXCEPTION_INDEX is 'the index of the exception'
/

comment on column USER_JAVA_THROWS.EXCEPTION_CLASS is 'the class of the exception'
/

