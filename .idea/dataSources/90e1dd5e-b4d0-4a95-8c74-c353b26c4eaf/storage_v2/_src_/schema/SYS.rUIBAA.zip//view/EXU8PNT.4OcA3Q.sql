create view EXU8PNT (POBJNO, PNAME, POWNERID, COBJNO) as
SELECT  nt$.obj#, o$.name, o$.owner#, nt$.ntab#
        FROM    sys.obj$ o$, sys.ntab$ nt$
        WHERE   nt$.obj# = o$.obj#
/

