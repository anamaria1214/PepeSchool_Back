create view AWR_CDB_TEMPSTATXS
            (SNAP_ID, DBID, INSTANCE_NUMBER, FILE#, CREATION_CHANGE#, FILENAME, TS#, TSNAME, BLOCK_SIZE, PHYRDS,
             PHYWRTS, SINGLEBLKRDS, READTIM, WRITETIM, SINGLEBLKRDTIM, PHYBLKRD, PHYBLKWRT, WAIT_COUNT, TIME, CON_DBID,
             CON_ID)
as
select t.snap_id, t.dbid, t.instance_number,
       t.file#, t.creation_change#, d.filename,
       d.ts#, coalesce(z.tsname, d.tsname) tsname, d.block_size,
       phyrds, phywrts, singleblkrds, readtim, writetim,
       singleblkrdtim, phyblkrd, phyblkwrt, wait_count, time,
       decode(t.con_dbid, 0, t.dbid, t.con_dbid),
       decode(t.per_pdb, 0, 0,
         con_dbid_to_id(decode(t.con_dbid, 0, t.dbid, t.con_dbid))) con_id
from AWR_CDB_SNAPSHOT sn, WRH$_TEMPSTATXS t, WRH$_TEMPFILE d, WRH$_TABLESPACE z
where     t.dbid             = d.dbid
      and t.file#            = d.file#
      and t.creation_change# = d.creation_change#
      and t.con_dbid         = d.con_dbid
      and sn.snap_id         = t.snap_id
      and sn.dbid            = t.dbid
      and sn.instance_number = t.instance_number
      and d.dbid             = z.dbid(+)
      and d.ts#              = z.ts#(+)
      and d.con_dbid         = z.con_dbid(+)
/

comment on table AWR_CDB_TEMPSTATXS is 'Temporary Datafile Historical Statistics Information'
/

