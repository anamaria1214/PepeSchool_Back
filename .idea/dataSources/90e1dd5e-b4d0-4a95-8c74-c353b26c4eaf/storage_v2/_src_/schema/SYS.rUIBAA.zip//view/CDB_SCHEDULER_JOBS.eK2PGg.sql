create view CDB_SCHEDULER_JOBS
            (OWNER, JOB_NAME, JOB_SUBNAME, JOB_STYLE, JOB_CREATOR, CLIENT_ID, GLOBAL_UID, PROGRAM_OWNER, PROGRAM_NAME,
             JOB_TYPE, JOB_ACTION, NUMBER_OF_ARGUMENTS, SCHEDULE_OWNER, SCHEDULE_NAME, SCHEDULE_TYPE, START_DATE,
             REPEAT_INTERVAL, EVENT_QUEUE_OWNER, EVENT_QUEUE_NAME, EVENT_QUEUE_AGENT, EVENT_CONDITION, EVENT_RULE,
             FILE_WATCHER_OWNER, FILE_WATCHER_NAME, END_DATE, JOB_CLASS, ENABLED, AUTO_DROP, RESTART_ON_RECOVERY,
             RESTART_ON_FAILURE, STATE, JOB_PRIORITY, RUN_COUNT, UPTIME_RUN_COUNT, MAX_RUNS, FAILURE_COUNT,
             UPTIME_FAILURE_COUNT, MAX_FAILURES, RETRY_COUNT, LAST_START_DATE, LAST_RUN_DURATION, NEXT_RUN_DATE,
             SCHEDULE_LIMIT, MAX_RUN_DURATION, LOGGING_LEVEL, STORE_OUTPUT, STOP_ON_WINDOW_CLOSE, INSTANCE_STICKINESS,
             RAISE_EVENTS, SYSTEM, JOB_WEIGHT, NLS_ENV, SOURCE, NUMBER_OF_DESTINATIONS, DESTINATION_OWNER, DESTINATION,
             CREDENTIAL_OWNER, CREDENTIAL_NAME, INSTANCE_ID, DEFERRED_DROP, ALLOW_RUNS_IN_RESTRICTED_MODE, COMMENTS,
             FLAGS, RESTARTABLE, HAS_CONSTRAINTS, CONNECT_CREDENTIAL_OWNER, CONNECT_CREDENTIAL_NAME,
             FAIL_ON_SCRIPT_ERROR, CON_ID)
as
SELECT k."OWNER",k."JOB_NAME",k."JOB_SUBNAME",k."JOB_STYLE",k."JOB_CREATOR",k."CLIENT_ID",k."GLOBAL_UID",k."PROGRAM_OWNER",k."PROGRAM_NAME",k."JOB_TYPE",k."JOB_ACTION",k."NUMBER_OF_ARGUMENTS",k."SCHEDULE_OWNER",k."SCHEDULE_NAME",k."SCHEDULE_TYPE",k."START_DATE",k."REPEAT_INTERVAL",k."EVENT_QUEUE_OWNER",k."EVENT_QUEUE_NAME",k."EVENT_QUEUE_AGENT",k."EVENT_CONDITION",k."EVENT_RULE",k."FILE_WATCHER_OWNER",k."FILE_WATCHER_NAME",k."END_DATE",k."JOB_CLASS",k."ENABLED",k."AUTO_DROP",k."RESTART_ON_RECOVERY",k."RESTART_ON_FAILURE",k."STATE",k."JOB_PRIORITY",k."RUN_COUNT",k."UPTIME_RUN_COUNT",k."MAX_RUNS",k."FAILURE_COUNT",k."UPTIME_FAILURE_COUNT",k."MAX_FAILURES",k."RETRY_COUNT",k."LAST_START_DATE",k."LAST_RUN_DURATION",k."NEXT_RUN_DATE",k."SCHEDULE_LIMIT",k."MAX_RUN_DURATION",k."LOGGING_LEVEL",k."STORE_OUTPUT",k."STOP_ON_WINDOW_CLOSE",k."INSTANCE_STICKINESS",k."RAISE_EVENTS",k."SYSTEM",k."JOB_WEIGHT",k."NLS_ENV",k."SOURCE",k."NUMBER_OF_DESTINATIONS",k."DESTINATION_OWNER",k."DESTINATION",k."CREDENTIAL_OWNER",k."CREDENTIAL_NAME",k."INSTANCE_ID",k."DEFERRED_DROP",k."ALLOW_RUNS_IN_RESTRICTED_MODE",k."COMMENTS",k."FLAGS",k."RESTARTABLE",k."HAS_CONSTRAINTS",k."CONNECT_CREDENTIAL_OWNER",k."CONNECT_CREDENTIAL_NAME",k."FAIL_ON_SCRIPT_ERROR",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SCHEDULER_JOBS") k
/

comment on table CDB_SCHEDULER_JOBS is 'All scheduler jobs in the database in all containers'
/

comment on column CDB_SCHEDULER_JOBS.OWNER is 'Owner of the scheduler job'
/

comment on column CDB_SCHEDULER_JOBS.JOB_NAME is 'Name of the scheduler job'
/

comment on column CDB_SCHEDULER_JOBS.JOB_SUBNAME is 'Subname of the scheduler job (for a job running a chain step)'
/

comment on column CDB_SCHEDULER_JOBS.JOB_STYLE is 'Job style - regular, lightweight or volatile'
/

comment on column CDB_SCHEDULER_JOBS.JOB_CREATOR is 'Original creator of this job'
/

comment on column CDB_SCHEDULER_JOBS.CLIENT_ID is 'Client id of user creating job'
/

comment on column CDB_SCHEDULER_JOBS.GLOBAL_UID is 'Global uid of user creating this job'
/

comment on column CDB_SCHEDULER_JOBS.PROGRAM_OWNER is 'Owner of the program associated with the job'
/

comment on column CDB_SCHEDULER_JOBS.PROGRAM_NAME is 'Name of the program associated with the job'
/

comment on column CDB_SCHEDULER_JOBS.JOB_TYPE is 'Inlined job action type'
/

comment on column CDB_SCHEDULER_JOBS.JOB_ACTION is 'Inlined job action'
/

comment on column CDB_SCHEDULER_JOBS.NUMBER_OF_ARGUMENTS is 'Inlined job number of arguments'
/

comment on column CDB_SCHEDULER_JOBS.SCHEDULE_OWNER is 'Owner of the schedule that this job uses (can be a window or window group)'
/

comment on column CDB_SCHEDULER_JOBS.SCHEDULE_NAME is 'Name of the schedule that this job uses (can be a window or window group)'
/

comment on column CDB_SCHEDULER_JOBS.SCHEDULE_TYPE is 'Type of the schedule that this job uses'
/

comment on column CDB_SCHEDULER_JOBS.START_DATE is 'Original scheduled start date of this job (for an inlined schedule)'
/

comment on column CDB_SCHEDULER_JOBS.REPEAT_INTERVAL is 'Inlined schedule PL/SQL expression or calendar string'
/

comment on column CDB_SCHEDULER_JOBS.EVENT_QUEUE_OWNER is 'Owner of source queue into which event will be raised'
/

comment on column CDB_SCHEDULER_JOBS.EVENT_QUEUE_NAME is 'Name of source queue into which event will be raised'
/

comment on column CDB_SCHEDULER_JOBS.EVENT_QUEUE_AGENT is 'Name of AQ agent used by user on the event source queue (if it is a secure queue)'
/

comment on column CDB_SCHEDULER_JOBS.EVENT_CONDITION is 'Boolean expression used as subscription rule for event on the source queue'
/

comment on column CDB_SCHEDULER_JOBS.EVENT_RULE is 'Name of rule used by the coordinator to trigger event based job'
/

comment on column CDB_SCHEDULER_JOBS.FILE_WATCHER_OWNER is 'Owner of file watcher on which this job is based'
/

comment on column CDB_SCHEDULER_JOBS.FILE_WATCHER_NAME is 'Name of file watcher on which this job is based'
/

comment on column CDB_SCHEDULER_JOBS.END_DATE is 'Date after which this job will no longer run (for an inlined schedule)'
/

comment on column CDB_SCHEDULER_JOBS.JOB_CLASS is 'Name of job class associated with the job'
/

comment on column CDB_SCHEDULER_JOBS.ENABLED is 'Whether the job is enabled'
/

comment on column CDB_SCHEDULER_JOBS.AUTO_DROP is 'Whether this job will be dropped when it has completed'
/

comment on column CDB_SCHEDULER_JOBS.RESTART_ON_RECOVERY is 'Whether this job can be restarted after a db crash'
/

comment on column CDB_SCHEDULER_JOBS.RESTART_ON_FAILURE is 'Whether this job can be re-tried if it fails'
/

comment on column CDB_SCHEDULER_JOBS.STATE is 'Current state of the job'
/

comment on column CDB_SCHEDULER_JOBS.JOB_PRIORITY is 'Priority of the job relative to others within the same class'
/

comment on column CDB_SCHEDULER_JOBS.RUN_COUNT is 'Number of times this job has run'
/

comment on column CDB_SCHEDULER_JOBS.MAX_RUNS is 'Maximum number of times this job is scheduled to run'
/

comment on column CDB_SCHEDULER_JOBS.FAILURE_COUNT is 'Number of times this job has failed to run'
/

comment on column CDB_SCHEDULER_JOBS.MAX_FAILURES is 'Number of times this job will be allowed to fail before being marked broken'
/

comment on column CDB_SCHEDULER_JOBS.RETRY_COUNT is 'Number of times this job has retried, if it is retrying.'
/

comment on column CDB_SCHEDULER_JOBS.LAST_START_DATE is 'Last date on which the job started running'
/

comment on column CDB_SCHEDULER_JOBS.LAST_RUN_DURATION is 'How long the job took last time'
/

comment on column CDB_SCHEDULER_JOBS.NEXT_RUN_DATE is 'Next date the job is scheduled to run on'
/

comment on column CDB_SCHEDULER_JOBS.SCHEDULE_LIMIT is 'Time in minutes after which a job which has not run yet will be rescheduled'
/

comment on column CDB_SCHEDULER_JOBS.MAX_RUN_DURATION is 'This column is reserved for future use'
/

comment on column CDB_SCHEDULER_JOBS.LOGGING_LEVEL is 'Amount of logging that will be done pertaining to this job'
/

comment on column CDB_SCHEDULER_JOBS.STORE_OUTPUT is 'Determines if full job output is to be stored'
/

comment on column CDB_SCHEDULER_JOBS.STOP_ON_WINDOW_CLOSE is 'Whether this job will stop if a window it is associated with closes'
/

comment on column CDB_SCHEDULER_JOBS.INSTANCE_STICKINESS is 'Whether this job is sticky'
/

comment on column CDB_SCHEDULER_JOBS.RAISE_EVENTS is 'List of job events to raise for this job'
/

comment on column CDB_SCHEDULER_JOBS.SYSTEM is 'Whether this is a system job'
/

comment on column CDB_SCHEDULER_JOBS.JOB_WEIGHT is 'Weight of this job'
/

comment on column CDB_SCHEDULER_JOBS.NLS_ENV is 'NLS environment of this job'
/

comment on column CDB_SCHEDULER_JOBS.SOURCE is 'Source global database identifier'
/

comment on column CDB_SCHEDULER_JOBS.DESTINATION_OWNER is 'Owner of destination object (if used) else NULL'
/

comment on column CDB_SCHEDULER_JOBS.DESTINATION is 'Destination that this job will run on'
/

comment on column CDB_SCHEDULER_JOBS.CREDENTIAL_OWNER is 'Owner of login credential'
/

comment on column CDB_SCHEDULER_JOBS.CREDENTIAL_NAME is 'Name of login credential'
/

comment on column CDB_SCHEDULER_JOBS.INSTANCE_ID is 'Instance user requests job to run on.'
/

comment on column CDB_SCHEDULER_JOBS.DEFERRED_DROP is 'Whether this job will be dropped when completed due to user request.'
/

comment on column CDB_SCHEDULER_JOBS.COMMENTS is 'Comments on the job'
/

comment on column CDB_SCHEDULER_JOBS.FLAGS is 'This column is for internal use.'
/

comment on column CDB_SCHEDULER_JOBS.RESTARTABLE is 'Whether this job can be restarted or not'
/

comment on column CDB_SCHEDULER_JOBS.HAS_CONSTRAINTS is 'Whether this job (not including program of job) is part of a resource constraint or incompatibility'
/

comment on column CDB_SCHEDULER_JOBS.CONNECT_CREDENTIAL_OWNER is 'Owner of connect credential'
/

comment on column CDB_SCHEDULER_JOBS.CONNECT_CREDENTIAL_NAME is 'Name of connect credential'
/

comment on column CDB_SCHEDULER_JOBS.FAIL_ON_SCRIPT_ERROR is 'Whether this job is set as failed when an script error occurs'
/

comment on column CDB_SCHEDULER_JOBS.CON_ID is 'container id'
/

