create view CDB_JAVA_LAYOUTS
            (OWNER, NAME, INTERFACES, INNER_CLASSES, FIELDS, STATIC_FIELDS, METHODS, STATIC_METHODS, NATIVE_METHODS,
             CON_ID) as
SELECT k."OWNER",k."NAME",k."INTERFACES",k."INNER_CLASSES",k."FIELDS",k."STATIC_FIELDS",k."METHODS",k."STATIC_METHODS",k."NATIVE_METHODS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_JAVA_LAYOUTS") k
/

comment on table CDB_JAVA_LAYOUTS is 'class layout information for all java classes in all containers'
/

comment on column CDB_JAVA_LAYOUTS.OWNER is 'owner of the class'
/

comment on column CDB_JAVA_LAYOUTS.NAME is 'name of the class'
/

comment on column CDB_JAVA_LAYOUTS.INTERFACES is 'how many interfaces does this class implement?'
/

comment on column CDB_JAVA_LAYOUTS.INNER_CLASSES is 'how many inner classes does this class contain?'
/

comment on column CDB_JAVA_LAYOUTS.FIELDS is 'how many locally declared fields does this class contain?'
/

comment on column CDB_JAVA_LAYOUTS.STATIC_FIELDS is 'how many locally declared static fields does this class contain?'
/

comment on column CDB_JAVA_LAYOUTS.METHODS is 'how many locally declared methods does this class contain?'
/

comment on column CDB_JAVA_LAYOUTS.STATIC_METHODS is 'how many locally declared static methods does this class contain?'
/

comment on column CDB_JAVA_LAYOUTS.CON_ID is 'container id'
/

