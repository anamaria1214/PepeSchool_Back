create view CDB_TYPE_ATTRS
            (OWNER, TYPE_NAME, ATTR_NAME, ATTR_TYPE_MOD, ATTR_TYPE_OWNER, ATTR_TYPE_NAME, LENGTH, PRECISION, SCALE,
             CHARACTER_SET_NAME, ATTR_NO, INHERITED, CON_ID)
as
SELECT k."OWNER",k."TYPE_NAME",k."ATTR_NAME",k."ATTR_TYPE_MOD",k."ATTR_TYPE_OWNER",k."ATTR_TYPE_NAME",k."LENGTH",k."PRECISION",k."SCALE",k."CHARACTER_SET_NAME",k."ATTR_NO",k."INHERITED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_TYPE_ATTRS") k
/

comment on table CDB_TYPE_ATTRS is 'Description of attributes of all types in the database in all containers'
/

comment on column CDB_TYPE_ATTRS.OWNER is 'Owner of the type'
/

comment on column CDB_TYPE_ATTRS.TYPE_NAME is 'Name of the type'
/

comment on column CDB_TYPE_ATTRS.ATTR_NAME is 'Name of the attribute'
/

comment on column CDB_TYPE_ATTRS.ATTR_TYPE_MOD is 'Type modifier of the attribute'
/

comment on column CDB_TYPE_ATTRS.ATTR_TYPE_OWNER is 'Owner of the type of the attribute'
/

comment on column CDB_TYPE_ATTRS.ATTR_TYPE_NAME is 'Name of the type of the attribute'
/

comment on column CDB_TYPE_ATTRS.LENGTH is 'Length of the CHAR attribute or maximum length of the VARCHAR
or VARCHAR2 attribute'
/

comment on column CDB_TYPE_ATTRS.PRECISION is 'Decimal precision of the NUMBER or DECIMAL attribute or
binary precision of the FLOAT attribute'
/

comment on column CDB_TYPE_ATTRS.SCALE is 'Scale of the NUMBER or DECIMAL attribute'
/

comment on column CDB_TYPE_ATTRS.CHARACTER_SET_NAME is 'Character set name of the attribute'
/

comment on column CDB_TYPE_ATTRS.ATTR_NO is 'Syntactical order number or position of the attribute as specified in the
type specification or CREATE TYPE statement (not to be used as ID number)'
/

comment on column CDB_TYPE_ATTRS.INHERITED is 'Is the attribute inherited from the supertype ?'
/

comment on column CDB_TYPE_ATTRS.CON_ID is 'container id'
/

