create view CDB_APP_ERRORS_HISTORY
            (APP_NAME, APP_STATEMENT, ERRORNUM, ERRORMSG, SYNC_TIME, SYSTEM_IGNORABLE, USER_IGNORABLE, CON_ID) as
SELECT k."APP_NAME",k."APP_STATEMENT",k."ERRORNUM",k."ERRORMSG",k."SYNC_TIME",k."SYSTEM_IGNORABLE",k."USER_IGNORABLE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_APP_ERRORS_HISTORY") k
/

comment on table CDB_APP_ERRORS_HISTORY is 'Maintains a history of the errors that happened during Application sync in all containers'
/

comment on column CDB_APP_ERRORS_HISTORY.APP_NAME is 'Name of the application whose statement was captured'
/

comment on column CDB_APP_ERRORS_HISTORY.APP_STATEMENT is 'Application statement'
/

comment on column CDB_APP_ERRORS_HISTORY.ERRORNUM is 'Error number for statement'
/

comment on column CDB_APP_ERRORS_HISTORY.ERRORMSG is 'Error message for statement'
/

comment on column CDB_APP_ERRORS_HISTORY.SYNC_TIME is 'Time of sync of statement'
/

comment on column CDB_APP_ERRORS_HISTORY.SYSTEM_IGNORABLE is 'Whether the error is a system ignorable error'
/

comment on column CDB_APP_ERRORS_HISTORY.USER_IGNORABLE is 'Whether the error is a user ignorable error'
/

comment on column CDB_APP_ERRORS_HISTORY.CON_ID is 'container id'
/

