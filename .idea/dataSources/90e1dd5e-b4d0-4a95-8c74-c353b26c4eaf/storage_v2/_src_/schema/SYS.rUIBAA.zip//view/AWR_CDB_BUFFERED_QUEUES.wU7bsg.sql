create view AWR_CDB_BUFFERED_QUEUES
            (SNAP_ID, DBID, INSTANCE_NUMBER, QUEUE_SCHEMA, QUEUE_NAME, STARTUP_TIME, QUEUE_ID, NUM_MSGS, SPILL_MSGS,
             CNUM_MSGS, CSPILL_MSGS, EXPIRED_MSGS, OLDEST_MSGID, OLDEST_MSG_ENQTM, QUEUE_STATE, ELAPSED_ENQUEUE_TIME,
             ELAPSED_DEQUEUE_TIME, ELAPSED_TRANSFORMATION_TIME, ELAPSED_RULE_EVALUATION_TIME, ENQUEUE_CPU_TIME,
             DEQUEUE_CPU_TIME, LAST_ENQUEUE_TIME, LAST_DEQUEUE_TIME, CON_DBID, CON_ID)
as
select qs.snap_id, qs.dbid, qs.instance_number, qs.queue_schema, qs.queue_name,
       qs.startup_time, qs.queue_id, qs.num_msgs, qs.spill_msgs, qs.cnum_msgs,
       qs.cspill_msgs, qs.expired_msgs, qs.oldest_msgid, qs.oldest_msg_enqtm,
       qs.queue_state, qs.elapsed_enqueue_time,
       qs.elapsed_dequeue_time, qs.elapsed_transformation_time,
       qs.elapsed_rule_evaluation_time, qs.enqueue_cpu_time,
       qs.dequeue_cpu_time, qs.last_enqueue_time, qs.last_dequeue_time,
       decode(qs.con_dbid, 0, qs.dbid, qs.con_dbid),
       decode(qs.per_pdb, 0, 0,
         con_dbid_to_id(decode(qs.con_dbid, 0, qs.dbid, qs.con_dbid))) con_id
  from wrh$_buffered_queues qs, AWR_CDB_SNAPSHOT sn
  where     sn.snap_id          = qs.snap_id
        and sn.dbid             = qs.dbid
        and sn.instance_number  = qs.instance_number
/

comment on table AWR_CDB_BUFFERED_QUEUES is 'STREAMS Buffered Queues Historical Statistics Information'
/

