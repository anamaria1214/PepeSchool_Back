create view USER_SCHEDULER_JOB_DESTS
            (JOB_NAME, JOB_SUBNAME, CREDENTIAL_OWNER, CREDENTIAL_NAME, DESTINATION_OWNER, DESTINATION, JOB_DEST_ID,
             ENABLED, REFS_ENABLED, STATE, NEXT_START_DATE, RUN_COUNT, RETRY_COUNT, FAILURE_COUNT, LAST_START_DATE,
             LAST_END_DATE)
as
SELECT  dd.JOB_NAME, dd.JOB_SUBNAME,
        decode(dd.local, 'X', null, CREDENTIAL_OWNER),
        decode(dd.local, 'X', null,dd.CREDENTIAL_NAME),
        decode(dd.local, 'N', dd.DESTINATION_OWNER, null),
        decode(dd.local, 'N', dd.DESTINATION_NAME, 'LOCAL'),
        lj.JOB_DEST_ID,
        decode(dd.pj_enbl, 1, 'TRUE', 'FALSE'),
        dd.ENABLED,
        (CASE WHEN (bitand(dd.pj_status,4+8+16+32+8192+524288) > 0 OR
                    (lj.STATE <> 'RUNNING' AND bitand(dd.pj_status, 1) = 0))
                 THEN  'DISABLED'
                 ELSE  coalesce(lj.STATE, 'SCHEDULED') END),
        dd.next_run_date NEXT_START_DATE,
        coalesce(lj.RUN_COUNT,0),
        coalesce(lj.RETRY_COUNT,0),
        coalesce(lj.FAILURE_COUNT,0),
        lj.LAST_START_DATE, lj.LAST_END_DATE
FROM
(SELECT
  d.job_dest_id JOB_DEST_ID,
  DECODE(BITAND(d.job_status,2+65536),2,'RUNNING',2+65536,'CHAIN_STALLED',
    DECODE(BITAND(d.job_status,1+4+8+16+32+128+8192),0,'SCHEDULED',1,
      (CASE WHEN d.retry_count>0 THEN 'RETRY SCHEDULED'
            WHEN (bitand(d.job_status, 1024) <> 0) THEN 'READY TO RUN'
            ELSE 'SCHEDULED' END),
      4,'COMPLETED',8,'BROKEN',16,'FAILED',
      32,'SUCCEEDED' ,128,'REMOTE',8192, 'STOPPED', NULL)) STATE,
    d.run_count, d.retry_count, d.failure_count,
    d.last_start_date, d.last_end_date, d.program_oid parent_job_id,d.dest_oid
  FROM  scheduler$_comb_lw_job d) lj,
(SELECT
     j0.JOB_NAME,
     'SCHED$_MD_'
     || TO_CHAR(coalesce(d0.dest_oid,j0.dest_oid), 'FMXXXXXXXXX') || '_'
     || TO_CHAR(decode(d0.local, 'X', 0,
                  coalesce(d0.cred_oid,j0.cred_oid)), 'FMXXXXXXXXX') JOB_SUBNAME,
     coalesce(d0.credential_owner,j0.credential_owner) credential_owner,
     coalesce(d0.credential_name,j0.credential_name) credential_name,
     d0.destination_owner,
     d0.destination_name,
     decode(d0.en_flag+j0.en_flag, 2, 'TRUE', 'FALSE') enabled,
     j0.en_flag pj_enbl,
     j0.pj_status,
     j0.next_run_date, j0.parent_job_id, d0.dest_oid, d0.local
FROM
  (SELECT cmu.name credential_owner,  cmo.name credential_name,
     wmu.name destination_owner, wmo.name destination_name,
     bitand(d.flags, bitand(w.flags,bitand(coalesce(ad.flags,1),1))) en_flag,
     w.obj# dest_grp_id,
     wg.member_oid2 cred_oid,
     wg.member_oid dest_oid,
     decode(bitand(d.flags, 12),12, 'X',8, 'Y','N') local
   FROM  scheduler$_window_group w, scheduler$_wingrp_member wg,
      scheduler$_destinations d, scheduler$_destinations ad,
      user$ wmu, obj$ wmo, user$ cmu, obj$ cmo
   WHERE w.obj# = wg.oid
       AND wg.member_oid = wmo.obj#
       AND wmo.owner# = wmu.user#
       AND wg.member_oid = d.obj#
       AND cmo.obj#(+) = wg.member_oid2
       AND d.agtdestoid = ad.obj#(+)
       AND cmo.owner# = cmu.user#(+)) d0,
  (SELECT  j1.credential_owner, j1.credential_name,
    substr(j1.destination, 1, instr(j1.destination, '"')-1) destination_owner,
    substr(j1.destination, instr(j1.destination, '"')+1,
        length(j1.destination) - instr(j1.destination, '"')) destination_name,
    bitand(j1.job_status, 1) en_flag,
    j1.dest_oid,
    j1.next_run_date,
    u.name OWNER, o.name JOB_NAME, o.subname JOB_SUBNAME,
    j1.obj# parent_job_id,
    j1.job_status pj_status,
    j1.credential_oid cred_oid
    FROM scheduler$_job j1, user$ u, obj$ o
      WHERE j1.obj# = o.obj# AND o.owner# = u.user#
                    AND o.owner# = USERENV('SCHEMAID')) j0
   WHERE j0.dest_oid = d0.dest_grp_id
    and (j0.cred_oid is null or j0.cred_oid != coalesce(d0.cred_oid, 0)
        or not exists (select 1 from scheduler$_wingrp_member wm
               where  wm.oid = d0.dest_grp_id
               and wm.member_oid2 is null
               and wm.member_oid = d0.dest_oid))) dd
WHERE
   lj.parent_job_id (+) = dd.parent_job_id and
   lj.dest_oid (+) = dd.dest_oid
   and (dd.pj_enbl = 1 or lj.dest_oid is not null)
UNION ALL
  SELECT o1.name, o1.subname, j1.credential_owner, j1.credential_name,
    j1.destination_owne
/

comment on table USER_SCHEDULER_JOB_DESTS is 'State of all jobs owned by current user at each of their destinations'
/

comment on column USER_SCHEDULER_JOB_DESTS.JOB_NAME is 'Name of scheduler job'
/

comment on column USER_SCHEDULER_JOB_DESTS.JOB_SUBNAME is 'Subname of scheduler job'
/

comment on column USER_SCHEDULER_JOB_DESTS.CREDENTIAL_OWNER is 'Owner of credential used for remote destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.CREDENTIAL_NAME is 'Name of credential used for remote destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.DESTINATION_OWNER is 'Owner of destination object that points to destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.DESTINATION is 'Name of destination object or name of destination itself'
/

comment on column USER_SCHEDULER_JOB_DESTS.JOB_DEST_ID is 'Numerical ID assigned to job at this destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.ENABLED is 'Is this job enabled at this destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.STATE is 'State of this job at this destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.NEXT_START_DATE is 'Next start time of this job at this destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.RUN_COUNT is 'Number of times this job has run at this destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.RETRY_COUNT is 'Number of times this job has been retried at this destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.FAILURE_COUNT is 'Number of times this job has failed at this destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.LAST_START_DATE is 'Last time this job started at this destination'
/

comment on column USER_SCHEDULER_JOB_DESTS.LAST_END_DATE is 'Last time this job ended at this destination'
/

