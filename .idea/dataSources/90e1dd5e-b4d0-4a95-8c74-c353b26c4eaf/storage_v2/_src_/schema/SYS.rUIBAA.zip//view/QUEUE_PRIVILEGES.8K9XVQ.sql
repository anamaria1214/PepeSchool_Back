create view QUEUE_PRIVILEGES (GRANTEE, OWNER, NAME, GRANTOR, ENQUEUE_PRIVILEGE, DEQUEUE_PRIVILEGE) as
select ue.name GRANTEE, u.name OWNER, o.name NAME, ur.name GRANTOR,
decode(sum(privilege#), 20, 1, 41, 1, 0) ENQUEUE_PRIVILEGE,
decode(sum(oa.privilege#), 21, 1, 41, 1, 0) DEQUEUE_PRIVILEGE
from sys.objauth$ oa, sys.obj$ o, sys.user$ ue, sys.user$ ur, sys.user$ u
where oa.obj# = o.obj#
  and o.type# = 24
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and u.user# = o.owner#
  and (oa.grantor# = userenv('SCHEMAID') or
       oa.grantee# in (select kzsrorol from x$kzsro) or
       o.owner# = userenv('SCHEMAID'))
group by u.name, o.name, ur.name, ue.name
/

comment on table QUEUE_PRIVILEGES is 'Grants on queues for which the user is the grantor, grantee, owner,
 or an enabled role or PUBLIC is the grantee'
/

comment on column QUEUE_PRIVILEGES.GRANTEE is 'Name of the user to whom access was granted'
/

comment on column QUEUE_PRIVILEGES.OWNER is 'Owner of the object'
/

comment on column QUEUE_PRIVILEGES.NAME is 'Name of the object'
/

comment on column QUEUE_PRIVILEGES.GRANTOR is 'Name of the user who performed the grant'
/

comment on column QUEUE_PRIVILEGES.ENQUEUE_PRIVILEGE is 'Permission to ENQUEUE to the queue'
/

comment on column QUEUE_PRIVILEGES.DEQUEUE_PRIVILEGE is 'Permission to DEQUEUE from the queue'
/

