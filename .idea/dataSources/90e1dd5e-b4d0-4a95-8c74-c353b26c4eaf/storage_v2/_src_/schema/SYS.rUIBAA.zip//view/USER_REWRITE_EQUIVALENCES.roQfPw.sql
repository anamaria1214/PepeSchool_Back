create view USER_REWRITE_EQUIVALENCES (OWNER, NAME, SOURCE_STMT, DESTINATION_STMT, REWRITE_MODE) as
select m."OWNER",m."NAME",m."SOURCE_STMT",m."DESTINATION_STMT",m."REWRITE_MODE" from dba_rewrite_equivalences m, sys.user$ u
where u.name = m.owner
  and u.user# = userenv('SCHEMAID')
/

comment on table USER_REWRITE_EQUIVALENCES is 'Description of all rewrite equivalence owned by the user'
/

comment on column USER_REWRITE_EQUIVALENCES.OWNER is 'Owner of the rewrite equivalence'
/

comment on column USER_REWRITE_EQUIVALENCES.NAME is 'Name of the rewrite equivalence'
/

comment on column USER_REWRITE_EQUIVALENCES.SOURCE_STMT is 'Source statement of the rewrite equivalence'
/

comment on column USER_REWRITE_EQUIVALENCES.DESTINATION_STMT is 'Destination of the rewrite equivalence'
/

comment on column USER_REWRITE_EQUIVALENCES.REWRITE_MODE is 'Rewrite mode of the rewrite equivalence'
/

