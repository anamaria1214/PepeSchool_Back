create view KU$_HCS_SRC_VIEW (HCS_OBJ#, SRC_ID, OWNER, OWNER_IN_DDL, NAME, ALIAS, IS_REMOTE, ORDER_NUM) as
select s.hcs_obj#,
         s.src#,
         t.owner,
         t.owner_in_ddl,
         t.name,
         s.alias,
         s.is_remote,
         s.order_num
  from sys.hcs_src$ s, sys.ku$_hcs_tbl_view t
  where t.top_obj_num = s.hcs_obj# and
        t.tbl_id = s.tbl#
/

