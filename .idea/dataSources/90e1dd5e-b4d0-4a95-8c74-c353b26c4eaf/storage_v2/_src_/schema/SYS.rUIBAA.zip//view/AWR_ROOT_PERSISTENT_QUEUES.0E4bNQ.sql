create view AWR_ROOT_PERSISTENT_QUEUES
            (SNAP_ID, DBID, INSTANCE_NUMBER, QUEUE_SCHEMA, QUEUE_NAME, QUEUE_ID, FIRST_ACTIVITY_TIME, ENQUEUED_MSGS,
             DEQUEUED_MSGS, BROWSED_MSGS, ELAPSED_ENQUEUE_TIME, ELAPSED_DEQUEUE_TIME, ENQUEUE_CPU_TIME,
             DEQUEUE_CPU_TIME, AVG_MSG_AGE, DEQUEUED_MSG_LATENCY, ELAPSED_TRANSFORMATION_TIME,
             ELAPSED_RULE_EVALUATION_TIME, ENQUEUED_EXPIRY_MSGS, ENQUEUED_DELAY_MSGS, MSGS_MADE_EXPIRED,
             MSGS_MADE_READY, LAST_ENQUEUE_TIME, LAST_DEQUEUE_TIME, LAST_TM_EXPIRY_TIME, LAST_TM_READY_TIME,
             ENQUEUE_TRANSACTIONS, DEQUEUE_TRANSACTIONS, EXECUTION_COUNT, CON_DBID, CON_ID)
as
select pqs.snap_id, pqs.dbid, pqs.instance_number, pqs.queue_schema,
       pqs.queue_name,pqs.queue_id, pqs.first_activity_time, pqs.enqueued_msgs,
       pqs.dequeued_msgs, pqs.browsed_msgs, pqs.elapsed_enqueue_time,
       pqs.elapsed_dequeue_time, pqs.enqueue_cpu_time, pqs.dequeue_cpu_time,
       pqs.avg_msg_age, pqs.dequeued_msg_latency,
       pqs.elapsed_transformation_time, pqs.elapsed_rule_evaluation_time,
       pqs.enqueued_expiry_msgs, pqs.enqueued_delay_msgs,
       pqs.msgs_made_expired, pqs.msgs_made_ready, pqs.last_enqueue_time,
       pqs.last_dequeue_time, pqs.last_tm_expiry_time, pqs.last_tm_ready_time,
       pqs.enqueue_transactions, pqs.dequeue_transactions, pqs.execution_count,
       decode(pqs.con_dbid, 0, pqs.dbid, pqs.con_dbid),
       decode(pqs.per_pdb, 0, 0,
         con_dbid_to_id(decode(pqs.con_dbid, 0, pqs.dbid, pqs.con_dbid))) con_id
  from wrh$_persistent_queues pqs, AWR_ROOT_SNAPSHOT sn
  where     sn.snap_id          = pqs.snap_id
        and sn.dbid             = pqs.dbid
        and sn.instance_number  = pqs.instance_number
/

comment on table AWR_ROOT_PERSISTENT_QUEUES is 'STREAMS AQ Persistent Queues Historical Statistics Information'
/

