create view DBA_OBJECT_USAGE (OWNER, INDEX_NAME, TABLE_NAME, MONITORING, USED, START_MONITORING, END_MONITORING) as
select u.name, io.name, t.name,
       decode(bitand(i.flags, 65536), 0, 'NO', 'YES'),
       decode(bitand(ou.flags, 1), 0, 'NO', 'YES'),
       ou.start_monitoring,
       ou.end_monitoring
from sys.obj$ io, sys.user$ u, sys.obj$ t, sys.ind$ i, sys.object_usage ou
where io.owner# = u.user#
  and i.obj# = ou.obj#
  and io.obj# = ou.obj#
  and t.obj# = i.bo#
/

comment on table DBA_OBJECT_USAGE is 'Record of index usage'
/

comment on column DBA_OBJECT_USAGE.OWNER is 'Owner of the index'
/

comment on column DBA_OBJECT_USAGE.INDEX_NAME is 'Name of the index'
/

comment on column DBA_OBJECT_USAGE.TABLE_NAME is 'Name of the table upon which the index was build'
/

comment on column DBA_OBJECT_USAGE.MONITORING is 'Whether the monitoring feature is on'
/

comment on column DBA_OBJECT_USAGE.USED is 'Whether the index has been accessed'
/

comment on column DBA_OBJECT_USAGE.START_MONITORING is 'When the monitoring feature is turned on'
/

comment on column DBA_OBJECT_USAGE.END_MONITORING is 'When the monitoring feature is turned off'
/

