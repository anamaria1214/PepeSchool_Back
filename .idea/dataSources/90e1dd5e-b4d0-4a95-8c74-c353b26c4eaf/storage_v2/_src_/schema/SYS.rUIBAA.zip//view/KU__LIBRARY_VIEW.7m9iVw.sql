create view KU$_LIBRARY_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, FILESPEC, LIB_AUDIT, PROPERTY, AGENT, DIRECTORY, FILENAME,
             CREDENTIAL) as
select '1','0',
         lb.obj#, value(o),
         lb.filespec,
         replace(lb.audit$,chr(0),'-'),
         bitand(lb.property, (power(2, 32)-1)),
         lb.agent,
         (select do.name from sys.obj$ do, sys.dependency$ d
          where do.obj#  = d.p_obj# and
                d.d_obj# = lb.obj# and
                do.type# = 23),
         lb.leaf_filename,
         (select value(c) from sys.ku$_credential_view c, sys.dependency$ d, obj$ oo
          where c.schema_obj.obj_num= d.p_obj# and
                d.d_obj#=lb.obj# and
                oo.obj#=d.p_obj# and
                oo.type#=90)
  from sys.ku$_edition_schemaobj_view o, sys.library$ lb
  where o.type_num=22 AND
        lb.obj# = o.obj_num AND
         (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles WHERE role='SELECT_CATALOG_ROLE'))
/

