create view DBA_HEAT_MAP_SEGMENT
            (OWNER, OBJECT_NAME, SUBOBJECT_NAME, SEGMENT_WRITE_TIME, SEGMENT_READ_TIME, FULL_SCAN, LOOKUP_SCAN) as
select u.name, o.name, o.subname,
    max (decode (hm.segment_write, 'YES', track_time, null)) SEGMENT_WRITE_TIME,
    max (decode (hm.segment_read, 'YES', track_time, null)) SEGMENT_READ_TIME,
    max (decode (hm.full_scan, 'YES', track_time, null)) FULL_SCAN,
    max (decode (hm.lookup_scan, 'YES', track_time, null)) LOOKUP_SCAN
  from obj$ o, user$ u, sys."_SYS_HEAT_MAP_SEG_HISTOGRAM" hm
  where o.obj# = hm.obj#
          and   o.owner# = u.user#
  group by u.name, o.name, o.subname
/

comment on table DBA_HEAT_MAP_SEGMENT is 'Last segment access time'
/

comment on column DBA_HEAT_MAP_SEGMENT.SEGMENT_WRITE_TIME is 'Last segment write access time'
/

comment on column DBA_HEAT_MAP_SEGMENT.SEGMENT_READ_TIME is 'Last segment read access time'
/

comment on column DBA_HEAT_MAP_SEGMENT.FULL_SCAN is 'Last full scan time'
/

comment on column DBA_HEAT_MAP_SEGMENT.LOOKUP_SCAN is 'Last range scan or point scan time'
/

