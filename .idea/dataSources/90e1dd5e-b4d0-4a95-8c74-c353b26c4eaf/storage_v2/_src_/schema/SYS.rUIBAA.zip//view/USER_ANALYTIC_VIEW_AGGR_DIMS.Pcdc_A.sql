create view USER_ANALYTIC_VIEW_AGGR_DIMS (ANALYTIC_VIEW_NAME, AGGR_GROUP_NAME, DIM_NAME, ORDER_NUM, ORIGIN_CON_ID) as
select ANALYTIC_VIEW_NAME, AGGR_GROUP_NAME, DIM_NAME,
       ORDER_NUM, ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_AVIEW_AGGR_DIMS)
where owner = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_ANALYTIC_VIEW_AGGR_DIMS is 'Analytic view aggregation function dimensions in the database'
/

comment on column USER_ANALYTIC_VIEW_AGGR_DIMS.ANALYTIC_VIEW_NAME is 'Name of the analytic view'
/

comment on column USER_ANALYTIC_VIEW_AGGR_DIMS.AGGR_GROUP_NAME is 'Aggregation group name of the aggregation function'
/

comment on column USER_ANALYTIC_VIEW_AGGR_DIMS.DIM_NAME is 'Name of the analytic view aggregation function dimension'
/

comment on column USER_ANALYTIC_VIEW_AGGR_DIMS.ORDER_NUM is 'Order number of the dimension within the analytic view aggregation function'
/

comment on column USER_ANALYTIC_VIEW_AGGR_DIMS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

