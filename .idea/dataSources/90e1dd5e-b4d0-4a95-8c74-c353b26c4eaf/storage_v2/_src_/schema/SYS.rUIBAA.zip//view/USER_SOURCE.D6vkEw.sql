create view USER_SOURCE (NAME, TYPE, LINE, TEXT, ORIGIN_CON_ID) as
select NAME, TYPE, LINE, TEXT,  ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(int$dba_source)
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

comment on table USER_SOURCE is 'Source of stored objects accessible to the user'
/

comment on column USER_SOURCE.NAME is 'Name of the object'
/

comment on column USER_SOURCE.TYPE is 'Type of the object: "TYPE", "TYPE BODY", "PROCEDURE", "FUNCTION",
"PACKAGE", "PACKAGE BODY", "LIBRARY", "ASSEMBLY" or "JAVA SOURCE"'
/

comment on column USER_SOURCE.LINE is 'Line number of this line of source'
/

comment on column USER_SOURCE.TEXT is 'Source text'
/

comment on column USER_SOURCE.ORIGIN_CON_ID is 'ID of Container where row originates'
/

