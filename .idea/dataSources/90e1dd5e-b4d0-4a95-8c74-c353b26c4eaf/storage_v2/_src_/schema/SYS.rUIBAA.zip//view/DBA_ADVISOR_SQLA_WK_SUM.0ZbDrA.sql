create view DBA_ADVISOR_SQLA_WK_SUM
            (OWNER, TASK_NAME, TASK_ID, NUM_SELECT_STMT, NUM_UPDATE_STMT, NUM_DELETE_STMT, NUM_INSERT_STMT,
             NUM_MERGE_STMT) as
select b.owner_name as owner,
             b.name as task_name,
             b.id as task_id,
             a.num_select as num_select_stmt,
             a.num_update as num_update_stmt,
             a.num_delete as num_delete_stmt,
             a.num_insert as num_insert_stmt,
             a.num_merge as num_merge_stmt
      from wri$_adv_sqla_sum a, wri$_adv_tasks b
      where a.task_id = b.id
        and b.advisor_id = 2
/

