create view DBA_TSDP_IMPORT_ERRORS (ERROR_CODE, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME, SENSITIVE_TYPE) as
select
  errcode,
  identifier1,
  identifier2,
  identifier3,
  identifier4
from sys.tsdp_error$
/

comment on table DBA_TSDP_IMPORT_ERRORS is 'Lists the errors encountered during import of Discovery Result'
/

comment on column DBA_TSDP_IMPORT_ERRORS.ERROR_CODE is 'The ORA error code of the error encountered'
/

comment on column DBA_TSDP_IMPORT_ERRORS.SCHEMA_NAME is 'The Schema corresponding to the error'
/

comment on column DBA_TSDP_IMPORT_ERRORS.TABLE_NAME is 'The Table corresponding to the error'
/

comment on column DBA_TSDP_IMPORT_ERRORS.COLUMN_NAME is 'The Column corresponding to the error'
/

comment on column DBA_TSDP_IMPORT_ERRORS.SENSITIVE_TYPE is 'The Sensitive Type corresponding to the error'
/

