create view INT$DBA_HIER_HIER_ATTR_CLASS
            (OWNER, HIER_NAME, OWNER_ID, OBJECT_ID, OBJECT_TYPE, HIER_ATTR_NAME, CLASSIFICATION, VALUE, LANGUAGE,
             ORDER_NUM, SHARING, ORIGIN_CON_ID)
as
select u.name owner,
       o.name hier_name,
       o.owner# OWNER_ID,
       o.obj# OBJECT_ID,
       o.type# OBJECT_TYPE,
       ha.attr_name HIER_ATTR_NAME,
       c.clsfction_name classification,
       c.clsfction_value value,
       c.clsfction_lang language,
       c.order_num order_num,
       case when bitand(o.flags, 196608)>0 then 1 else 0 end sharing,
       to_number(sys_context('USERENV','CON_ID')) origin_con_id
from sys.obj$ o, hcs_clsfctn$ c, user$ u, hcs_hier_attr$ ha
where u.user# = o.owner#
      and c.obj# = o.obj#
      and c.obj_type = '11' -- HIERARCHICAL ATTRIBUTE
      and ha.hier# = c.obj#
      and ha.attr# = c.sub_obj#
/

