create view CDB_DATA_FILES
            (FILE_NAME, FILE_ID, TABLESPACE_NAME, BYTES, BLOCKS, STATUS, RELATIVE_FNO, AUTOEXTENSIBLE, MAXBYTES,
             MAXBLOCKS, INCREMENT_BY, USER_BYTES, USER_BLOCKS, ONLINE_STATUS, LOST_WRITE_PROTECT, CON_ID)
as
SELECT k."FILE_NAME",k."FILE_ID",k."TABLESPACE_NAME",k."BYTES",k."BLOCKS",k."STATUS",k."RELATIVE_FNO",k."AUTOEXTENSIBLE",k."MAXBYTES",k."MAXBLOCKS",k."INCREMENT_BY",k."USER_BYTES",k."USER_BLOCKS",k."ONLINE_STATUS",k."LOST_WRITE_PROTECT",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_DATA_FILES") k
/

comment on table CDB_DATA_FILES is 'Information about database data files in all containers'
/

comment on column CDB_DATA_FILES.FILE_NAME is 'Name of the database data file'
/

comment on column CDB_DATA_FILES.FILE_ID is 'ID of the database data file'
/

comment on column CDB_DATA_FILES.TABLESPACE_NAME is 'Name of the tablespace to which the file belongs'
/

comment on column CDB_DATA_FILES.BYTES is 'Size of the file in bytes'
/

comment on column CDB_DATA_FILES.BLOCKS is 'Size of the file in ORACLE blocks'
/

comment on column CDB_DATA_FILES.STATUS is 'File status:  "INVALID" or "AVAILABLE"'
/

comment on column CDB_DATA_FILES.RELATIVE_FNO is 'Tablespace-relative file number'
/

comment on column CDB_DATA_FILES.AUTOEXTENSIBLE is 'Autoextensible indicator:  "YES" or "NO"'
/

comment on column CDB_DATA_FILES.MAXBYTES is 'Maximum autoextensible file size in bytes'
/

comment on column CDB_DATA_FILES.MAXBLOCKS is 'Maximum autoextensible file size in blocks'
/

comment on column CDB_DATA_FILES.INCREMENT_BY is 'Default increment for autoextension'
/

comment on column CDB_DATA_FILES.USER_BYTES is 'Size of the useful portion of file in bytes'
/

comment on column CDB_DATA_FILES.USER_BLOCKS is 'Size of the useful portion of file in ORACLE blocks'
/

comment on column CDB_DATA_FILES.ONLINE_STATUS is 'Online status of the file'
/

comment on column CDB_DATA_FILES.LOST_WRITE_PROTECT is 'Lost write protection status of file - also check tablespace setting'
/

comment on column CDB_DATA_FILES.CON_ID is 'container id'
/

