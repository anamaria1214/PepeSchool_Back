create view CDB_XS_PRINCIPALS (NAME, GUID, TYPE, EXTERNAL_SOURCE, DESCRIPTION, CON_ID) as
SELECT k."NAME",k."GUID",k."TYPE",k."EXTERNAL_SOURCE",k."DESCRIPTION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XS_PRINCIPALS") k
/

comment on table CDB_XS_PRINCIPALS is 'All the Real Application Security principals defined in the database in all containers'
/

comment on column CDB_XS_PRINCIPALS.NAME is 'Name of the principal'
/

comment on column CDB_XS_PRINCIPALS.GUID is 'GUID of the principal'
/

comment on column CDB_XS_PRINCIPALS.TYPE is 'Type of the principal. Possible values are USER, ROLE, or DYNAMIC ROLE'
/

comment on column CDB_XS_PRINCIPALS.EXTERNAL_SOURCE is 'External source of the principal'
/

comment on column CDB_XS_PRINCIPALS.DESCRIPTION is 'Description of the principal'
/

comment on column CDB_XS_PRINCIPALS.CON_ID is 'container id'
/

