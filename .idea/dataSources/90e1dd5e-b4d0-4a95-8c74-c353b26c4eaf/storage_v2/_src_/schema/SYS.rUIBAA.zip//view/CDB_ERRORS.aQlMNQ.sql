create view CDB_ERRORS (OWNER, NAME, TYPE, SEQUENCE, LINE, POSITION, TEXT, ATTRIBUTE, MESSAGE_NUMBER, CON_ID) as
SELECT k."OWNER",k."NAME",k."TYPE",k."SEQUENCE",k."LINE",k."POSITION",k."TEXT",k."ATTRIBUTE",k."MESSAGE_NUMBER",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ERRORS") k
/

comment on table CDB_ERRORS is 'Current errors on all stored objects in the database in all containers'
/

comment on column CDB_ERRORS.NAME is 'Name of the object'
/

comment on column CDB_ERRORS.TYPE is 'Type of the object'
/

comment on column CDB_ERRORS.SEQUENCE is 'Sequence number used for ordering purposes'
/

comment on column CDB_ERRORS.LINE is 'Line number at which this error occurs'
/

comment on column CDB_ERRORS.POSITION is 'Position in the line at which this error occurs'
/

comment on column CDB_ERRORS.TEXT is 'Text of the error'
/

comment on column CDB_ERRORS.CON_ID is 'container id'
/

