create view ALL_SCHEDULER_DB_DESTS (OWNER, DESTINATION_NAME, CONNECT_INFO, AGENT, ENABLED, REFS_ENABLED, COMMENTS) as
SELECT "OWNER","DESTINATION_NAME","CONNECT_INFO","AGENT","ENABLED","REFS_ENABLED","COMMENTS" FROM dba_scheduler_db_dests
/

comment on table ALL_SCHEDULER_DB_DESTS is 'User-visible destination objects in the database pointing to remote databases'
/

comment on column ALL_SCHEDULER_DB_DESTS.OWNER is 'Owner of this destination object'
/

comment on column ALL_SCHEDULER_DB_DESTS.DESTINATION_NAME is 'Name of this destination object'
/

comment on column ALL_SCHEDULER_DB_DESTS.CONNECT_INFO is 'Connect string to connect to remote database'
/

comment on column ALL_SCHEDULER_DB_DESTS.AGENT is 'Name of agent through which connection to remote database is being made'
/

comment on column ALL_SCHEDULER_DB_DESTS.ENABLED is 'Whether this destination object is enabled'
/

comment on column ALL_SCHEDULER_DB_DESTS.COMMENTS is 'Optional comment'
/

