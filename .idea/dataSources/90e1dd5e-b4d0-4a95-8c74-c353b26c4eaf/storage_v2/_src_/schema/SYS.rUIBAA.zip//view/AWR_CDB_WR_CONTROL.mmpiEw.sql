create view AWR_CDB_WR_CONTROL
            (DBID, SNAP_INTERVAL, RETENTION, TOPNSQL, CON_ID, SRC_DBID, SRC_DBNAME, TABLESPACE_NAME) as
select dbid, snap_interval, retention,
       decode(topnsql, 2000000000, 'DEFAULT',
                       2000000001, 'MAXIMUM',
                       to_char(topnsql, '999999999')) topnsql,
       decode(con_dbid_to_id(dbid), 1, 0, con_dbid_to_id(dbid)) con_id,
       decode(src_dbid, 0, dbid, src_dbid) src_dbid,
       src_dbname, tablespace_name
from WRM$_WR_CONTROL
/

comment on table AWR_CDB_WR_CONTROL is 'Workload Repository Control Information'
/

