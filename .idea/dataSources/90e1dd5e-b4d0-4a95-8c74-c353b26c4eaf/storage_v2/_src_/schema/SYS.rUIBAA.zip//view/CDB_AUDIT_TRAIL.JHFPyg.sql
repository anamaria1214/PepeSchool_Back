create view CDB_AUDIT_TRAIL
            (OS_USERNAME, USERNAME, USERHOST, TERMINAL, TIMESTAMP, OWNER, OBJ_NAME, ACTION, ACTION_NAME, NEW_OWNER,
             NEW_NAME, OBJ_PRIVILEGE, SYS_PRIVILEGE, ADMIN_OPTION, GRANTEE, AUDIT_OPTION, SES_ACTIONS, LOGOFF_TIME,
             LOGOFF_LREAD, LOGOFF_PREAD, LOGOFF_LWRITE, LOGOFF_DLOCK, COMMENT_TEXT, SESSIONID, ENTRYID, STATEMENTID,
             RETURNCODE, PRIV_USED, CLIENT_ID, ECONTEXT_ID, SESSION_CPU, EXTENDED_TIMESTAMP, PROXY_SESSIONID,
             GLOBAL_UID, INSTANCE_NUMBER, OS_PROCESS, TRANSACTIONID, SCN, SQL_BIND, SQL_TEXT, OBJ_EDITION_NAME, DBID,
             RLS_INFO, CURRENT_USER, CON_ID)
as
SELECT k."OS_USERNAME",k."USERNAME",k."USERHOST",k."TERMINAL",k."TIMESTAMP",k."OWNER",k."OBJ_NAME",k."ACTION",k."ACTION_NAME",k."NEW_OWNER",k."NEW_NAME",k."OBJ_PRIVILEGE",k."SYS_PRIVILEGE",k."ADMIN_OPTION",k."GRANTEE",k."AUDIT_OPTION",k."SES_ACTIONS",k."LOGOFF_TIME",k."LOGOFF_LREAD",k."LOGOFF_PREAD",k."LOGOFF_LWRITE",k."LOGOFF_DLOCK",k."COMMENT_TEXT",k."SESSIONID",k."ENTRYID",k."STATEMENTID",k."RETURNCODE",k."PRIV_USED",k."CLIENT_ID",k."ECONTEXT_ID",k."SESSION_CPU",k."EXTENDED_TIMESTAMP",k."PROXY_SESSIONID",k."GLOBAL_UID",k."INSTANCE_NUMBER",k."OS_PROCESS",k."TRANSACTIONID",k."SCN",k."SQL_BIND",k."SQL_TEXT",k."OBJ_EDITION_NAME",k."DBID",k."RLS_INFO",k."CURRENT_USER",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_AUDIT_TRAIL") k
/

comment on table CDB_AUDIT_TRAIL is 'All audit trail entries in all containers'
/

comment on column CDB_AUDIT_TRAIL.OS_USERNAME is 'Operating System logon user name of the user whose actions were audited'
/

comment on column CDB_AUDIT_TRAIL.USERNAME is 'Name of the logged in user whose actions were audited'
/

comment on column CDB_AUDIT_TRAIL.USERHOST is 'Client host machine name'
/

comment on column CDB_AUDIT_TRAIL.TERMINAL is 'Identifier for the user''s terminal'
/

comment on column CDB_AUDIT_TRAIL.TIMESTAMP is 'Date/Time of the creation of the audit trail entry (Date/Time of the user''s logon for entries created by AUDIT SESSION) in session''s time zone'
/

comment on column CDB_AUDIT_TRAIL.OWNER is 'Creator of object affected by the action'
/

comment on column CDB_AUDIT_TRAIL.OBJ_NAME is 'Name of the object affected by the action'
/

comment on column CDB_AUDIT_TRAIL.ACTION is 'Numeric action type code.  The corresponding name of the action type (CREATE TABLE, INSERT, etc.) is in the column ACTION_NAME'
/

comment on column CDB_AUDIT_TRAIL.ACTION_NAME is 'Name of the action type corresponding to the numeric code in ACTION'
/

comment on column CDB_AUDIT_TRAIL.NEW_OWNER is 'The owner of the object named in the NEW_NAME column'
/

comment on column CDB_AUDIT_TRAIL.NEW_NAME is 'New name of object after RENAME, or name of underlying object (e.g. CREATE INDEX owner.obj_name ON new_owner.new_name)'
/

comment on column CDB_AUDIT_TRAIL.OBJ_PRIVILEGE is 'Object privileges granted/revoked by a GRANT/REVOKE statement'
/

comment on column CDB_AUDIT_TRAIL.RLS_INFO is 'RLS predicates along with the RLS policy names used for the object accessed'
/

comment on column CDB_AUDIT_TRAIL.CURRENT_USER is 'Effective user for the statement execution'
/

comment on column CDB_AUDIT_TRAIL.CON_ID is 'container id'
/

