create view CDB_LOGSTDBY_PLSQL_MAP (OWNER, PKG_NAME, PROC_NAME, INTERNAL_PKG_NAME, INTERNAL_PROC_NAME, CON_ID) as
SELECT k."OWNER",k."PKG_NAME",k."PROC_NAME",k."INTERNAL_PKG_NAME",k."INTERNAL_PROC_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_LOGSTDBY_PLSQL_MAP") k
/

comment on table CDB_LOGSTDBY_PLSQL_MAP is 'PLSQL mapping from user invokable procedure to supp-log pragma-ed procedure in all containers'
/

comment on column CDB_LOGSTDBY_PLSQL_MAP.OWNER is 'Owner name of the procedure'
/

comment on column CDB_LOGSTDBY_PLSQL_MAP.PKG_NAME is 'Package name of the user invokable procedure'
/

comment on column CDB_LOGSTDBY_PLSQL_MAP.PROC_NAME is 'Procedure name of the user invokable procedure'
/

comment on column CDB_LOGSTDBY_PLSQL_MAP.INTERNAL_PKG_NAME is 'Package name of the internal procedure'
/

comment on column CDB_LOGSTDBY_PLSQL_MAP.INTERNAL_PROC_NAME is 'Procedure name of the internal procedure'
/

comment on column CDB_LOGSTDBY_PLSQL_MAP.CON_ID is 'container id'
/

