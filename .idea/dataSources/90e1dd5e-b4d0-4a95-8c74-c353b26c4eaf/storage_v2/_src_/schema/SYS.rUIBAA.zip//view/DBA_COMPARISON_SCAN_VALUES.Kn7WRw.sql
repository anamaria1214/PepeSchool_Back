create view DBA_COMPARISON_SCAN_VALUES
            (OWNER, COMPARISON_NAME, SCAN_ID, COLUMN_POSITION, MIN_VALUE, MAX_VALUE, LAST_UPDATE_TIME) as
SELECT
  u.name              owner,
  r.comparison_name   comparison_name,
  v.scan_id           scan_id,
  v.column_position   column_position,
  v.min_val           min_value,
  v.max_val           max_value,
  v.last_update_time
FROM
  comparison$ r, user$ u, comparison_scan_val$ v
WHERE
    v.comparison_id = r.comparison_id
AND r.user# = u.user#
/

comment on table DBA_COMPARISON_SCAN_VALUES is 'Details about a comparison scan''s values'
/

comment on column DBA_COMPARISON_SCAN_VALUES.OWNER is 'Owner of comparison'
/

comment on column DBA_COMPARISON_SCAN_VALUES.COMPARISON_NAME is 'Name of comparison'
/

comment on column DBA_COMPARISON_SCAN_VALUES.SCAN_ID is 'Scan id of scan'
/

comment on column DBA_COMPARISON_SCAN_VALUES.COLUMN_POSITION is 'Column position as in dba_comparison_columns'
/

comment on column DBA_COMPARISON_SCAN_VALUES.MIN_VALUE is 'Minimum value of scan'
/

comment on column DBA_COMPARISON_SCAN_VALUES.MAX_VALUE is 'Maximum value of scan'
/

comment on column DBA_COMPARISON_SCAN_VALUES.LAST_UPDATE_TIME is 'The time that this row was updated'
/

