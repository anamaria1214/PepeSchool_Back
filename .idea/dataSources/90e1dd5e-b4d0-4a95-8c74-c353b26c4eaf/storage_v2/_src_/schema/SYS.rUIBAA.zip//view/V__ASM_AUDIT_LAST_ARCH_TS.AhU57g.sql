create view V_$ASM_AUDIT_LAST_ARCH_TS (AUDIT_TRAIL, LAST_ARCHIVE_TS, CON_ID) as
select "AUDIT_TRAIL","LAST_ARCHIVE_TS","CON_ID" from v$asm_audit_last_arch_ts
/

