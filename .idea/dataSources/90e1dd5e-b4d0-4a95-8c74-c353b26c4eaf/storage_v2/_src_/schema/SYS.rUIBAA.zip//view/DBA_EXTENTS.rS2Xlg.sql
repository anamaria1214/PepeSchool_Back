create view DBA_EXTENTS
            (OWNER, SEGMENT_NAME, PARTITION_NAME, SEGMENT_TYPE, TABLESPACE_NAME, EXTENT_ID, FILE_ID, BLOCK_ID, BYTES,
             BLOCKS, RELATIVE_FNO)
as
select ds.owner, ds.segment_name, ds.partition_name, ds.segment_type,
       ds.tablespace_name,
       e.ext#, f.file#, e.block#, e.length * ds.blocksize, e.length, e.file#
from sys.uet$ e, sys.sys_dba_segs ds, sys.file$ f
where e.segfile# = ds.relative_fno
  and e.segblock# = ds.header_block
  and e.ts# = ds.tablespace_id
  and e.ts# = f.ts#
  and e.file# = f.relfile#
  and bitand(NVL(ds.segment_flags,0), 1) = 0
  and bitand(NVL(ds.segment_flags,0), 65536) = 0
union all
select
       ds.owner, ds.segment_name, ds.partition_name, ds.segment_type,
       ds.tablespace_name,
       e.ktfbueextno, f.file#, e.ktfbuebno,
       e.ktfbueblks * ds.blocksize, e.ktfbueblks, e.ktfbuefno
from sys.sys_dba_segs ds, sys.x$ktfbue e, sys.file$ f
where e.ktfbuesegfno = ds.relative_fno
  and e.ktfbuesegbno = ds.header_block
  and e.ktfbuesegtsn = ds.tablespace_id
  and ds.tablespace_id = f.ts#
  and e.ktfbuefno = f.relfile#
  and bitand(NVL(ds.segment_flags, 0), 1) = 1
  and bitand(NVL(ds.segment_flags,0), 65536) = 0
/

comment on table DBA_EXTENTS is 'Extents comprising all segments in the database'
/

comment on column DBA_EXTENTS.OWNER is 'Owner of the segment associated with the extent'
/

comment on column DBA_EXTENTS.SEGMENT_NAME is 'Name of the segment associated with the extent'
/

comment on column DBA_EXTENTS.PARTITION_NAME is 'Partition/Subpartition Name, if any, of the segment'
/

comment on column DBA_EXTENTS.SEGMENT_TYPE is 'Type of the segment'
/

comment on column DBA_EXTENTS.TABLESPACE_NAME is 'Name of the tablespace containing the extent'
/

comment on column DBA_EXTENTS.EXTENT_ID is 'Extent number in the segment'
/

comment on column DBA_EXTENTS.FILE_ID is 'Name of the file containing the extent'
/

comment on column DBA_EXTENTS.BLOCK_ID is 'Starting block number of the extent'
/

comment on column DBA_EXTENTS.BYTES is 'Size of the extent in bytes'
/

comment on column DBA_EXTENTS.BLOCKS is 'Size of the extent in ORACLE blocks'
/

comment on column DBA_EXTENTS.RELATIVE_FNO is 'Relative number of the file containing the segment header'
/

