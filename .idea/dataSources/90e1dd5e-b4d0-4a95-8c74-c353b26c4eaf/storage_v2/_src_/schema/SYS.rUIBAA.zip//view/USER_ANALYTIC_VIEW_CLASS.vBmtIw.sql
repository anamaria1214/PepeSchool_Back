create view USER_ANALYTIC_VIEW_CLASS (ANALYTIC_VIEW_NAME, CLASSIFICATION, VALUE, LANGUAGE, ORDER_NUM, ORIGIN_CON_ID) as
select analytic_view_name, classification, value, language,
       order_num, origin_con_id
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_AVIEW_CLASS)
where OWNER = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_ANALYTIC_VIEW_CLASS is 'Analytic view classifications in the database'
/

comment on column USER_ANALYTIC_VIEW_CLASS.ANALYTIC_VIEW_NAME is 'Analytic view name of owning analytic view classification'
/

comment on column USER_ANALYTIC_VIEW_CLASS.CLASSIFICATION is 'Name of analytic view classification'
/

comment on column USER_ANALYTIC_VIEW_CLASS.VALUE is 'Value of analytic view classification'
/

comment on column USER_ANALYTIC_VIEW_CLASS.LANGUAGE is 'Language of analytic view classification'
/

comment on column USER_ANALYTIC_VIEW_CLASS.ORDER_NUM is 'Order number of analytic view classification'
/

comment on column USER_ANALYTIC_VIEW_CLASS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

