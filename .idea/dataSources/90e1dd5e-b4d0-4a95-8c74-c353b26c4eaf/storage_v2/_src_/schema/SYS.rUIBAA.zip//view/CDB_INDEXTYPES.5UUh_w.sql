create view CDB_INDEXTYPES
            (OWNER, INDEXTYPE_NAME, IMPLEMENTATION_SCHEMA, IMPLEMENTATION_NAME, INTERFACE_VERSION,
             IMPLEMENTATION_VERSION, NUMBER_OF_OPERATORS, PARTITIONING, ARRAY_DML, MAINTENANCE_TYPE, CON_ID)
as
SELECT k."OWNER",k."INDEXTYPE_NAME",k."IMPLEMENTATION_SCHEMA",k."IMPLEMENTATION_NAME",k."INTERFACE_VERSION",k."IMPLEMENTATION_VERSION",k."NUMBER_OF_OPERATORS",k."PARTITIONING",k."ARRAY_DML",k."MAINTENANCE_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_INDEXTYPES") k
/

comment on table CDB_INDEXTYPES is 'All indextypes in all containers'
/

comment on column CDB_INDEXTYPES.OWNER is 'Owner of the indextype'
/

comment on column CDB_INDEXTYPES.INDEXTYPE_NAME is 'Name of the indextype'
/

comment on column CDB_INDEXTYPES.IMPLEMENTATION_SCHEMA is 'Name of the schema for indextype implementation'
/

comment on column CDB_INDEXTYPES.IMPLEMENTATION_NAME is 'Name of indextype implementation'
/

comment on column CDB_INDEXTYPES.INTERFACE_VERSION is 'Version of indextype interface'
/

comment on column CDB_INDEXTYPES.IMPLEMENTATION_VERSION is 'Version of indextype implementation'
/

comment on column CDB_INDEXTYPES.NUMBER_OF_OPERATORS is 'Number of operators associated with the indextype'
/

comment on column CDB_INDEXTYPES.PARTITIONING is 'Kinds of local partitioning supported by the indextype'
/

comment on column CDB_INDEXTYPES.ARRAY_DML is 'Does this indextype support array dml'
/

comment on column CDB_INDEXTYPES.MAINTENANCE_TYPE is 'An indicator of whether the indextype is system managed or user managed'
/

comment on column CDB_INDEXTYPES.CON_ID is 'container id'
/

