create view DBA_FREE_SPACE_COALESCED_TMP2 (TS#, TOTAL_EXTENTS, TOTAL_BLOCKS) as
select ts#, count(*), sum(length)
    from sys.fet$
  group by ts#
union all
  select u.ts#, count(*), sum(u.length)
    from sys.uet$ u, sys.ts$ ts, sys.recyclebin$ rb
  where ts.ts# = u.ts#
    and u.ts# = rb.ts#
    and u.segfile# = rb.file#
    and u.segblock# = rb.block#
    and ts.bitmapped = 0
  group by u.ts#
/

comment on column DBA_FREE_SPACE_COALESCED_TMP2.TS# is 'Number of Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP2.TOTAL_EXTENTS is 'Number of Free Extents in Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP2.TOTAL_BLOCKS is 'Total Free Blocks in Tablespace'
/

