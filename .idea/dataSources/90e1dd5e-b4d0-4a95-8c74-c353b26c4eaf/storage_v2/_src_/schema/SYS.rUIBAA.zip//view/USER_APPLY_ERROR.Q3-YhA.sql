create view USER_APPLY_ERROR
            (APPLY_NAME, QUEUE_NAME, QUEUE_OWNER, LOCAL_TRANSACTION_ID, SOURCE_DATABASE, SOURCE_TRANSACTION_ID,
             SOURCE_COMMIT_SCN, MESSAGE_NUMBER, ERROR_NUMBER, ERROR_MESSAGE, RECIPIENT_ID, RECIPIENT_NAME,
             MESSAGE_COUNT, ERROR_CREATION_TIME, SOURCE_COMMIT_POSITION, ERROR_TYPE, SOURCE_ROOT_NAME, ERROR_POSITION)
as
select p.apply_name, e.queue_name, e.queue_owner, e.local_transaction_id,
       e.source_database, e.source_transaction_id,
       e.source_commit_scn, e.message_number, e.error_number,
       e.error_message, e.recipient_id, e.recipient_name, e.message_count,
       e.error_creation_time, e.source_commit_position, e.error_type,
       e.source_root_name, e.error_position
  from DBA_APPLY_ERROR e, sys.streams$_apply_process p, sys.user$ u
  where e.apply_name = p.apply_name and p.apply_userid = u.user#
        and u.name = sys_context('USERENV', 'CURRENT_USER')
/

comment on table USER_APPLY_ERROR is 'Error transactions owned by an apply visible to the current user'
/

comment on column USER_APPLY_ERROR.APPLY_NAME is 'Name of the apply process at the local site which processed the transaction'
/

comment on column USER_APPLY_ERROR.QUEUE_NAME is 'Name of the queue at the local site where the transaction came from'
/

comment on column USER_APPLY_ERROR.QUEUE_OWNER is 'Owner of the queue at the local site where the transaction came from'
/

comment on column USER_APPLY_ERROR.LOCAL_TRANSACTION_ID is 'Local transaction ID for the error creation transaction'
/

comment on column USER_APPLY_ERROR.SOURCE_DATABASE is 'Database where the transaction originated'
/

comment on column USER_APPLY_ERROR.SOURCE_TRANSACTION_ID is 'Original transaction ID at the source database'
/

comment on column USER_APPLY_ERROR.SOURCE_COMMIT_SCN is 'Original commit SCN for the transaction at the source database'
/

comment on column USER_APPLY_ERROR.MESSAGE_NUMBER is 'Identifier for the message in the transaction that raised an error'
/

comment on column USER_APPLY_ERROR.ERROR_NUMBER is 'Error number'
/

comment on column USER_APPLY_ERROR.ERROR_MESSAGE is 'Error message'
/

comment on column USER_APPLY_ERROR.RECIPIENT_ID is 'User ID of the original recipient'
/

comment on column USER_APPLY_ERROR.RECIPIENT_NAME is 'Name of the original recipient'
/

comment on column USER_APPLY_ERROR.MESSAGE_COUNT is 'Total number of messages inside the error transaction'
/

comment on column USER_APPLY_ERROR.ERROR_CREATION_TIME is 'The time that this error was created'
/

comment on column USER_APPLY_ERROR.SOURCE_COMMIT_POSITION is 'Original commit position for the transaction'
/

comment on column USER_APPLY_ERROR.ERROR_TYPE is 'The type of the error transaction'
/

comment on column USER_APPLY_ERROR.SOURCE_ROOT_NAME is 'Root Database where the transaction originated'
/

comment on column USER_APPLY_ERROR.ERROR_POSITION is 'Position of the LCR that encountered the error'
/

