create view CDB_SCHEDULER_GROUP_MEMBERS (OWNER, GROUP_NAME, MEMBER_NAME, CON_ID) as
SELECT k."OWNER",k."GROUP_NAME",k."MEMBER_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SCHEDULER_GROUP_MEMBERS") k
/

comment on table CDB_SCHEDULER_GROUP_MEMBERS is 'Members of all scheduler object groups in the database in all containers'
/

comment on column CDB_SCHEDULER_GROUP_MEMBERS.OWNER is 'Owner of the group'
/

comment on column CDB_SCHEDULER_GROUP_MEMBERS.GROUP_NAME is 'Name of the group'
/

comment on column CDB_SCHEDULER_GROUP_MEMBERS.MEMBER_NAME is 'Name of the member of this group'
/

comment on column CDB_SCHEDULER_GROUP_MEMBERS.CON_ID is 'container id'
/

