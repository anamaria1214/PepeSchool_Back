create view DBA_REPLAY_UPGRADE_STATEMENTS
            (ORIGIN_CON_ID, STATEMENT_ID, CAPTURE_TIME, STATEMENT, VERSION_NUMBER, SESSION_ID, OPCODE, OPTIMIZED,
             COMPONENT_ID) as
with catalog$dflt$appid as
(
   select max(ver#), decode(tgtver,'12.1.0.1.0',4294967295,
                                   '12.1.0.2.0',4294967294,
                                   '12.2.0.1.0',4294967293,
                                   '18.0.0.0.0',4294967292,
                                   '19.0.0.0.0',4294967291,
                                   '11.2.0.4.0',4294967290,
                                    -1) dfltappid
     from fed$versions f, v$instance v
    where f.appid#=(select appid# from fed$apps
                     where spare1=0 and app_name='APP$CDB$CATALOG')
      and substr(f.tgtver,1,10)<>substr(v.version,1,10) group by tgtver
)
select ORIGIN_CON_ID, STATEMENT_ID, CAPTURE_TIME, NVL(LONGSQLTXT, SQLSTMT),
       VERSION_NUMBER, SESSION_ID,
       OPCODE, OPTIMIZED, nvl(s.COMPONENT_ID, 'CATALOG')
from INT$DBA_APP_STATEMENTS s, catalog$dflt$appid
where (((select count(*) from int$dba_app_statements
                         where app_id=dfltappid)=0
                 and s.app_name='APP$CDB$CATALOG')
        or s.app_id=dfltappid)
/

comment on table DBA_REPLAY_UPGRADE_STATEMENTS is 'Describes all statements for Replay Upgrade'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.STATEMENT_ID is 'Statement ID'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.CAPTURE_TIME is 'Time of capture of application statement'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.STATEMENT is 'Statement Text'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.VERSION_NUMBER is 'Version number when statement was captured'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.SESSION_ID is 'Unique session id when statement was captured'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.OPCODE is 'Opcode indicating statement type'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.OPTIMIZED is 'Indicates whether statement was skipped due to optimization'
/

comment on column DBA_REPLAY_UPGRADE_STATEMENTS.COMPONENT_ID is 'Component ID of the replayed statement'
/

