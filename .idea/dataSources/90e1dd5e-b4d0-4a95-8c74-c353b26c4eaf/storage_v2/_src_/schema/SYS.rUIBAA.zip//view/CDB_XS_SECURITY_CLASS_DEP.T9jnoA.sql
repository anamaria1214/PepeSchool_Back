create view CDB_XS_SECURITY_CLASS_DEP (SECURITY_CLASS, OWNER, PARENT, PARENT_OWNER, CON_ID) as
SELECT k."SECURITY_CLASS",k."OWNER",k."PARENT",k."PARENT_OWNER",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XS_SECURITY_CLASS_DEP") k
/

comment on table CDB_XS_SECURITY_CLASS_DEP is 'The dependencies between all the Real Application Security security classes defined in the database in all containers'
/

comment on column CDB_XS_SECURITY_CLASS_DEP.SECURITY_CLASS is 'Name of the security class'
/

comment on column CDB_XS_SECURITY_CLASS_DEP.OWNER is 'Owner of the security class'
/

comment on column CDB_XS_SECURITY_CLASS_DEP.PARENT is 'Name of the parent security class'
/

comment on column CDB_XS_SECURITY_CLASS_DEP.PARENT_OWNER is 'Owner of the parent security class'
/

comment on column CDB_XS_SECURITY_CLASS_DEP.CON_ID is 'container id'
/

