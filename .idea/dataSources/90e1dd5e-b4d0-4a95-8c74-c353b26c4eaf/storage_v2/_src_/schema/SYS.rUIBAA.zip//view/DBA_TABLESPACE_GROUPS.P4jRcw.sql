create view DBA_TABLESPACE_GROUPS (GROUP_NAME, TABLESPACE_NAME) as
select ts2.name, ts.name
from ts$ ts, ts$ ts2
where ts.online$ != 3
and bitand(ts.flags,1024) = 1024
    and ts.dflmaxext  = ts2.ts#
/

comment on table DBA_TABLESPACE_GROUPS is 'Description of all tablespace groups'
/

comment on column DBA_TABLESPACE_GROUPS.GROUP_NAME is 'Tablespace Group name'
/

comment on column DBA_TABLESPACE_GROUPS.TABLESPACE_NAME is 'Tablespace name'
/

