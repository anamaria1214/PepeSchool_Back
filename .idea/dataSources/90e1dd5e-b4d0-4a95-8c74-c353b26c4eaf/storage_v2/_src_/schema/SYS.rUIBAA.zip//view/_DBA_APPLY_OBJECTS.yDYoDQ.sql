create view "_DBA_APPLY_OBJECTS"
            (OBJECT_OWNER, OBJECT_NAME, PROPERTY, APPLY_DATABASE_LINK, SPARE1, SPARE2, SPARE3, SPARE4) as
select
u.name, o.name, do.property, do.dblink, do.spare1, do.spare2,
do.spare3, do.spare4
from sys.streams$_dest_objs do, sys.obj$ o, sys.user$ u
  where o.obj# = do.object_number
   and o.owner# = u.user#
/

