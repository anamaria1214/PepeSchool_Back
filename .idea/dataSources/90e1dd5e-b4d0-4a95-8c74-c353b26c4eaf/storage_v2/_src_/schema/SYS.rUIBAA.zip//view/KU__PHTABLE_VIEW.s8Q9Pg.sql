create view KU$_PHTABLE_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, BASE_OBJ, ANC_OBJ, BOBJ_NUM, TAB_NUM, COLS, CLUCOLS,
             TABCLUSTER, FBA, FBA_PERIODS, CLST, ILM_POLICIES, FLAGS, FLAGS2, AUDIT_VAL, ROWCNT, BLKCNT, EMPCNT, AVGSPC,
             CHNCNT, AVGRLN, AVGSPC_FLB, FLBCNT, ANALYZETIME, SAMPLESIZE, DEGREE, INSTANCES, INTCOLS, KERNELCOLS,
             TSTZ_COLS, TRIGFLAG, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5, SPARE6, SPARE7, SPARE8, SPARE9, SPARE10,
             ENCALG, INTALG, IM_COLSEL, CON0_LIST, CON2_LIST, EXTTAB, CUBETAB, BLOCKCHAIN, SVCNAME, SVCFLAGS, PROPERTY,
             PROPERTY2, PROPERTY3, PROPERTY4, STORAGE, DEFERRED_STG, TS_NAME, BLOCKSIZE, DATAOBJ_NUM, PCT_FREE,
             PCT_USED, INITRANS, MAXTRANS, CON1_LIST, COL_LIST, NT, PKREF_LIST, XMLSCHEMACOLS, XMLCOLSET, XMLHIERARCHY,
             PARENT_OBJ, REFPAR_LEVEL, OBJGRANT_LIST, PCT_THRESH, NUMKEYCOLS, INCLCOL_NAME, IOV, MAPTAB, PART_OBJ)
as
select '2','8',
         t.obj#,
         value(o),
         -- if this is a secondary table, get base obj and ancestor obj
         decode(bitand(o.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, secobj$ s
              where o.obj_num=s.secobj#
                and oo.obj_num=s.obj#
                and rownum < 2),
           null),
         decode(bitand(o.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, ind$ i, secobj$ s
              where o.obj_num=s.secobj#
                and i.obj#=s.obj#
                and oo.obj_num=i.bo#
                and rownum < 2),
           null),
        /* -- */
         t.bobj#, t.tab#, t.cols,
         t.clucols,
         (select value(cl) from ku$_tabcluster_view cl
          where cl.obj_num = t.obj#),
        /* fba  - flashback archive, table clustering, ILM */
         (select /*+ INDEX (SYS_FBA_TRACKEDTABLES)*/ value(fb)
          from ku$_fba_view fb where fb.obj_num = t.obj#),
         cast( multiset(select * from ku$_fba_period_view fb
                        where fb.obj_num = t.obj#
                        order by fb.periodname
                        ) as ku$_fba_period_list_t
             ),
         (select value(cz) from ku$_clst_view cz where cz.obj_num = t.obj#),
         cast( multiset(select /*+ INDEX (ILMPOLICY$)*/ * from ku$_ilm_policy_view p
                        where p.obj_num = t.obj#
                        order by p.policy_num
                        ) as ku$_ilm_policy_list_t
              ),
         bitand(t.flags, (power(2, 32)-1)),
         bitand(trunc(t.flags / power(2, 32)), (power(2, 32)-1)),
         replace(t.audit$,chr(0),'-'), t.rowcnt, t.blkcnt, t.empcnt,
         t.avgspc, t.chncnt, t.avgrln, t.avgspc_flb, t.flbcnt,
         to_char(t.analyzetime,'YYYY/MM/DD HH24:MI:SS'),
         t.samplesize, t.degree, t.instances, t.intcols, t.kernelcols,
         (select sys.dbms_metadata_util.has_tstz_cols(t.obj#) from dual),
         bitand(t.trigflag, (power(2, 32)-1)),
         t.spare1, t.spare2, t.spare3, t.spare4, t.spare5,
         to_char(t.spare6,'YYYY/MM/DD HH24:MI:SS'),  t.spare7,t.spare8,t.spare9,t.spare10,
         decode(bitand(t.trigflag, 65536), 65536,
           (select e.encalg from sys.enc$ e where e.obj#=t.obj#),
           null),
         decode(bitand(t.trigflag, 65536), 65536,
           (select e.intalg from sys.enc$ e where e.obj#=t.obj#),
           null),
         cast( multiset(select * from ku$_im_colsel_view imc
                        where imc.obj_num = t.obj#
                       ) as ku$_im_colsel_list_t
             ),
         cast( multiset(select * from ku$_constraint0_view con
                        where con.obj_num = t.obj#
                        and con.contype not in (7,11)
                       ) as ku$_constraint0_list_t
             ),
         cast( multiset(select * from ku$_constraint2_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint2_list_t
             ),
         (select value(etv) from ku$_exttab_view etv
                        where etv.obj_num = o.obj_num),
         (select value(otv) from ku$_cube_tab_view otv
                        where otv.obj_num = o.obj_num),
         decode(BITAND(nvl(t.spare7,0),128), 0,NULL,
             (select value(bc) from ku$_blockchain_view bc
                     where bc.obj_num = o.obj_num)),
         (select svcname  from imsvc$ where obj# = t.obj# and subpart# is null),
         (select bitand(svcflags, (power(2, 32)-1))
          from imsvc$ where obj# = t.obj# and subpart# is null),
      /* storage and deferred storage (at most one will be found), tablespace name/blocksize */
         bitand(t.property, (power(2, 32)-1)),
         bitand(trunc(t.property / power(2, 32)), (power(2, 32)-1)),
         bitand(trunc(t.property / power(2,64)),  (power(2, 32)-1)),
         bitand(trunc(t.property / power(2,96)),  (power(2, 32)-1)),
         (select value(s) fr
/

