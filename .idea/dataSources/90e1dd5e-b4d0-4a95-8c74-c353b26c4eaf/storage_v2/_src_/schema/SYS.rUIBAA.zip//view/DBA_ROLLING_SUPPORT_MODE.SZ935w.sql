create view DBA_ROLLING_SUPPORT_MODE (OWNER, TABLE_NAME, SUPPORT_MODE, EXPLANATION) as
with redo_compat as
         (select nvl((select min(s.redo_compat)
                      from system.logstdby$parameters p,
                           system.logmnr_session$ s,
                           sys.v$database d
                      where p.name in ('LMNR_SID', 'FUTURE_SESSION') and
                            p.value = s.session# and
                            d.database_role = 'LOGICAL STANDBY'),
                     (select p.value
                      from sys.v$parameter p
                      where p.name = 'compatible')) compat
          from dual)
  select owner, name,
  (
    case
     when (gensby = 0) then
      'UNSUPPORTED'
     when (gensby = -1) then
      'INTERNAL'
     else 'SUPPORTED'
    end
  ) support_mode, explanation
  from (
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_support_tab_10_1 u, redo_compat c
    where c.compat like '10.0%' or c.compat like '10.1%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_support_tab_10_2 u, redo_compat c
    where c.compat like '10.2%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_support_tab_11_1 u, redo_compat c
    where c.compat like '11.0%' or c.compat like '11.1%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_support_tab_11_2 u, redo_compat c
    where c.compat like '11.2%' and c.compat not like '11.2.0.3%'
                                and c.compat not like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_support_tab_11_2b u, redo_compat c
    where c.compat like '11.2.0.3%' or c.compat like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_ru_support_tab_12_1 u, redo_compat c
    where c.compat like '12.0%' or c.compat like '12.1%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_ru_support_tab_12_2 u, redo_compat c
    where c.compat like '12.2%' and c.compat not like '12.2.0.2%'
    UNION ALL
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_ru_supp_tab_12_2_0_2 u, redo_compat c
    where c.compat like '12.2.0.2%' or c.compat like '18.0%'
          or c.compat like '18.1%'
    UNION ALL
    -- If replication metadata maintenance is disabled via event, then we must
    -- use the 19.0 compat-specific view.
    select u.owner, u.name, u.gensby, '' explanation
    from logstdby_ru_supp_tab_19 u, redo_compat c
    where c.compat like '19.%' or
          (c.compat like '2%.%' and
           sys_context('userenv', 'IS_REPL_META_DISABLED') = 'TRUE')
    UNION ALL
    -- Transient/Rolling LSBY views are common to all compats from 20.0 onward
    select u.owner, u.name, u.gensby, u.explanation
    from logstdby_ru_support_tab_common u, redo_compat c
    where c.compat like '2%.%' and
          sys_context('userenv', 'IS_REPL_META_DISABLED') = 'FALSE'
  )
/

comment on table DBA_ROLLING_SUPPORT_MODE is 'List of all tables and their support_mode during DBMS_ROLLING upgrade'
/

comment on column DBA_ROLLING_SUPPORT_MODE.OWNER is 'Schema name of the table'
/

comment on column DBA_ROLLING_SUPPORT_MODE.TABLE_NAME is 'Name of the table'
/

comment on column DBA_ROLLING_SUPPORT_MODE.SUPPORT_MODE is 'Either SUPPORTED, UNSUPPORTED, or INTERNAL'
/

comment on column DBA_ROLLING_SUPPORT_MODE.EXPLANATION is 'Gives a reason when support_mode is not SUPPORTED'
/

