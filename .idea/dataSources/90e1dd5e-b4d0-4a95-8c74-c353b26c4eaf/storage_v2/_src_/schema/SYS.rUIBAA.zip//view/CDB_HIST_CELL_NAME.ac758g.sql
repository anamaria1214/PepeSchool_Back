create view CDB_HIST_CELL_NAME (DBID, SNAP_ID, CELL_HASH, CELL_NAME, CON_DBID, CON_ID) as
SELECT k."DBID",k."SNAP_ID",k."CELL_HASH",k."CELL_NAME",k."CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_CELL_NAME") k
/

comment on table CDB_HIST_CELL_NAME is 'Exadata Cell names in all containers'
/

comment on column CDB_HIST_CELL_NAME.CON_ID is 'container id'
/

