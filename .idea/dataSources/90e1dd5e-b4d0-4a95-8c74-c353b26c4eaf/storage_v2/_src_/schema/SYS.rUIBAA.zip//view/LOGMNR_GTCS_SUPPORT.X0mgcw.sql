create view LOGMNR_GTCS_SUPPORT
            (LOGMNR_UID, OBJ#, OBJV#, SEGCOL#, INTCOL#, COL#, COLNAME, TYPE#, LENGTH, PRECISION, SCALE,
             INTERVAL_LEADING_PRECISION, INTERVAL_TRAILING_PRECISION, PROPERTY, CHARSETID, CHARSETFORM, LOGMNRCOLFLAGS,
             XTYPESCHEMANAME, XTYPENAME, XFQCOLNAME, XTOPINTCOL, XREFFEDTABLEOBJN, XREFFEDTABLEOBJV, XCOLTYPEFLAGS,
             XOPQTYPETYPE, XOPQTYPEFLAGS, XOPQLOBINTCOL, XOPQOBJINTCOL, XXMLINTCOL, EAOWNER#, EAMKEYID, EAENCALG,
             EAINTALG, EACOLKLC, EAKLCLEN, EAFLAGS, LOGMNRDERIVEDFLAGS, COLLID, COLLINTCOL#, ACDRRESCOL#, NULL$)
as
select
         o.logmnr_uid,
         o.obj#,
         o.objv#,
         lc.segcol#,
         lc.intcol#,
         lc.col#,
         lc.name,
         lc.type#,
         lc.length,
         lc.precision#,
         lc.scale,
         lc.spare2,  /* INTERVAL_LEADING_PRECISION */
         lc.spare1,  /* INTERVAL_TRAILING_PRECISION */
         lc.property,
         lc.charsetid,
         lc.charsetform,
         NULL LogmnrColFlags,   /* THIS IS BEING SET IN C */
         case lc.type#
              when 1 /* DTYCHR */ then NULL  /* shortcut for most common */
              when 2 /* DTYNUM */ then NULL
              when 12 /* DTYDAT */ then NULL
              when 58 /* DTYOPQ - XMLType, ANYDATA, etc. */ then
               (select lv.data_type_owner
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
              when 121 /* DTYADT */ then
               (select lv.data_type_owner
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
              when 122 /* DTYNTB */ then
               (select lv.data_type_owner
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
              when 123 /* DTYNAR */ then
               (select lv.data_type_owner
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
              when 111 /* DTYIREF */ then  /* needed?  copied from  dba_tab_cols */
               (select lv.data_type_owner
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
           else NULL end XTypeSchemaName,
         case lc.type#
              when 1 /* DTYCHR */ then NULL  /* shortcut for most common */
              when 2 /* DTYNUM */ then NULL
              when 12 /* DTYDAT */ then NULL
              when 58 /* DTYOPQ - XMLTYPE, ANYDATA, etc. */ then
               (select lv.data_type
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
              when 121 /* DTYADT */ then
               (select lv.data_type
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
              when 122 /* DTYNTB */ then
               (select lv.data_type
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
              when 123 /* DTYNAR */ then
               (select lv.data_type
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
              when 111 /* DTYIREF */ then  /* needed?  copied from  dba_tab_cols */
               (select lv.data_type
                 from sys.logmnr_tab_cols_support lv
                 where lv.logmnr_uid = o.logmnr_uid and
                       lv.obj# = lc.obj# and
                       lv.internal_column_id = lc.intcol#)
           else NULL end XTypeName,
         case bit
/

