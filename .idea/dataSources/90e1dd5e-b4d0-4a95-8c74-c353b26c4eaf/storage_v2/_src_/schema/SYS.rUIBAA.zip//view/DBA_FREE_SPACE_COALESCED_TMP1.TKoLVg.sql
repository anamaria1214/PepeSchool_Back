create view DBA_FREE_SPACE_COALESCED_TMP1 (TS#, EXTENTS_COALESCED, BLOCKS_COALESCED) as
select a.ts#, count(*) extents_coalesced, sum(a.length) blocks_coalesced
    from sys.fet$ a
  where not exists (
    select *
      from sys.fet$ b
    where b.ts# = a.ts#
      and b.file# = a.file#
      and a.block# = b.block# + b.length)
  group by ts#
union all
  select u.ts#, count(*) extents_coalesced, sum(u.length) blocks_coalesced
    from sys.uet$ u, sys.ts$ ts, sys.recyclebin$ rb
  where ts.ts# = u.ts#
    and u.ts# = rb.ts#
    and u.segfile# = rb.file#
    and u.segblock# = rb.block#
    and ts.bitmapped = 0
    and not exists (
      select *
        from sys.uet$ ub
      where u.ts# = ub.ts#
        and u.file# = ub.file#
        and u.block# = ub.block# + ub.length)
  group by u.ts#
/

comment on column DBA_FREE_SPACE_COALESCED_TMP1.TS# is 'Number of Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP1.EXTENTS_COALESCED is 'Number of Coalesced Free Extents in Tablespace'
/

comment on column DBA_FREE_SPACE_COALESCED_TMP1.BLOCKS_COALESCED is 'Total Coalesced Free Oracle Blocks in Tablespace'
/

