create view CDB_ACTIVITY_CONFIG
            (CON_DBNAME, PARAMETER_NAME, PARAMETER_VALUE, LAST_UPDATED_TIME, LAST_UPDATED_USER, CON_ID) as
SELECT k."CON_DBNAME",k."PARAMETER_NAME",k."PARAMETER_VALUE",k."LAST_UPDATED_TIME",k."LAST_UPDATED_USER",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ACTIVITY_CONFIG") k
/

comment on table CDB_ACTIVITY_CONFIG is 'Object Activity Tracking Configuation in all containers'
/

comment on column CDB_ACTIVITY_CONFIG.PARAMETER_NAME is 'The name of an activity configuration parameter'
/

comment on column CDB_ACTIVITY_CONFIG.PARAMETER_VALUE is 'The value of a configuration parameter'
/

comment on column CDB_ACTIVITY_CONFIG.LAST_UPDATED_TIME is 'The time this configuration parameter was last updated'
/

comment on column CDB_ACTIVITY_CONFIG.LAST_UPDATED_USER is 'The user who last updated this configuration parameter'
/

comment on column CDB_ACTIVITY_CONFIG.CON_ID is 'container id'
/

