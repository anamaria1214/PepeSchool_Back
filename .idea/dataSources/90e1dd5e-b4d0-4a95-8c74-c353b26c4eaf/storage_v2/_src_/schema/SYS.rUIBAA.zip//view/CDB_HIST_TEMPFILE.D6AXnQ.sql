create view CDB_HIST_TEMPFILE (DBID, FILE#, CREATION_CHANGE#, FILENAME, TS#, TSNAME, BLOCK_SIZE, CON_DBID, CON_ID) as
SELECT k."DBID",k."FILE#",k."CREATION_CHANGE#",k."FILENAME",k."TS#",k."TSNAME",k."BLOCK_SIZE",k."CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_TEMPFILE") k
/

comment on table CDB_HIST_TEMPFILE is 'Names of Temporary Datafiles in all containers'
/

comment on column CDB_HIST_TEMPFILE.CON_ID is 'container id'
/

