create view DBA_COMPARISON
            (OWNER, COMPARISON_NAME, COMPARISON_MODE, SCHEMA_NAME, OBJECT_NAME, OBJECT_TYPE, REMOTE_SCHEMA_NAME,
             REMOTE_OBJECT_NAME, REMOTE_OBJECT_TYPE, DBLINK_NAME, SCAN_MODE, SCAN_PERCENT, CYCLIC_INDEX_VALUE,
             NULL_VALUE, LOCAL_CONVERGE_TAG, REMOTE_CONVERGE_TAG, MAX_NUM_BUCKETS, MIN_ROWS_IN_BUCKET, LAST_UPDATE_TIME)
as
SELECT
  u.name,
  comparison_name,
  decode(comparison_mode, 1, 'TABLE') comparison_mode,
  schema_name, object_name,
  decode(object_type, 2, 'TABLE', 4, 'VIEW', 5, 'SYNONYM',
         42, 'MATERIALIZED VIEW',
         'UNDEFINED') object_type,
  rmt_schema_name, rmt_object_name,
  decode(rmt_object_type, 2, 'TABLE', 4, 'VIEW', 5, 'SYNONYM',
         42, 'MATERIALIZED VIEW',
         'UNDEFINED') remote_object_type,
  dblink_name,
  decode(scan_mode, 1, 'FULL', 2, 'RANDOM', 3, 'CYCLIC', 4, 'CUSTOM',
         'UNDEFINED') scan_mode,
  scan_percent,
  cyl_idx_val cyclic_index_value,
  null_value,
  loc_converge_tag,
  rmt_converge_tag,
  max_num_buckets,
  min_rows_in_bucket,
  last_update_time
FROM comparison$ c, user$ u
where c.user# = u.user#
/

comment on table DBA_COMPARISON is 'Details about the comparison object'
/

comment on column DBA_COMPARISON.OWNER is 'Owner of comparison'
/

comment on column DBA_COMPARISON.COMPARISON_NAME is 'Name of comparison'
/

comment on column DBA_COMPARISON.COMPARISON_MODE is 'Mode of comparison: TABLE'
/

comment on column DBA_COMPARISON.SCHEMA_NAME is 'Schema name of local object'
/

comment on column DBA_COMPARISON.OBJECT_NAME is 'Name of local object'
/

comment on column DBA_COMPARISON.OBJECT_TYPE is 'Type of local object'
/

comment on column DBA_COMPARISON.REMOTE_SCHEMA_NAME is 'Schema name of remote object'
/

comment on column DBA_COMPARISON.REMOTE_OBJECT_NAME is 'Name of remote object'
/

comment on column DBA_COMPARISON.REMOTE_OBJECT_TYPE is 'Type of remote object'
/

comment on column DBA_COMPARISON.DBLINK_NAME is 'Database link name to remote database'
/

comment on column DBA_COMPARISON.SCAN_MODE is 'Scan mode of comparison: FULL'
/

comment on column DBA_COMPARISON.SCAN_PERCENT is 'Scan percent of comparison: Applicable to Random and Cyclic modes'
/

comment on column DBA_COMPARISON.CYCLIC_INDEX_VALUE is 'Last index column value used in a cyclic scan'
/

comment on column DBA_COMPARISON.NULL_VALUE is 'Value to use for null column values'
/

comment on column DBA_COMPARISON.LOCAL_CONVERGE_TAG is 'The local streams tag used while performing converge dmls'
/

comment on column DBA_COMPARISON.REMOTE_CONVERGE_TAG is 'The remote streams tag used while performing converge dmls'
/

comment on column DBA_COMPARISON.MAX_NUM_BUCKETS is 'Suggested maximum number of buckets in a scan'
/

comment on column DBA_COMPARISON.MIN_ROWS_IN_BUCKET is 'Suggested minimum number of rows in a bucket'
/

comment on column DBA_COMPARISON.LAST_UPDATE_TIME is 'The time that this row was updated'
/

