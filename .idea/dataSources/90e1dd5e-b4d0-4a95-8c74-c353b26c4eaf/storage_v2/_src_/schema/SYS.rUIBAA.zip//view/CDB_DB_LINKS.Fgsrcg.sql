create view CDB_DB_LINKS
            (OWNER, DB_LINK, USERNAME, CREDENTIAL_NAME, CREDENTIAL_OWNER, HOST, CREATED, HIDDEN, SHARD_INTERNAL, VALID,
             INTRA_CDB, CON_ID)
as
SELECT k."OWNER",k."DB_LINK",k."USERNAME",k."CREDENTIAL_NAME",k."CREDENTIAL_OWNER",k."HOST",k."CREATED",k."HIDDEN",k."SHARD_INTERNAL",k."VALID",k."INTRA_CDB",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_DB_LINKS") k
/

comment on table CDB_DB_LINKS is 'All database links in the database in all containers'
/

comment on column CDB_DB_LINKS.DB_LINK is 'Name of the database link'
/

comment on column CDB_DB_LINKS.USERNAME is 'Name of user to log on as'
/

comment on column CDB_DB_LINKS.CREDENTIAL_NAME is 'Name of the credential that stores username and password'
/

comment on column CDB_DB_LINKS.CREDENTIAL_OWNER is 'Owner of the credential'
/

comment on column CDB_DB_LINKS.HOST is 'SQL*Net string for connect'
/

comment on column CDB_DB_LINKS.CREATED is 'Creation time of the database link'
/

comment on column CDB_DB_LINKS.HIDDEN is 'Whether database link is hidden or not'
/

comment on column CDB_DB_LINKS.SHARD_INTERNAL is 'Whether database link is internally managed for sharding'
/

comment on column CDB_DB_LINKS.VALID is 'Whether database link is usable or not'
/

comment on column CDB_DB_LINKS.INTRA_CDB is 'Whether database link is intra-CDB or not'
/

comment on column CDB_DB_LINKS.CON_ID is 'container id'
/

