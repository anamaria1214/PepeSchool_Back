create view KU$_TTSP_INDPARTVIEW (OBJ_NUM, PARTOBJ, TS_NAME, TS_NUM, IDX_PROP, POFLAGS, TS_FLAGS) as
SELECT i.bo#, value(tpo), ts.name, ts.ts#,
           bitand(i.property, (power(2, 32)-1)),
           bitand(po.flags, (power(2, 32)-1)),
           ts.flags
    from  (     sys.ku$_schemaobj_view tpo
     inner join sys.tabpart$    tp  on tpo.obj_num = tp.obj#
     inner join sys.ind$        i   on tp.bo#=i.bo#
     inner join sys.partobj$    po  on po.obj# = i.obj#
     inner join sys.indpart$    ip  on i.obj#=ip.bo# and
                                       tp.part#=ip.part#
     inner join sys.ts$         ts  on ip.ts#=ts.ts#
  )
/

