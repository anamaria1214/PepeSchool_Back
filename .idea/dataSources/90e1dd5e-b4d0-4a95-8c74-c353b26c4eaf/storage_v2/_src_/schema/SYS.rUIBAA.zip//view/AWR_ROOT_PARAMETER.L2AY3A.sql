create view AWR_ROOT_PARAMETER
            (SNAP_ID, DBID, INSTANCE_NUMBER, PARAMETER_HASH, PARAMETER_NAME, VALUE, ISDEFAULT, ISMODIFIED, CON_DBID,
             CON_ID) as
select p.snap_id, p.dbid, p.instance_number,
       p.parameter_hash, pn.parameter_name,
       case when SYS_CONTEXT('USERENV','SYSTEM_DATA_VISIBLE')='YES' or p.per_pdb<>0 then p.value else null end value, -- Use macro to mask sensitive column
       isdefault, ismodified,
       decode(p.con_dbid, 0, p.dbid, p.con_dbid),
       decode(p.per_pdb, 0, 0,
         con_dbid_to_id(decode(p.con_dbid, 0, p.dbid, p.con_dbid))) con_id
from AWR_ROOT_SNAPSHOT sn, WRH$_PARAMETER p, WRH$_PARAMETER_NAME pn
where     p.parameter_hash   = pn.parameter_hash
      and p.dbid             = pn.dbid
      and p.snap_id          = sn.snap_id
      and p.dbid             = sn.dbid
      and p.instance_number  = sn.instance_number
/

comment on table AWR_ROOT_PARAMETER is 'Parameter Historical Statistics Information'
/

