create view DBA_DMT_USED_EXTENTS (SEGMENT_FILEID, SEGMENT_BLOCK, TABLESPACE_ID, EXTENT_ID, FILEID, BLOCK, LENGTH) as
select  u.segfile#, u.segblock#, u.ts#,
        u.ext#, u.file#, u.block#, u.length
from    sys.uet$ u
where   not exists (select * from sys.recyclebin$ rb
                    where u.ts# = rb.ts#
                      and u.segfile# = rb.file#
                      and u.segblock# = rb.block#)
/

comment on table DBA_DMT_USED_EXTENTS is 'All extents in the dictionary managed tablespaces'
/

comment on column DBA_DMT_USED_EXTENTS.SEGMENT_FILEID is 'File number of segment header of the extent'
/

comment on column DBA_DMT_USED_EXTENTS.SEGMENT_BLOCK is 'Block number of segment header of the extent'
/

comment on column DBA_DMT_USED_EXTENTS.TABLESPACE_ID is 'ID of the tablespace containing the extent'
/

comment on column DBA_DMT_USED_EXTENTS.EXTENT_ID is 'Extent number in the segment'
/

comment on column DBA_DMT_USED_EXTENTS.FILEID is 'File Number of the extent'
/

comment on column DBA_DMT_USED_EXTENTS.BLOCK is 'Starting block number of the extent'
/

comment on column DBA_DMT_USED_EXTENTS.LENGTH is 'Number of blocks in the extent'
/

