create view CDB_AQ_AGENTS (AGENT_NAME, HTTP_ENABLED, SMTP_ENABLED, CON_ID) as
SELECT k."AGENT_NAME",k."HTTP_ENABLED",k."SMTP_ENABLED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_AQ_AGENTS") k
/

comment on table CDB_AQ_AGENTS is ' in all containers'
/

comment on column CDB_AQ_AGENTS.CON_ID is 'container id'
/

