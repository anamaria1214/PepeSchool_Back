create view AWR_PDB_CELL_METRIC_DESC (DBID, METRIC_ID, METRIC_NAME, METRIC_TYPE, CON_DBID, CON_ID) as
select dbid, metric_id, metric_name, metric_type,
       decode(con_dbid, 0, dbid, con_dbid),
       decode(con_dbid_to_id(dbid), 1, 0, con_dbid_to_id(dbid)) con_id
  from WRH$_CELL_METRIC_DESC
/

comment on table AWR_PDB_CELL_METRIC_DESC is 'Cell Metric Names'
/

