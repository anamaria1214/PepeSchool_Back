create view KU$_PROCDEPOBJ_GRANT_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, BASE_OBJ, CLASS, PREPOST, TYPE_NUM, LEVEL_NUM, TAG, CMNT, PACKAGE,
             PKG_SCHEMA, ANC_OBJ, PLSQL)
as
select '1','0',
         o.obj_num,
         value(o),
         p.class, p.prepost, p.type#, p.level#,
         p.tag, p.cmnt, p.package, p.schema,
         value(oo),
         sys.dbms_metadata.get_procobj_grant
               (p.tag, p.package, p.schema, 'GRANT_EXP',
                o.owner_name || '.' || o.name || ' - ' || o.type_name, o.obj_num,
                (select 1 from dual
                 where  (SYS_CONTEXT('USERENV','CURRENT_USERID') = 0
                 OR EXISTS ( SELECT * FROM sys.session_roles WHERE role='SELECT_CATALOG_ROLE'))))
  from   sys.ku$_schemaobj_view o, sys.ku$_schemaobj_view oo,
         sys.ku$_exppkgobj_view p,
         (select dp.p_obj#,dp.d_obj# from sys.expdepobj$ dp
             where not exists (select 1 from sys.expdepobj$ dp2
                         where dp.d_obj#=dp2.d_obj# and dp.rowid < dp2.rowid)) d
  where  p.class = 3 and p.type# = o.type_num and
                d.d_obj# = o.obj_num AND
                d.p_obj# = oo.obj_num
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles WHERE role='SELECT_CATALOG_ROLE'))
  order  by p.level#, p.type#
/

