create view USER_CUBE_NAMED_BUILD_SPECS (CUBE_NAME, NAMED_BUILD_SPEC) as
SELECT
  o.name CUBE_NAME,
  syn.syntax_clob NAMED_BUILD_SPEC
FROM
  olap_cubes$ c,
  obj$ o,
  olap_syntax$ syn
WHERE
  o.obj#=c.obj#
  AND o.owner#=USERENV('SCHEMAID')
  AND syn.owner_id(+)=c.obj#
  AND syn.owner_type(+)=1
  AND syn.ref_role = 18 -- named build spec
/

comment on table USER_CUBE_NAMED_BUILD_SPECS is 'OLAP Cube Named Build Specifications owned by the user in the database'
/

comment on column USER_CUBE_NAMED_BUILD_SPECS.CUBE_NAME is 'Name of the OLAP Cube'
/

comment on column USER_CUBE_NAMED_BUILD_SPECS.NAMED_BUILD_SPEC is 'Name of the OLAP Cube Named Build Specification'
/

