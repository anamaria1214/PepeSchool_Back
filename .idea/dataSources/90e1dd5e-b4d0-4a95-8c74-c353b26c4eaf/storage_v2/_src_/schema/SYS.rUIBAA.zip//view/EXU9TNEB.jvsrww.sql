create view EXU9TNEB (TSNO, FILENO, BLOCKNO, LENGTH) as
SELECT  ktfbuesegtsn, ktfbuesegfno, ktfbuesegbno, ktfbueblks
        FROM    sys.x$ktfbue
        WHERE   ktfbueextno = 1
/

