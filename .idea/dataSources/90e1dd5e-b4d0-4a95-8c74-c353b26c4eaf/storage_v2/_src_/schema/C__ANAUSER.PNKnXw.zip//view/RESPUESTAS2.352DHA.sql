create view RESPUESTAS2 as
SELECT ex.ID AS id_examen, re.id AS idRe FROM RESPUESTAEXAMEN re JOIN PREGUNTAEXAMEN pe ON re.PREGUNTAEXAMEN_ID=pe.ID
                                  JOIN EXAMENESTUDIANTE exe ON exe.ID=pe.examenestudiante_id
                                  JOIN EXAMEN ex ON exe.EXAMEN_ID=ex.ID
/

