create trigger MODIFICAR_EXAMEN
    before update
    on EXAMEN
    for each row
DECLARE
v_cantRespuestas NUMBER;
BEGIN
SELECT COUNT(re.id) INTO v_cantRespuestas 
                        FROM EXAMENESTUDIANTE exe 
                        LEFT JOIN preguntaexamen pe ON pe.examenestudiante_id=exe.id
                        LEFT JOIN respuestaexamen re ON pe.id=re.preguntaexamen_id
                        WHERE exe.examen_id=:old.ID;
                    
IF v_cantrespuestas>0 THEN
    RAISE_APPLICATION_ERROR(-20000, 'No se puede modificar el examen, ya ha sido contestado por un estudiante');
END IF;
END;
/

