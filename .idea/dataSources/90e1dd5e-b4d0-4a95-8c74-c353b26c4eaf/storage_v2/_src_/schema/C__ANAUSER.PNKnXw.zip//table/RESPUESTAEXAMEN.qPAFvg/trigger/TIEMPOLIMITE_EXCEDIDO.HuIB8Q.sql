create trigger TIEMPOLIMITE_EXCEDIDO
    before insert
    on RESPUESTAEXAMEN
    for each row
DECLARE
v_fechaPresentacion EXAMENESTUDIANTE.FECHAPRESENTACION%TYPE;
v_tiempoMax EXAMEN.LIMITETIEMPO%TYPE;
BEGIN
SELECT ex.limitetiempo, exe.fechapresentacion INTO v_tiempoMax, v_fechapresentacion
        FROM EXAMEN ex LEFT JOIN EXAMENESTUDIANTE exe ON ex.ID=exe.EXAMEN_ID
                       LEFT JOIN respuestas2 r ON ex.ID=r.id_examen
                       WHERE r.idRE=:new.id;

IF (v_fechapresentacion - SYSDATE) * 1440 > v_tiempoMax THEN
    RAISE_APPLICATION_ERROR(-20000, 'Ya excedió el tiempo límite para contestar el examen');
END IF;

END;
/

