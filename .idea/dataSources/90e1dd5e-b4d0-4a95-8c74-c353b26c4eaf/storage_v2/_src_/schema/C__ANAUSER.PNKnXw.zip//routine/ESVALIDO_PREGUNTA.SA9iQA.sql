create FUNCTION esValido_pregunta(
id_respuestaExamen IN NUMBER,
id_preguntaExamen IN NUMBER 
)RETURN VARCHAR2 IS
    v_opcion OPCION.ID%TYPE;
    v_preguntaCorrecta VARCHAR2(1) := 1;
    v_EsCorrecta OPCION.RESPUESTACORRECTA%TYPE;
BEGIN
SELECT op.RESPUESTACORRECTA INTO v_EsCorrecta FROM RESPUESTAEXAMEN re 
                            LEFT JOIN OPCION op ON re.OPCION_ID=op.ID 
                            WHERE re.ID=id_respuestaExamen;
   IF v_EsCorrecta='S' THEN 
   UPDATE PREGUNTAEXAMEN px SET px.escorrecta=1 WHERE px.ID=id_preguntaExamen;
     v_preguntaCorrecta:= 0;
   END IF;
    RETURN v_preguntaCorrecta;
EXCEPTION
WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No se encontró ninguna opción');
     WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('Se encontraron muchas opciones');
END;
/

